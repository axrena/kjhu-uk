# AlqorDuel - Profesyonel Duel Plugin (Paper 1.21+ / Java 21)

> AlqorDuel benzeri, yüksek performanslı, tamamen modüler ve profesyonel seviyede geliştirilmiş bir PvP düello eklentisi.

---

## 🚀 Özellikler

### Duel Sistemi
- `/duel invite <oyuncu>` - Düello isteği gönder
- `/duel kabul` - İsteği kabul et
- `/duel red` - İsteği reddet
- `/duel durum` - Aktif düello ve bekleyen istek durumu

**Kurallar (tam istenen gibi):**
- Aynı anda 1 aktif istek gönderebilir
- Aynı anda 1 bekleyen isteği olabilir
- Aynı anda 1 düelloda bulunabilir
- İstek kabul/red/süre dolunca tekrar istek gönderilebilir
- Kendine istek atamaz, offline'a atamaz
- Aynı düellodaki oyunculara tekrar istek atılamaz
- Varsayılan istek süresi 30 saniye (config)

**İstek gönderildiğinde efektler:**
- Title, Subtitle, ActionBar, Ses, Clickable Chat (KABUL/REDDET butonları)

### Arena Sistemi - Sınırsız Arena
Her arena:
- İsim, Dünya, Spawn1, Spawn2, Lobby (opsiyonel), Aktif/Pasif, Kullanım durumu

- Boşta arena otomatik seçilir
- Aynı arena 2 düello tarafından kullanılamaz
- Tamamen arenas.yml'e kaydedilir

**Arena Komutları (Admin):**
```
/duel create <arena>
/duel delete <arena>
/duel edit <arena> pos1
/duel edit <arena> pos2
/duel edit <arena> lobby
/duel edit <arena> enable
/duel edit <arena> disable
/duel arenas
/duel reload
```

### Düello Başlangıcı

Kabul edildiğinde kaydedilenler:
- Konum, Envanter, Zırh, Offhand, XP, Level, Sağlık, Açlık, Saturation, Potion Effectleri, GameMode, FireTicks, FallDistance

Sonrasında:
- Arena spawnlarına ışınlanma
- Can doldurma, açlık doldurma, ateş söndürme, efekt temizleme, fall/velocity sıfırlama
- 5 saniyelik geri sayım (config'den ayarlanabilir)

**Countdown sırasında:**
- PvP kapalı
- Hareket isteğe bağlı engellenebilir (`block-movement-during-countdown`)
- Komut kullanımı engelli
- Title, Subtitle, ActionBar, BossBar, Ses efekti

### Düello Sırasında
- PvP aktif
- Arena dışına çıkamaz (max-distance config, dışarı çıkarsa spawnına geri ışınlanır)
- Yasaklı işlemlerin tümü engelli (detay aşağıda)

### Düello Sonu
- Kazanan/kaybeden belirleme
- Title, ActionBar, Firework (3 adet rastgele renk), Ses, Chat broadcast
- Eski konumuna ışınlanma
- Envanter, zırh, XP, level, efekt, sağlık, açlık eksiksiz geri yükleme
- Arena otomatik boşaltma

### Oyuncu Çıkışı & Respawn
- Düello sırasında çıkış = otomatik kaybetme
- Rakip kazanır, arena temizlenir
- Respawn olduğunda eski konumuna gönderilir (PlayerState restore sistemi)

### Yasaklanan İşlemler (Config'den togglenabilir)
- Komut kullanımı (sadece duel komutları izinli)
- Teleport
- Blok kırma/koyma
- Item atma/alma
- Chest/EnderChest açma
- Inventory düzenleme
- GameMode değiştirme
- Uçma
- Vanish (flight ve gamemode ile dolaylı engellendi)
- Arena dışına çıkma

### GUI Sistemi (Modern, Dekoratif)
- Arena Listesi (`/duel arenas` veya `/duel gui`)
- Admin Arena Yönetimi (`/duel gui admin`)
- Düello İstek Onayı (istersen API ile açılabilir)
- Arena Seçimi
- Tüm boş slotlar siyah camla doldurulur, boş slot yok

### Dosyalar
- `config.yml` - Ana ayarlar, countdown, sesler, yasaklar, performans
- `messages.yml` - Tüm mesajlar MiniMessage, HEX destekli
- `arenas.yml` - Arena veritabanı (otomatik yönetilir)

### Mesaj Sistemi
- MiniMessage (`<gradient:#FF5F6D:#6A82FB>`)
- Adventure Components
- HEX Renkler (`<#RRGGBB>`)
- PlaceholderAPI desteği (`%player%`, PlaceholderAPI placeholder'ları otomatik çevrilir)
- Custom placeholderlar: `%player%`, `%target%`, `%arena%`, `%time%`, `%winner%`, `%loser%`, `%opponent%`

### Yetkiler
- `duel.use` - Temel duel komutları (default: true)
- `duel.admin` - Arena yönetimi, reload, admin GUI (default: op)

### Event Kullanımı (Profesyonel)
- PlayerJoinEvent, PlayerQuitEvent, PlayerMoveEvent, PlayerDeathEvent, PlayerRespawnEvent, EntityDamageByEntityEvent, InventoryClickEvent, InventoryCloseEvent, PlayerCommandPreprocessEvent, BlockBreakEvent, BlockPlaceEvent, PlayerDropItemEvent, EntityPickupItemEvent, EntityResurrectEvent, PlayerGameModeChangeEvent, PlayerToggleFlightEvent, PlayerTeleportEvent, PlayerInteractEvent

### Performans & OOP Mimari
- **Manager sınıfları:** ConfigManager, MessagesManager, ArenaConfigManager, ArenaManager, DuelManager, GUIManager
- **Model sınıfları:** Arena, Duel, DuelRequest, DuelState, PlayerState
- **Command:** DuelCommand + DuelTabCompleter
- **Listeners:** 13 ayrı listener sınıfı
- **Utils:** MessageUtil, LocationUtil, SoundUtil, ItemBuilder
- Bellek sızıntısı yok: Tüm tasklar cancel edilir, mapler ConcurrentHashMap
- Scheduler akıllıca kullanılıyor: Expiration task async, arena save async opsiyonel
- 200+ oyunculu sunucularda sorunsuz: O(1) lookup'lar, minimal PlayerMoveEvent logic
- Kod modüler, okunabilir, genişletilebilir
- Tüm ayarlar config üzerinden değiştirilebilir

---

## 📦 Kurulum

1. Java 21 yüklü olduğundan emin olun
2. Paper 1.21+ sunucu kullanın (`paper-1.21.4.jar` önerilir)
3. `AlqorDuel-1.0.0.jar` dosyasını `plugins/` klasörüne atın
4. Sunucuyu başlatın - configler oluşacak
5. `/duel create Arena1` ile arena oluşturun
6. `/duel edit Arena1 pos1` - Spawn1
7. `/duel edit Arena1 pos2` - Spawn2
8. `/duel edit Arena1 lobby` - Opsiyonel bekleme
9. `/duel edit Arena1 enable` - Aktifleştir
10. Artık oyuncular `/duel invite <oyuncu>` kullanabilir!

---

## 🔧 Derleme

```bash
mvn clean package
```
Çıktı: `target/AlqorDuel.jar`

Gereksinimler:
- Java 21
- Maven 3.8+
- Paper API 1.21.4

---

## 📝 Config Önizleme

```yaml
settings:
  request-expire-seconds: 30
  countdown-seconds: 5
  block-movement-during-countdown: true
  max-distance-from-arena: 50

duel:
  heal-on-start: true
  restrictions:
    block-commands: true
    block-break: true
    # ... daha fazlası

countdown:
  bossbar-enabled: true
  bossbar-color: "RED"
```

Mesajlar MiniMessage:
```yaml
duel:
  invite:
    received-chat:
      - "<gradient:#FF5F6D:#6A82FB>⚔ DÜELLO İSTEĞİ ⚔</gradient>"
      - "<green><click:run_command:'/duel kabul'>[✔ KABUL ET]</click>"
```

---

## 🏗️ Mimari Diyagram

```
AlqorDuel (Main)
├── ConfigManager (config.yml)
├── MessagesManager (messages.yml) + MessageUtil (MiniMessage + PAPI)
├── ArenaConfigManager (arenas.yml disk I/O)
├── ArenaManager (memory cache, findFreeArena)
├── DuelManager (requests, countdown, duel lifecycle, restore)
│   ├── Duel (data)
│   ├── DuelRequest (expire logic)
│   ├── PlayerState (snapshot & restore)
│   └── DuelState (enum)
├── GUIManager
│   └── BaseGUI (click actions)
├── Commands
│   ├── DuelCommand
│   └── DuelTabCompleter
└── Listeners (13 sınıf)
```

---

## 🔐 Güvenlik & Fair Play Notları

- Totem engeli: `EntityResurrectEvent` cancel
- Envanter korunması: DeathEvent drops clear + PlayerState restore
- Anti-cheat dostu: Velocity reset, fall distance reset, teleport async
- Crash güvenliği: onDisable'de tüm duellolar force-end + arena release

---

## 📄 Lisans

Özel proje - AlqorDuel esinlenmesi

---

## 👨‍💻 Geliştirici Notları

- Paper API modern `showTitle(Title)` kullanımı
- Adventure API Component tabanlı mesajlar, legacy fallback
- BossBar Bukkit + Adventure uyumlu
- Async save ile ana thread bloklanmıyor
- `teleportAsync` kullanımı Paper önerisine uygun

İyi düellolar! ⚔️
