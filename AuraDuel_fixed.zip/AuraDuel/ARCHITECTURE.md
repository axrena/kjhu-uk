# AlqorDuel Mimari Dokümantasyonu

## Paket Yapısı

```
com.alqorduel
├── AlqorDuel.java (Main Plugin Class)
├── config/
│   ├── ConfigManager.java (config.yml wrapper + typed getters)
│   ├── MessagesManager.java (messages.yml + MiniMessage cache)
│   └── ArenaConfigManager.java (arenas.yml async/sync save, thread-safe)
├── arena/
│   ├── Arena.java (Domain object, AtomicBoolean inUse, occupy/release)
│   └── ArenaManager.java (ConcurrentHashMap, random free arena selection, CRUD)
├── duel/
│   ├── DuelState.java (REQUESTED, COUNTDOWN, IN_PROGRESS, FINISHED, CANCELLED)
│   ├── DuelRequest.java (Immutable expire logic)
│   ├── PlayerState.java (Full snapshot, restore with teleportAsync fallback)
│   ├── Duel.java (Aggregate root)
│   └── DuelManager.java (Core logic: request lifecycle, countdown scheduler, end by death/quit, restore & cleanup, firework, broadcast)
├── gui/
│   ├── BaseGUI.java (InventoryHolder, click actions map, type enum)
│   └── GUIManager.java (Arena list, Admin, Confirm GUIs, decorative glass filling)
├── commands/
│   ├── DuelCommand.java (Subcommand router, permission checks, user-friendly errors)
│   └── DuelTabCompleter.java (Context aware: invite->online players, edit->arena names+pos1/pos2/lobby/enable/disable)
├── listeners/
│   ├── PlayerJoinListener (PAPI check)
│   ├── PlayerQuitListener (auto-lose + GUI unregister)
│   ├── PlayerMoveListener (freeze during countdown, border check with max-distance)
│   ├── PlayerDeathListener (clear drops/exp, call endDuelByDeath)
│   ├── PlayerRespawnListener (restore PlayerState, set respawn location to old location)
│   ├── DamageListener (cancel non-same-duel damage, cancel countdown damage)
│   ├── InventoryListener (GUI click handling priority, block inventory edit in duel)
│   ├── CommandBlockListener (block non-duel commands)
│   ├── BlockBreakPlaceListener (block building)
│   ├── ItemDropPickupListener (block drop/pickup)
│   ├── ResurrectListener (cancel totem)
│   ├── GameModeAndFlightListener (block gamemode/flight)
│   ├── TeleportListener (block teleport except arena spawns)
│   └── InteractListener (block chest/enderchest/shulker/barrel)
└── utils/
    ├── MessageUtil.java (MiniMessage central, prefix handling, PAPI hook via PlaceholderAPI.setPlaceholders, stripTags)
    ├── LocationUtil.java (serialize/deserialize to ConfigurationSection)
    ├── SoundUtil.java (safe Sound.valueOf parsing)
    └── ItemBuilder.java (fluent Component lore, glowing, flags)
```

## Akış Diyagramları

### İstek Akışı
```
Player A /duel invite B
→ DuelManager.sendRequest() checks
  - self? offline? isInDuel? alreadySent? targetHasPending? sameDuel?
→ Create DuelRequest(timestamp, expireAt)
→ Store in sentRequests & receivedRequests (ConcurrentHashMap)
→ notifyRequestSent() => Title, Subtitle, ActionBar, Sound, Clickable Chat
→ ExpirationTask (async 20t) scans sentRequests, moves expired to sync expireRequest() which sends messages & removeRequest()
```

### Kabul Akışı
```
/duel kabul
→ DuelManager.acceptRequest()
→ Find free arena via ArenaManager.findFreeArena() random
→ Try arena.tryOccupy(duelId) CAS atomic
→ Remove request maps
→ Create Duel object, add to duelsById & playerToDuelId
→ startDuelCountdown()
  - Save PlayerState for both
  - preparePlayerForDuel (heal/feed/extinguish/clear effects/reset velocity)
  - teleportAsync to spawn1/spawn2
  - Create Bukkit BossBar if enabled
  - Schedule runTaskTimer 0,20: countdown logic
    * Title, Actionbar, BossBar progress, sound
    * Check offline -> forceEndDuel(PLAYER_OFFLINE)
    * When count 0 -> runTask -> startDuel()
```

### Start Duel
```
→ Cancel countdown task id
→ State = IN_PROGRESS
→ Title "BAŞLA!", ActionBar, sound ENTITY_ENDER_DRAGON_GROWL
→ Chat: arena + opponent
→ PvP now allowed (DamageListener allows same duel id when state IN_PROGRESS)
```

### End Duel (Death)
```
PlayerDeathEvent -> clear drops/exp -> DuelManager.endDuelByDeath(loser)
→ Get duel by playerToDuelId
→ Get winner = opponent
→ forceEndDuel(winner, DEATH, loser)
  - Cancel countdown tasks
  - BossBar removeAll
  - State FINISHED
  - Resolve winner/loser names (offline support via Bukkit.getOfflinePlayer)
  - Send win/lose Title, ActionBar, win-chat list
  - Play win/lose sounds
  - Firework spawn (async task later for detonate)
  - Broadcast to all online if DEATH
  - If PLAYER_OFFLINE and both online still, send quit messages
  - restoreAndCleanup()
    * arena.release() atomic set false
    * runTaskLater 2 ticks:
      for each PlayerState: if online & !dead -> restore else add to pendingRespawnRestore
      remove duelsById & playerToDuelId
```

### Respawn Handling
```
PlayerRespawnEvent -> DuelManager.handleRespawn(player)
→ If pendingRespawnRestore contains uuid
  - Search duels or try restore scheduled
  - setRespawnLocation to PlayerState.location if found
  - Schedule 2 ticks later restore() which teleports to old location & inventory restore
→ If duel mapping still exists but player died (player.isDead()) -> pending
```

## Performans Kararları

- ConcurrentHashMap her yerde, synchronized blok yok
- Arena occupy atomic compareAndSet, race condition yok
- PlayerMoveEvent: sadece isInDuel ve state check, distanceSquared minimal
- Expiration task async'de scan, expire işlemi sync'e taşınıyor (Bukkit API thread safety)
- Arena save: asyncSave config ile ana thread bloklanmaz, ama onDisable'de sync save zorunlu
- No memory leak: openGUIs unregister on close/quit, bossBar removeAll, task cancel, maps clear
- 200+ oyuncularda: O(1) lookup player->duel, arena seçimi O(n) ama n=arena sayısı genelde <100, random erişim

## Genişletilebilirlik

- Yeni GUI eklemek: GUIManager'da yeni method + BaseGUI.Type enum ekle
- Yeni yasak eklemek: config.yml'e ekle + ConfigManager getter + listener'da check
- Yeni efekt: effects.sounds.* + SoundUtil
- PlaceholderAPI: MessageUtil.applyPlaceholders otomatik
```

