package com.Auraduel.gui;

import com.Auraduel.AuraDuel;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public final class BaseGUI implements InventoryHolder {

    public enum Type {
        ARENA_LIST,
        ADMIN_ARENA,
        DUEL_CONFIRM,
        ARENA_SELECT,
        DUEL_SETUP,
        KIT_SELECT,
        DUEL_SETTINGS
    }

    @FunctionalInterface
    public interface ClickAction {
        void onClick(Player player, ClickType clickType);
    }

    private final AuraDuel plugin;
    private final Component title;
    private final int size;
    private final Type type;
    private final Inventory inventory;
    private final Map<Integer, ClickAction> actions = new HashMap<>();

    public BaseGUI(AuraDuel plugin, Component title, int size, Type type) {
        this.plugin = plugin;
        this.title = title;
        this.size = size;
        this.type = type;
        this.inventory = Bukkit.createInventory(this, size, title);
    }

    public void setItem(int slot, ItemStack item, ClickAction action) {
        if (slot < 0 || slot >= size) return;
        inventory.setItem(slot, item);
        if (action != null) {
            actions.put(slot, action);
        } else {
            actions.remove(slot);
        }
    }

    public ClickAction getAction(int slot) {
        return actions.get(slot);
    }

    public void open(Player player) {
        player.openInventory(inventory);
    }

    public Type getType() {
        return type;
    }

    public Component getTitle() {
        return title;
    }

    public int getSize() {
        return size;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}

