package com.Auraduel.gui;

import com.Auraduel.AuraDuel;
import com.Auraduel.arena.Arena;
import com.Auraduel.duel.DuelRequest;
import com.Auraduel.kit.Kit;
import com.Auraduel.utils.ItemBuilder;
import com.Auraduel.utils.MessageUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class GUIManager {

    private final AuraDuel plugin;
    private final Map<UUID, BaseGUI> openGUIs = new HashMap<>();

    // Kit oluÅŸturma iÃ§in chat input bekleme
    public enum InputType {
        KIT_ID,
        KIT_DISPLAYNAME
    }

    public static final class KitCreationData {
        public String id;
        public String displayName;
        public Material icon;
        public boolean isNew = true;

        public KitCreationData(String id, String displayName, Material icon, boolean isNew) {
            this.id = id;
            this.displayName = displayName;
            this.icon = icon != null ? icon : Material.DIAMOND_SWORD;
            this.isNew = isNew;
        }
    }

    private final Map<UUID, InputType> pendingInputs = new ConcurrentHashMap<>();
    private final Map<UUID, KitCreationData> creationData = new ConcurrentHashMap<>();
    private final Map<UUID, String> editingKitId = new ConcurrentHashMap<>();
    // Sayfalama
    private final Map<UUID, Integer> kitManagementPage = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> kitSelectionPage = new ConcurrentHashMap<>();

    public GUIManager(AuraDuel plugin) {
        this.plugin = plugin;
    }

    public void registerOpen(Player player, BaseGUI gui) {
        openGUIs.put(player.getUniqueId(), gui);
    }

    public void unregisterOpen(Player player) {
        openGUIs.remove(player.getUniqueId());
    }

    public Optional<BaseGUI> getOpenGUI(Player player) {
        return Optional.ofNullable(openGUIs.get(player.getUniqueId()));
    }

    // ================= CHAT INPUT HANDLING =================
    public boolean isAwaitingInput(UUID uuid) {
        return pendingInputs.containsKey(uuid);
    }

    public void handleChatInput(Player player, String message) {
        InputType type = pendingInputs.get(player.getUniqueId());
        if (type == null) return;

        String msg = message.trim();

        if (msg.equalsIgnoreCase("iptal") || msg.equalsIgnoreCase("cancel")) {
            pendingInputs.remove(player.getUniqueId());
            creationData.remove(player.getUniqueId());
            editingKitId.remove(player.getUniqueId());
            player.sendMessage(MessageUtil.parseWithPrefix("<red>Kit oluÅŸturma iptal edildi.", player));
            return;
        }

        switch (type) {
            case KIT_ID -> {
                // ID validasyonu
                if (!msg.matches("[a-zA-Z0-9_]{2,16}")) {
                    player.sendMessage(MessageUtil.parseWithPrefix("<red>GeÃ§ersiz ID! Sadece harf, rakam, _ ve 2-16 karakter olmalÄ±. Tekrar yaz veya iptal iÃ§in 'iptal' yaz.", player));
                    return;
                }
                if (plugin.getKitManager().getKit(msg).isPresent()) {
                    player.sendMessage(MessageUtil.parseWithPrefix("<red>Bu ID'de zaten kit var: " + msg + " BaÅŸka ID yaz veya iptal yaz.", player));
                    return;
                }
                KitCreationData data = creationData.getOrDefault(player.getUniqueId(), new KitCreationData(null, null, Material.DIAMOND_SWORD, true));
                data.id = msg.toLowerCase(Locale.ROOT);
                creationData.put(player.getUniqueId(), data);
                pendingInputs.put(player.getUniqueId(), InputType.KIT_DISPLAYNAME);
                player.sendMessage(MessageUtil.parseWithPrefix("<gradient:#0A1931:#3B82F6>âœ” ID:</gradient> <white>" + data.id + "</white>", player));
                player.sendMessage(MessageUtil.parseWithPrefix("<#3B82F6>Åimdi kitin gÃ¶rÃ¼nen ismini yaz (MiniMessage destekli). Ã–rnek: <gradient:#0A1931:#3B82F6>Ã–zel Kit</gradient> - Atlamak iÃ§in 'atla' yaz, iptal iÃ§in 'iptal'", player));
            }
            case KIT_DISPLAYNAME -> {
                KitCreationData data = creationData.get(player.getUniqueId());
                if (data == null) {
                    pendingInputs.remove(player.getUniqueId());
                    player.sendMessage(MessageUtil.parseWithPrefix("<red>Oturum bulunamadÄ±, baÅŸtan baÅŸla.", player));
                    return;
                }
                String displayName;
                if (msg.equalsIgnoreCase("atla") || msg.equalsIgnoreCase("skip")) {
                    displayName = "<gradient:#0A1931:#1E3A8A:#3B82F6>" + data.id + "</gradient>";
                } else {
                    displayName = msg;
                }
                data.displayName = displayName;
                creationData.put(player.getUniqueId(), data);
                pendingInputs.remove(player.getUniqueId());

                // Edit mi yeni mi?
                String editId = editingKitId.get(player.getUniqueId());
                if (editId != null) {
                    // Mevcut kiti dÃ¼zenleme - isim deÄŸiÅŸtir
                    plugin.getKitManager().setKitName(editId, displayName);
                    player.sendMessage(MessageUtil.parseWithPrefix("<green>Kit ismi deÄŸiÅŸtirildi: " + displayName, player));
                    editingKitId.remove(player.getUniqueId());
                    creationData.remove(player.getUniqueId());
                    openKitManagementGUI(player);
                } else {
                    // Yeni kit oluÅŸturma aÅŸamasÄ± - GUI aÃ§
                    openKitCreatorConfirmGUI(player, data);
                }
            }
        }
    }

    // ================= ARENA LIST GUI =================
    public void openArenaListGUI(Player player) {
        int rows = plugin.getConfigManager().getArenaListRows();
        int size = rows * 9;
        Component title = MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.arena-list-title"), player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.ARENA_LIST);

        List<Arena> arenas = new ArrayList<>(plugin.getArenaManager().getAllArenas());
        arenas.sort(Comparator.comparing(Arena::getName));
        int availableCount = (int) arenas.stream().filter(Arena::isAvailable).count();

        int slot = 0;
        for (Arena arena : arenas) {
            if (slot >= size - 9) break;
            boolean isDolu = arena.isInUse();
            boolean isDisabled = !arena.isEnabled();
            Material mat = isDolu ? Material.RED_CONCRETE : isDisabled ? Material.GRAY_CONCRETE : arena.isAvailable() ? Material.LIME_CONCRETE : Material.YELLOW_CONCRETE;

            String nameRaw = plugin.getMessagesManager().getRaw("gui.arena-item-name").replace("%arena%", arena.getName());
            List<String> loreRaws = plugin.getMessagesManager().getList("gui.arena-item-lore");
            List<Component> lore = new ArrayList<>();
            String statusRaw = arena.isEnabled() ? plugin.getMessagesManager().getRaw("arena.status-enabled") : plugin.getMessagesManager().getRaw("arena.status-disabled");
            String inuseRaw = arena.isInUse() ? plugin.getMessagesManager().getRaw("arena.inuse-yes") : plugin.getMessagesManager().getRaw("arena.inuse-no");
            for (String l : loreRaws) {
                String replaced = l.replace("%arena%", arena.getName()).replace("%world%", arena.getWorldName() != null ? arena.getWorldName() : "Bilinmiyor").replace("<status>", statusRaw).replace("<inuse>", inuseRaw);
                lore.add(MessageUtil.parse(replaced, player));
            }
            lore.add(Component.empty());
            if (isDolu) {
                lore.add(MessageUtil.parse("<red><bold>âœ˜ DOLU - Åu anda savaÅŸ var!</bold>", player));
                lore.add(MessageUtil.parse("<gray>BoÅŸalana kadar kimse giremez.</gray>", player));
            } else if (isDisabled) {
                lore.add(MessageUtil.parse("<gray>Pasif durumda.</gray>", player));
            } else if (arena.isAvailable()) {
                lore.add(MessageUtil.parse("<green><bold>âœ” BOÅTA</bold>", player));
            } else {
                lore.add(MessageUtil.parse("<yellow>âš  Kurulum eksik", player));
            }
            if (player.hasPermission("duel.admin")) {
                lore.add(Component.empty());
                lore.add(MessageUtil.parse("<dark_gray>SaÄŸ tÄ±k Ä±ÅŸÄ±nlan", player));
            }

            ItemStack item = new ItemBuilder(mat).name(MessageUtil.parse(nameRaw, player)).lore(lore).glowing(arena.isAvailable()).build();
            gui.setItem(slot, item, (p, click) -> {
                if (arena.isInUse()) {
                    p.sendMessage(plugin.getMessagesManager().getPrefixed("arena.in-use"));
                    return;
                }
                if (p.hasPermission("duel.admin") && click.isRightClick() && arena.getSpawn1() != null) p.teleportAsync(arena.getSpawn1());
            });
            slot++;
        }

        if (availableCount == 0 && !arenas.isEmpty()) {
            ItemStack warn = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse("<red><bold>TÃœM ARENALAR DOLU!</bold>", player)).lore(MessageUtil.parse("<gray>Bekleyin.</gray>", player)).build();
            gui.setItem(size - 9 + 1, warn, null);
        }
        ItemStack info = new ItemBuilder(Material.PAPER).name(MessageUtil.parse("<#1E3A8A>Arena Bilgisi", player))
                .lore(MessageUtil.parse("<gray>Toplam: <white>" + arenas.size(), player), MessageUtil.parse("<green>BoÅŸta: <white>" + availableCount, player), MessageUtil.parse("<red>Dolu: <white>" + (arenas.size() - availableCount), player)).build();
        gui.setItem(size - 9 + 3, info, null);

        fillDecorative(gui);
        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), player)).build();
        gui.setItem(size - 5, close, (p, c) -> p.closeInventory());
        gui.open(player);
        registerOpen(player, gui);
    }

    // ================= ADMIN GUI =================
    public void openAdminGUI(Player player) {
        int rows = plugin.getConfigManager().getAdminGuiRows();
        int size = rows * 9;
        Component title = MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.arena-admin-title"), player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.ADMIN_ARENA);

        List<Arena> adminArenas = new ArrayList<>(plugin.getArenaManager().getAllArenas());
        int slot = 0;
        for (Arena arena : adminArenas) {
            if (slot >= size - 9) break;
            boolean isDolu = arena.isInUse();
            Material mat = isDolu ? Material.RED_CONCRETE : Material.PAPER;
            String nameRaw = plugin.getMessagesManager().getRaw("gui.arena-item-name").replace("%arena%", arena.getName());
            List<String> loreRaws = plugin.getMessagesManager().getList("gui.arena-item-lore");
            List<Component> lore = new ArrayList<>();
            String statusRaw = arena.isEnabled() ? plugin.getMessagesManager().getRaw("arena.status-enabled") : plugin.getMessagesManager().getRaw("arena.status-disabled");
            String inuseRaw = arena.isInUse() ? plugin.getMessagesManager().getRaw("arena.inuse-yes") : plugin.getMessagesManager().getRaw("arena.inuse-no");
            for (String l : loreRaws) {
                String replaced = l.replace("%arena%", arena.getName()).replace("%world%", arena.getWorldName() != null ? arena.getWorldName() : "Bilinmiyor").replace("<status>", statusRaw).replace("<inuse>", inuseRaw);
                lore.add(MessageUtil.parse(replaced, player));
            }
            lore.add(Component.empty());
            if (isDolu) lore.add(MessageUtil.parse("<red><bold>âœ˜ DOLU - DÃ¼zenlenemez!</bold>", player));
            else {
                lore.add(MessageUtil.parse("<yellow>Sol: Pos1, SaÄŸ: Pos2", player));
                lore.add(MessageUtil.parse("<yellow>Shift+Sol: Enable/Disable, Shift+SaÄŸ: Sil", player));
            }
            ItemStack item = new ItemBuilder(mat).name(MessageUtil.parse(nameRaw, player)).lore(lore).build();
            gui.setItem(slot, item, (p, click) -> {
                if (arena.isInUse()) {
                    p.sendMessage(plugin.getMessagesManager().getPrefixed("arena.in-use"));
                    return;
                }
                if (click.isShiftClick() && click.isRightClick()) {
                    if (plugin.getArenaManager().deleteArena(arena.getName())) {
                        p.sendMessage(plugin.getMessagesManager().getPrefixed("arena.deleted", "%arena%", arena.getName()));
                        p.closeInventory();
                        openAdminGUI(p);
                    }
                    return;
                }
                if (click.isShiftClick() && click.isLeftClick()) {
                    if (arena.isEnabled()) arena.setEnabled(false);
                    else {
                        if (!arena.isSetup()) {
                            p.sendMessage(plugin.getMessagesManager().getPrefixed("arena.not-setup"));
                            return;
                        }
                        arena.setEnabled(true);
                    }
                    plugin.getArenaManager().saveArena(arena);
                    p.closeInventory();
                    openAdminGUI(p);
                    return;
                }
                if (click.isLeftClick()) {
                    arena.setSpawn1(p.getLocation());
                    plugin.getArenaManager().saveArena(arena);
                    p.sendMessage(plugin.getMessagesManager().getPrefixed("arena.pos1-set", "%arena%", arena.getName(), "%world%", p.getWorld().getName(), "%x%", String.format("%.1f", p.getLocation().getX()), "%y%", String.format("%.1f", p.getLocation().getY()), "%z%", String.format("%.1f", p.getLocation().getZ())));
                } else if (click.isRightClick()) {
                    arena.setSpawn2(p.getLocation());
                    plugin.getArenaManager().saveArena(arena);
                    p.sendMessage(plugin.getMessagesManager().getPrefixed("arena.pos2-set", "%arena%", arena.getName(), "%world%", p.getWorld().getName(), "%x%", String.format("%.1f", p.getLocation().getX()), "%y%", String.format("%.1f", p.getLocation().getY()), "%z%", String.format("%.1f", p.getLocation().getZ())));
                }
            });
            slot++;
        }
        fillDecorative(gui);
        ItemStack create = new ItemBuilder(Material.EMERALD_BLOCK).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.admin-create-name"), player)).lore(MessageUtil.parse("<gray>/duel create <arena>", player)).glowing(true).build();
        gui.setItem(size - 6, create, (p, c) -> {
            p.closeInventory();
            p.sendMessage(plugin.getMessagesManager().getPrefixed("invalid-usage", "<usage>", "/duel create <arena>"));
        });
        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), player)).build();
        gui.setItem(size - 5, close, (p, c) -> p.closeInventory());
        gui.open(player);
        registerOpen(player, gui);
    }

    // ================= DUEL SETUP GUI (INVITE) =================
    public void openDuelSetupGUI(Player requester, Player target) {
        int size = 45;
        Component title = MessageUtil.parse("<black>DÃ¼ello Kur - " + target.getName(), requester);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.DUEL_SETUP);

        String selectedArena = plugin.getDuelManager().getArenaPreference(requester.getUniqueId()).orElse("Rastgele");
        String selectedKit = plugin.getDuelManager().getKitPreference(requester.getUniqueId());
        fillDecorative(gui);

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(target);
            meta.displayName(MessageUtil.parse("<#3B82F6>" + target.getName(), requester));
            meta.lore(List.of(MessageUtil.parse("<gray>Rakip: <white>" + target.getName(), requester)));
            head.setItemMeta(meta);
        }
        gui.setItem(13, head, null);

        var kitOpt = plugin.getKitManager().getKit(selectedKit);
        Kit currentKit = kitOpt.orElse(plugin.getKitManager().getKitOrDefault("own"));
        List<Component> kitLore = new ArrayList<>(currentKit.getLore());
        kitLore.add(Component.empty());
        kitLore.add(MessageUtil.parse("<#3B82F6>TÄ±klayarak kit seÃ§!", requester));
        kitLore.add(MessageUtil.parse("<gray>Åu anki: <white>" + currentKit.getId(), requester));
        ItemStack kitItem = new ItemBuilder(currentKit.getIcon()).name(Component.empty().append(currentKit.getDisplayName()).append(MessageUtil.parse(" <gray>[SeÃ§ili]", requester))).lore(kitLore).glowing(true).build();
        gui.setItem(21, kitItem, (p, click) -> openKitSelectionGUI(p, target));

        Material arenaMat = selectedArena.equalsIgnoreCase("Rastgele") || selectedArena.equalsIgnoreCase("RANDOM") ? Material.COMPASS : Material.GRASS_BLOCK;
        List<Component> arenaLore = new ArrayList<>();
        arenaLore.add(MessageUtil.parse("<gray>SeÃ§im: <white>" + selectedArena, requester));
        arenaLore.add(Component.empty());
        arenaLore.add(MessageUtil.parse("<gray>Toplam: <white>" + plugin.getArenaManager().getTotalCount(), requester));
        arenaLore.add(MessageUtil.parse("<green>BoÅŸta: <white>" + plugin.getArenaManager().getAvailableCount(), requester));
        arenaLore.add(MessageUtil.parse("<red>Dolu: <white>" + (plugin.getArenaManager().getTotalCount() - plugin.getArenaManager().getAvailableCount()), requester));
        arenaLore.add(Component.empty());
        arenaLore.add(MessageUtil.parse("<#3B82F6>TÄ±kla ve arena seÃ§!", requester));
        ItemStack arenaItem = new ItemBuilder(arenaMat).name(MessageUtil.parse("<#3B82F6>Arena SeÃ§: <white>" + selectedArena, requester)).lore(arenaLore).glowing(true).build();
        gui.setItem(22, arenaItem, (p, click) -> openArenaSelectionGUI(p, target));

        boolean betEnabled = plugin.getDuelManager().getBetPreference(requester.getUniqueId());
        List<Component> betLore = List.of(
                MessageUtil.parse("<gray>Åu an: " + (betEnabled ? "<green>AÃ§Ä±k" : "<red>KapalÄ±"), requester),
                Component.empty(),
                MessageUtil.parse("<yellow>TÄ±kla ve deÄŸiÅŸtir!", requester)
        );
        ItemStack settings = new ItemBuilder(Material.DROPPER)
                .name(MessageUtil.parse("<#1E3A8A>EÅŸya Bahisi: " + (betEnabled ? "<green>AÃ§Ä±k" : "<red>KapalÄ±"), requester))
                .lore(betLore)
                .glowing(betEnabled)
                .build();
        gui.setItem(23, settings, (p, c) -> {
            boolean current = plugin.getDuelManager().getBetPreference(p.getUniqueId());
            plugin.getDuelManager().setBetPreference(p.getUniqueId(), !current);
            openDuelSetupGUI(p, target);
        });

        List<Component> confirmLore = List.of(
                MessageUtil.parse("<gray>Rakip: <white>" + target.getName(), requester),
                MessageUtil.parse("<gray>Arena: <white>" + selectedArena, requester),
                MessageUtil.parse("<gray>Kit: <white>" + currentKit.getId(), requester),
                Component.empty(),
                MessageUtil.parse("<green><bold>TÄ±kla ve istek gÃ¶nder!</bold>", requester)
        );
        ItemStack confirm = new ItemBuilder(Material.LIME_CONCRETE).name(MessageUtil.parse("<green><bold>âœ” Ä°stek GÃ¶nder</bold>", requester)).lore(confirmLore).glowing(true).build();
        gui.setItem(30, confirm, (p, click) -> {
            p.closeInventory();
            var result = plugin.getDuelManager().sendRequest(p, target);
            if (result.result != com.Auraduel.duel.DuelManager.RequestResult.SUCCESS) {
                var mm = plugin.getMessagesManager();
                switch (result.result) {
                    case ALREADY_IN_DUEL -> p.sendMessage(mm.getPrefixed("duel.already-in-duel"));
                    case TARGET_ALREADY_IN_DUEL -> p.sendMessage(mm.getPrefixed("duel.target-already-in-duel", "%target%", target.getName()));
                    case ALREADY_SENT -> p.sendMessage(mm.getPrefixed("duel.already-sent-request"));
                    case TARGET_HAS_PENDING -> p.sendMessage(mm.getPrefixed("duel.target-has-pending", "%target%", target.getName()));
                    case SELF -> p.sendMessage(mm.getPrefixed("duel.self-request"));
                    case OFFLINE -> p.sendMessage(mm.getPrefixed("duel.offline-target", "%target%", target.getName()));
                    default -> {}
                }
            }
        });

        ItemStack cancel = new ItemBuilder(Material.RED_CONCRETE).name(MessageUtil.parse("<red><bold>âœ˜ Ä°ptal</bold>", requester)).build();
        gui.setItem(32, cancel, (p, click) -> p.closeInventory());

        gui.open(requester);
        registerOpen(requester, gui);
    }

    // ================= ARENA SELECTION GUI =================
    public void openArenaSelectionGUI(Player requester, Player target) {
        int size = 54;
        Component title = MessageUtil.parse("<black>Arena SeÃ§", requester);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.ARENA_SELECT);

        List<Arena> arenas = new ArrayList<>(plugin.getArenaManager().getAllArenas());
        arenas.sort(Comparator.comparing(Arena::isAvailable).reversed().thenComparing(Arena::getName));

        ItemStack random = new ItemBuilder(Material.COMPASS).name(MessageUtil.parse("<gradient:#0A1931:#3B82F6:#60A5FA>ğŸ² Rastgele Arena</gradient>", requester))
                .lore(MessageUtil.parse("<gray>BoÅŸta olanlardan otomatik seÃ§ilir", requester), MessageUtil.parse("<green>Ã–nerilen!", requester), Component.empty(), MessageUtil.parse("<gray>BoÅŸta: <white>" + plugin.getArenaManager().getAvailableCount(), requester)).glowing(true).build();
        gui.setItem(4, random, (p, click) -> {
            plugin.getDuelManager().setArenaPreference(p.getUniqueId(), "RANDOM");
            p.sendMessage(MessageUtil.parseWithPrefix("<green>Rastgele arena seÃ§ildi!", p));
            openDuelSetupGUI(p, target);
        });

        int slot = 9;
        for (Arena arena : arenas) {
            if (slot >= size - 9) break;
            boolean isDolu = arena.isInUse();
            boolean isDisabled = !arena.isEnabled();
            Material mat = isDolu ? Material.RED_CONCRETE : isDisabled ? Material.GRAY_CONCRETE : arena.isAvailable() ? Material.LIME_CONCRETE : Material.YELLOW_CONCRETE;

            String nameRaw = plugin.getMessagesManager().getRaw("gui.arena-item-name").replace("%arena%", arena.getName());
            List<Component> lore = new ArrayList<>();
            String statusRaw = arena.isEnabled() ? plugin.getMessagesManager().getRaw("arena.status-enabled") : plugin.getMessagesManager().getRaw("arena.status-disabled");
            String inuseRaw = arena.isInUse() ? plugin.getMessagesManager().getRaw("arena.inuse-yes") : plugin.getMessagesManager().getRaw("arena.inuse-no");
            for (String l : plugin.getMessagesManager().getList("gui.arena-item-lore")) {
                String replaced = l.replace("%arena%", arena.getName()).replace("%world%", arena.getWorldName() != null ? arena.getWorldName() : "Bilinmiyor").replace("<status>", statusRaw).replace("<inuse>", inuseRaw);
                lore.add(MessageUtil.parse(replaced, requester));
            }
            lore.add(Component.empty());
            if (isDolu) {
                lore.add(MessageUtil.parse("<red><bold>âœ˜ DOLU - SeÃ§ilemez!</bold>", requester));
                lore.add(MessageUtil.parse("<gray>Ä°Ã§inde dÃ¼ello var.</gray>", requester));
            } else if (isDisabled) lore.add(MessageUtil.parse("<gray>Pasif - Admin aktif etmeli", requester));
            else if (arena.isAvailable()) {
                lore.add(MessageUtil.parse("<green><bold>âœ” BOÅTA - SeÃ§ilebilir!</bold>", requester));
                lore.add(MessageUtil.parse("<yellow>TÄ±kla ve seÃ§", requester));
            } else lore.add(MessageUtil.parse("<yellow>âš  Kurulum eksik", requester));

            ItemStack item = new ItemBuilder(mat).name(MessageUtil.parse(nameRaw, requester)).lore(lore).glowing(arena.isAvailable()).build();
            gui.setItem(slot, item, (p, click) -> {
                if (arena.isInUse() || !arena.isEnabled() || !arena.isSetup()) {
                    p.sendMessage(MessageUtil.parseWithPrefix("<red>Bu arena seÃ§ilemez! Dolu/pasif/eksik.", p));
                    return;
                }
                plugin.getDuelManager().setArenaPreference(p.getUniqueId(), arena.getName());
                p.sendMessage(MessageUtil.parseWithPrefix("<green>Arena seÃ§ildi: " + arena.getName(), p));
                openDuelSetupGUI(p, target);
            });
            slot++;
        }

        fillDecorative(gui);
        ItemStack back = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<yellow>â—€ Geri", requester)).build();
        gui.setItem(size - 6, back, (p, c) -> openDuelSetupGUI(p, target));
        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), requester)).build();
        gui.setItem(size - 5, close, (p, c) -> p.closeInventory());
        gui.open(requester);
        registerOpen(requester, gui);
    }

    // ================= KIT SELECTION GUI (DÃ¼ello iÃ§in) - SAYFALAMA + PERMISSION + DURUM =================
    public void openKitSelectionGUI(Player requester, Player target) {
        int page = kitSelectionPage.getOrDefault(requester.getUniqueId(), 0);
        openKitSelectionGUI(requester, target, page);
    }

    public void openKitSelectionGUI(Player requester, Player target, int page) {
        int size = 54;
        Component title = MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.kit-select-title") + " <gray>[" + (page + 1) + "]", requester);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.KIT_SELECT);

        var allKits = new ArrayList<>(plugin.getKitManager().getEnabledKits());
        allKits.sort(Comparator.comparingInt(Kit::getOrder).thenComparing(Kit::getId));

        int kitsPerPage = 28;
        int totalPages = (int) Math.ceil((double) allKits.size() / kitsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages && totalPages > 0) page = totalPages - 1;
        final int finalPage = page;
        kitSelectionPage.put(requester.getUniqueId(), finalPage);

        int start = finalPage * kitsPerPage;
        int end = Math.min(start + kitsPerPage, allKits.size());
        List<Kit> pageKits = allKits.subList(start, end);

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        int idx = 0;
        for (Kit kit : pageKits) {
            if (idx >= slots.length) break;
            int slot = slots[idx];

            boolean selected = plugin.getDuelManager().getKitPreference(requester.getUniqueId()).equalsIgnoreCase(kit.getId());
            boolean hasPerm = requester.hasPermission(kit.getPermission()) || requester.hasPermission("duel.kit.*") || requester.hasPermission("duel.admin") || kit.getId().equals("own");
            boolean enabled = kit.isEnabled();

            List<Component> lore = new ArrayList<>(kit.getLore());
            lore.add(Component.empty());
            if (!enabled) {
                lore.add(MessageUtil.parse("<red><bold>âœ˜ Pasif - SeÃ§ilemez!</bold>", requester));
            } else if (!hasPerm) {
                lore.add(MessageUtil.parse("<red><bold>âœ˜ Yetkin yok!</bold>", requester));
            } else if (selected) {
                lore.add(MessageUtil.parse("<green><bold>âœ” Åu an seÃ§ili!</bold>", requester));
            } else {
                lore.add(MessageUtil.parse("<green><bold>âœ” SeÃ§mek iÃ§in tÄ±kla!</bold>", requester));
            }

            Material mat = kit.getIcon();
            if (!enabled) mat = Material.GRAY_CONCRETE;
            else if (!hasPerm) mat = Material.BARRIER;

            ItemStack item = new ItemBuilder(mat).name(kit.getDisplayName()).lore(lore).glowing(selected && hasPerm && enabled).build();
            gui.setItem(slot, item, (p, click) -> {
                if (!kit.isEnabled()) {
                    p.sendMessage(MessageUtil.parseWithPrefix("<red>Bu kit pasif!", p));
                    return;
                }
                if (!hasPerm) {
                    p.sendMessage(MessageUtil.parseWithPrefix("<red>Bu kiti seÃ§mek iÃ§in iznin yok! <white>" + kit.getPermission(), p));
                    return;
                }
                plugin.getDuelManager().setKitPreference(p.getUniqueId(), kit.getId());
                p.sendMessage(MessageUtil.parseWithPrefix("<green>Kit seÃ§ildi: <white>" + kit.getId() + " <gray>(" + kit.getPermission() + ")", p));
                openDuelSetupGUI(p, target);
            });
            idx++;
        }

        fillDecorative(gui);

        if (finalPage > 0) {
            ItemStack prev = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<#1E3A8A>â—€ Ã–nceki Sayfa (" + finalPage + ")", requester)).build();
            gui.setItem(45, prev, (p, c) -> openKitSelectionGUI(p, target, finalPage - 1));
        }
        if (finalPage < totalPages - 1) {
            ItemStack next = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<#1E3A8A>Sonraki Sayfa â–¶ (" + (finalPage + 2) + ")", requester)).build();
            gui.setItem(53, next, (p, c) -> openKitSelectionGUI(p, target, finalPage + 1));
        }

        ItemStack back = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<yellow>â—€ Geri - DÃ¼ello Kur", requester)).build();
        gui.setItem(48, back, (p, c) -> openDuelSetupGUI(p, target));
        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), requester)).build();
        gui.setItem(49, close, (p, c) -> p.closeInventory());

        gui.open(requester);
        registerOpen(requester, gui);
    }

    // ================= KIT MANAGEMENT GUI (Admin, Her ÅŸey GUI ile Kit Ekleme) + SAYFALAMA =================
    public void openKitManagementGUI(Player player) {
        int page = kitManagementPage.getOrDefault(player.getUniqueId(), 0);
        openKitManagementGUI(player, page);
    }

    public void openKitManagementGUI(Player player, int page) {
        int size = 54;
        Component title = MessageUtil.parse(plugin.getMessagesManager().getRaw("kit.list-title").replace("%count%", String.valueOf(plugin.getKitManager().getCount())) + " <gray>[" + (page + 1) + "]", player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.KIT_SELECT);

        var allKits = new ArrayList<>(plugin.getKitManager().getAllKits());
        allKits.sort(Comparator.comparing(Kit::getOrder).thenComparing(Kit::getId));

        int kitsPerPage = 28;
        int totalPages = (int) Math.ceil((double) allKits.size() / kitsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages && totalPages > 0) page = totalPages - 1;
        final int finalPage = page;
        kitManagementPage.put(player.getUniqueId(), finalPage);

        int start = finalPage * kitsPerPage;
        int end = Math.min(start + kitsPerPage, allKits.size());
        List<Kit> pageKits = allKits.subList(start, end);

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        int idx = 0;
        for (Kit kit : pageKits) {
            if (idx >= slots.length) break;
            int slot = slots[idx];
            List<Component> lore = new ArrayList<>(kit.getLore());
            lore.add(Component.empty());
            lore.add(MessageUtil.parse("<#1E3A8A>ID: <white>" + kit.getId(), player));
            lore.add(MessageUtil.parse("<#1E3A8A>Icon: <white>" + kit.getIcon().name(), player));
            lore.add(MessageUtil.parse("<#1E3A8A>Slot: <white>" + (kit.getGuiSlot() == -1 ? "Oto" : kit.getGuiSlot()), player));
            lore.add(MessageUtil.parse("<#1E3A8A>Perm: <white>" + kit.getPermission(), player));
            lore.add(MessageUtil.parse("<#1E3A8A>Enabled: <white>" + kit.isEnabled() + " <gray>SÄ±ra: <white>" + kit.getOrder(), player));
            lore.add(MessageUtil.parse("<#1E3A8A>EÅŸya: <white>" + kit.getItems().size() + " <gray>+ ZÄ±rh: <white>" + kit.getArmor().size(), player));
            lore.add(Component.empty());
            lore.add(MessageUtil.parse("<yellow>Sol tÄ±k: <white>DÃ¼zenle (tÃ¼m NBT)", player));
            lore.add(MessageUtil.parse("<yellow>SaÄŸ tÄ±k: <white>Icon yap (elindeki)", player));
            if (!kit.getId().equals("own")) lore.add(MessageUtil.parse("<red>Shift+SaÄŸ: <white>Sil (kits.yml)", player));
            lore.add(MessageUtil.parse("<dark_gray>Database: kits.yml - kalÄ±cÄ±", player));

            ItemStack item = new ItemBuilder(kit.getIcon()).name(kit.getDisplayName()).lore(lore).glowing(kit.getId().equals("own") || kit.isEnabled()).build();
            gui.setItem(slot, item, (p, click) -> {
                if (click.isShiftClick() && click.isRightClick()) {
                    if (kit.getId().equals("own")) {
                        p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.cannot-delete-own"));
                        return;
                    }
                    boolean deleted = plugin.getKitManager().deleteKit(kit.getId());
                    if (deleted) {
                        p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.deleted", "%kit%", kit.getId()));
                        p.closeInventory();
                        openKitManagementGUI(p, finalPage);
                    }
                    return;
                }
                if (click.isRightClick()) {
                    var hand = p.getInventory().getItemInMainHand();
                    if (hand != null && hand.getType() != Material.AIR) {
                        plugin.getKitManager().setKitIcon(kit.getId(), hand.getType());
                        p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.set-icon", "%kit%", kit.getId(), "%icon%", hand.getType().name()));
                        p.closeInventory();
                        openKitManagementGUI(p, finalPage);
                    } else {
                        p.sendMessage(MessageUtil.parseWithPrefix("<red>Elinde bir eÅŸya tut!", p));
                    }
                    return;
                }
                if (click.isLeftClick()) {
                    openKitEditorGUI(p, kit);
                }
            });
            idx++;
        }

        fillDecorative(gui);

        // Sayfalama butonlarÄ±
        if (finalPage > 0) {
            ItemStack prev = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<#1E3A8A>â—€ Ã–nceki Sayfa (" + finalPage + ")", player)).lore(MessageUtil.parse("<gray>Sayfa: " + (finalPage) + "/" + totalPages, player)).build();
            gui.setItem(45, prev, (p, c) -> openKitManagementGUI(p, finalPage - 1));
        }
        if (finalPage < totalPages - 1) {
            ItemStack next = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<#1E3A8A>Sonraki Sayfa â–¶ (" + (finalPage + 2) + ")", player)).lore(MessageUtil.parse("<gray>Sayfa: " + (finalPage + 2) + "/" + totalPages, player)).build();
            gui.setItem(53, next, (p, c) -> openKitManagementGUI(p, finalPage + 1));
        }

        ItemStack create = new ItemBuilder(Material.EMERALD_BLOCK).name(MessageUtil.parse("<gradient:#0A1931:#1E3A8A:#3B82F6>â• Yeni Kit OluÅŸtur (GUI)</gradient>", player))
                .lore(
                        MessageUtil.parse("<gray>TÄ±kla ve envanterindeki eÅŸyalardan", player),
                        MessageUtil.parse("<gray>yeni kit oluÅŸtur. <white>kits.yml'e</white> kaydedilir.", player),
                        Component.empty(),
                        MessageUtil.parse("<yellow>1. TÄ±kla -> ID yaz (chat)", player),
                        MessageUtil.parse("<yellow>2. Ä°sim yaz (MiniMessage - kapalÄ± mavi)", player),
                        MessageUtil.parse("<yellow>3. Ä°kon otomatik elindeki item", player),
                        MessageUtil.parse("<yellow>4. Kaydedilir ve restartta gitmez", player),
                        Component.empty(),
                        MessageUtil.parse("<dark_gray>BoÅŸ slot yok, dekoratif cam dolu", player)
                ).glowing(true).build();
        gui.setItem(49, create, (p, click) -> {
            p.closeInventory();
            startKitCreationFlow(p);
        });

        ItemStack info = new ItemBuilder(Material.PAPER).name(MessageUtil.parse("<#1E3A8A>Kit Database Bilgisi", player))
                .lore(
                        MessageUtil.parse("<gray>Toplam: <white>" + allKits.size() + " <gray>Sayfa: <white>" + (page + 1) + "/" + totalPages, player),
                        MessageUtil.parse("<gray>Dosya: <white>kits.yml", player),
                        MessageUtil.parse("<gray>Konum: <white>plugins/AuraDuel/kits.yml", player),
                        MessageUtil.parse("<green>KalÄ±cÄ±! Restartta silinmez.", player)
                )
                .build();
        gui.setItem(48, info, null);

        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), player)).build();
        gui.setItem(49 + 4, close, (p, c) -> p.closeInventory());

        gui.open(player);
        registerOpen(player, gui);
    }

    // Kit oluÅŸturma akÄ±ÅŸÄ±nÄ± baÅŸlat - chat ile ID ister
    public void startKitCreationFlow(Player player) {
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        creationData.put(player.getUniqueId(), new KitCreationData(null, null, Material.DIAMOND_SWORD, true));
        pendingInputs.put(player.getUniqueId(), InputType.KIT_ID);
        player.sendMessage(MessageUtil.parseWithPrefix("<gradient:#0A1931:#3B82F6>â• Yeni Kit OluÅŸturma</gradient>", player));
        player.sendMessage(MessageUtil.parseWithPrefix("<#3B82F6>â–¸ <gray>LÃ¼tfen kit iÃ§in <white>ID</white> yazÄ±n (Ã¶rnek: <white>mykit</white>). Sadece harf, rakam, _. Ä°ptal iÃ§in <white>iptal</white> yaz.", player));
        player.sendMessage(MessageUtil.parseWithPrefix("<gray>Envanterindeki eÅŸyalar kit olarak kaydedilecek ve <white>kits.yml</white> database'ine yazÄ±lacak (restartta gitmez).", player));
    }

    // Kit oluÅŸturma son adÄ±m GUI - icon ve kaydetme
    public void openKitCreatorConfirmGUI(Player player, KitCreationData data) {
        int size = 27;
        Component title = MessageUtil.parse("<black>Kit OluÅŸtur: " + data.id, player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.KIT_SELECT);

        fillDecorative(gui);

        ItemStack icon = new ItemBuilder(data.icon != null ? data.icon : Material.DIAMOND_SWORD)
                .name(MessageUtil.parse("<#3B82F6>Icon: <white>" + (data.icon != null ? data.icon.name() : "DIAMOND_SWORD"), player))
                .lore(
                        MessageUtil.parse("<gray>Åu anki icon", player),
                        MessageUtil.parse("<yellow>TÄ±kla ve elindeki eÅŸyayÄ± icon yap", player)
                )
                .build();
        gui.setItem(11, icon, (p, click) -> {
            var hand = p.getInventory().getItemInMainHand();
            if (hand != null && hand.getType() != Material.AIR) {
                data.icon = hand.getType();
                creationData.put(p.getUniqueId(), data);
                p.sendMessage(MessageUtil.parseWithPrefix("<green>Icon gÃ¼ncellendi: " + hand.getType().name(), p));
                openKitCreatorConfirmGUI(p, data);
            }
        });

        ItemStack idItem = new ItemBuilder(Material.PAPER)
                .name(MessageUtil.parse("<#1E3A8A>ID: <white>" + data.id, player))
                .lore(MessageUtil.parse("<gray>Kit ID'si", player))
                .build();
        gui.setItem(12, idItem, null);

        ItemStack nameItem = new ItemBuilder(Material.NAME_TAG)
                .name(MessageUtil.parse(data.displayName != null ? data.displayName : "<white>" + data.id, player))
                .lore(
                        MessageUtil.parse("<gray>GÃ¶rÃ¼nen isim (MiniMessage)", player),
                        MessageUtil.parse("<yellow>TÄ±kla ve ismi tekrar deÄŸiÅŸtir (chat)", player)
                )
                .build();
        gui.setItem(13, nameItem, (p, click) -> {
            editingKitId.put(p.getUniqueId(), data.id);
            pendingInputs.put(p.getUniqueId(), InputType.KIT_DISPLAYNAME);
            creationData.put(p.getUniqueId(), data);
            p.closeInventory();
            p.sendMessage(MessageUtil.parseWithPrefix("<#3B82F6>Yeni gÃ¶rÃ¼nen ismi chat'e yaz (MiniMessage). Ã–rnek: <gradient:#0A1931:#3B82F6>Ã–zel Kit</gradient> Atlamak iÃ§in 'atla'", p));
        });

        ItemStack preview = new ItemBuilder(Material.CHEST)
                .name(MessageUtil.parse("<#1E3A8A>Envanter Ã–nizleme", player))
                .lore(
                        MessageUtil.parse("<gray>Kaydedilecek eÅŸya sayÄ±sÄ±: <white>" + (player.getInventory().getContents().length), player),
                        MessageUtil.parse("<gray>Elindeki envanter kit olarak kaydedilecek", player)
                )
                .build();
        gui.setItem(14, preview, null);

        ItemStack save = new ItemBuilder(Material.LIME_CONCRETE)
                .name(MessageUtil.parse("<green><bold>âœ” Kaydet (Database: kits.yml)</bold>", player))
                .lore(
                        MessageUtil.parse("<gray>ID: <white>" + data.id, player),
                        MessageUtil.parse("<gray>Isim: " + (data.displayName != null ? data.displayName : data.id), player),
                        MessageUtil.parse("<gray>Icon: <white>" + data.icon, player),
                        Component.empty(),
                        MessageUtil.parse("<green>Kaydet ve kits.yml'e yaz! Restartta gitmez.", player)
                )
                .glowing(true)
                .build();
        gui.setItem(15, save, (p, click) -> {
            // Elindeki envanterden kit oluÅŸtur, ama displayName ve icon'u data'dan al
            boolean created = plugin.getKitManager().createKitFromPlayer(data.id, p);
            if (created) {
                // displayName ve icon gÃ¼ncelle
                if (data.displayName != null) plugin.getKitManager().setKitName(data.id, data.displayName);
                if (data.icon != null) plugin.getKitManager().setKitIcon(data.id, data.icon);
                p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.created", "%kit%", data.id));
                creationData.remove(p.getUniqueId());
                pendingInputs.remove(p.getUniqueId());
                p.closeInventory();
                openKitManagementGUI(p);
            } else {
                p.sendMessage(MessageUtil.parseWithPrefix("<red>Kit oluÅŸturulamadÄ±, ID zaten var olabilir.", p));
            }
        });

        ItemStack cancel = new ItemBuilder(Material.RED_CONCRETE).name(MessageUtil.parse("<red><bold>âœ˜ Ä°ptal</bold>", player)).build();
        gui.setItem(26 - 5, cancel, (p, c) -> {
            creationData.remove(p.getUniqueId());
            pendingInputs.remove(p.getUniqueId());
            p.closeInventory();
            openKitManagementGUI(p);
        });

        gui.open(player);
        registerOpen(player, gui);
    }

    // Kit dÃ¼zenleme GUI'si
    public void openKitEditorGUI(Player player, Kit kit) {
        int size = 27;
        Component title = MessageUtil.parse("<black>Kit DÃ¼zenle: " + kit.getId(), player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.KIT_SELECT);

        fillDecorative(gui);

        ItemStack icon = new ItemBuilder(kit.getIcon())
                .name(MessageUtil.parse("<#3B82F6>Icon: <white>" + kit.getIcon().name(), player))
                .lore(MessageUtil.parse("<yellow>TÄ±kla ve elindeki eÅŸyayÄ± icon yap", player))
                .build();
        gui.setItem(10, icon, (p, click) -> {
            var hand = p.getInventory().getItemInMainHand();
            if (hand != null && hand.getType() != Material.AIR) {
                plugin.getKitManager().setKitIcon(kit.getId(), hand.getType());
                p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.set-icon", "%kit%", kit.getId(), "%icon%", hand.getType().name()));
                p.closeInventory();
                openKitEditorGUI(p, plugin.getKitManager().getKit(kit.getId()).orElse(kit));
            }
        });

        ItemStack nameItem = new ItemBuilder(Material.NAME_TAG)
                .name(kit.getDisplayName())
                .lore(MessageUtil.parse("<gray>ID: <white>" + kit.getId(), player), MessageUtil.parse("<yellow>TÄ±kla ve ismi deÄŸiÅŸtir (chat)", player))
                .build();
        gui.setItem(12, nameItem, (p, click) -> {
            editingKitId.put(p.getUniqueId(), kit.getId());
            pendingInputs.put(p.getUniqueId(), InputType.KIT_DISPLAYNAME);
            p.closeInventory();
            p.sendMessage(MessageUtil.parseWithPrefix("<#3B82F6>Mevcut kit <white>" + kit.getId() + "</white> iÃ§in yeni ismi chat'e yaz (MiniMessage). Ã–rnek: <gradient:#0A1931:#3B82F6>Yeni Ä°sim</gradient>", p));
        });

        ItemStack updateItems = new ItemBuilder(Material.CHEST)
                .name(MessageUtil.parse("<#1E3A8A>Envanteri GÃ¼ncelle (TÃ¼m NBT)", player))
                .lore(
                        MessageUtil.parse("<gray>TÄ±kla ve ÅŸu anki envanterini bu kite kaydet", player),
                        MessageUtil.parse("<gray>Inventory, Hotbar, Armor, OffHand", player),
                        MessageUtil.parse("<gray>Enchant, Lore, NBT, Attribute, PotionMeta...", player),
                        MessageUtil.parse("<gray>kits.yml gÃ¼ncellenir, restartta gitmez", player)
                )
                .build();
        gui.setItem(14, updateItems, (p, click) -> {
            Kit targetKit = plugin.getKitManager().getKit(kit.getId()).orElse(null);
            if (targetKit != null) {
                targetKit.setInventoryFromPlayer(p);
                plugin.getKitManager().saveKit(targetKit);
                p.sendMessage(MessageUtil.parseWithPrefix("<green>Kit eÅŸyalarÄ± gÃ¼ncellendi ve kits.yml'e kaydedildi! HiÃ§bir veri kaybolmadÄ±.", p));
                p.closeInventory();
                openKitEditorGUI(p, targetKit);
            }
        });

        ItemStack delete = new ItemBuilder(Material.BARRIER)
                .name(MessageUtil.parse("<red><bold>Sil</bold>", player))
                .lore(MessageUtil.parse("<gray>Kiti database'den sil", player))
                .build();
        gui.setItem(16, delete, (p, click) -> {
            if (kit.getId().equals("own")) {
                p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.cannot-delete-own"));
                return;
            }
            boolean deleted = plugin.getKitManager().deleteKit(kit.getId());
            if (deleted) {
                p.sendMessage(plugin.getMessagesManager().getPrefixed("kit.deleted", "%kit%", kit.getId()));
                p.closeInventory();
                openKitManagementGUI(p);
            }
        });

        ItemStack back = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<yellow>â—€ Geri", player)).build();
        gui.setItem(size - 6, back, (p, c) -> openKitManagementGUI(p));
        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), player)).build();
        gui.setItem(size - 5, close, (p, c) -> p.closeInventory());

        gui.open(player);
        registerOpen(player, gui);
    }

    // ================= DUEL CONFIRM GUI =================
    public void openConfirmGUI(Player player, DuelRequest request, Player requester) {
        int size = 27;
        Component title = MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.duel-confirm-title"), player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.DUEL_CONFIRM);
        fillDecorative(gui);

        String arenaPref = plugin.getDuelManager().getArenaPreference(requester.getUniqueId()).orElse("Rastgele");
        String kitPref = plugin.getDuelManager().getKitPreference(requester.getUniqueId());

        ItemStack accept = new ItemBuilder(Material.GREEN_WOOL).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.confirm-accept-name"), player))
                .lore(MessageUtil.parse("<gray>" + requester.getName() + " ile dÃ¼ello", player), MessageUtil.parse("<gray>Arena: <white>" + arenaPref, player), MessageUtil.parse("<gray>Kit: <white>" + kitPref, player), Component.empty(), MessageUtil.parse("<green>Kabul et!", player)).glowing(true).build();
        gui.setItem(11, accept, (p, click) -> {
            p.closeInventory();
            plugin.getDuelManager().acceptRequest(p);
        });

        ItemStack deny = new ItemBuilder(Material.RED_WOOL).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.confirm-deny-name"), player)).lore(MessageUtil.parse("<gray>Reddet", player)).build();
        gui.setItem(15, deny, (p, click) -> {
            p.closeInventory();
            plugin.getDuelManager().denyRequest(p);
        });

        ItemStack info = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) info.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(requester);
            meta.displayName(MessageUtil.parse("<#3B82F6>" + requester.getName(), player));
            meta.lore(List.of(MessageUtil.parse("<gray>SÃ¼re: <white>" + request.getRemainingSeconds() + "s", player), MessageUtil.parse("<gray>Arena: <white>" + arenaPref, player), MessageUtil.parse("<gray>Kit: <white>" + kitPref, player)));
            info.setItemMeta(meta);
        }
        gui.setItem(13, info, null);
        gui.open(player);
        registerOpen(player, gui);
    }

    private void fillDecorative(BaseGUI gui) {
        if (!plugin.getConfigManager().isDecorativeGlass()) return;
        Material glass = plugin.getConfigManager().getGlassMaterial();
        ItemStack filler = new ItemBuilder(glass).name(Component.empty()).build();
        Inventory inv = gui.getInventory();
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) gui.setItem(i, filler, null);
    }

    // ================= AYARLAR GUI - CONFIG YML YERÄ°NE TIKLA AÃ‡/KAPAT =================
    public void openGlobalSettingsGUI(Player player) {
        int size = 54;
        Component title = MessageUtil.parse("<black>DÃ¼ello AyarlarÄ± - TÄ±kla AÃ§/Kapat", player);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.DUEL_SETTINGS);
        fillDecorative(gui);

        var cfg = plugin.getConfigManager();

        // EÅŸya dÃ¼ÅŸÃ¼rme
        boolean blockDrop = cfg.isBlockDrop();
        ItemStack drop = new ItemBuilder(Material.DROPPER)
                .name(MessageUtil.parse("<#3B82F6>EÅŸya DÃ¼ÅŸÃ¼rme: " + (blockDrop ? "<red><bold>KapalÄ±</bold>" : "<green><bold>AÃ§Ä±k (Bahis Modu)</bold>"), player))
                .lore(
                        MessageUtil.parse("<gray>Åu an: " + (blockDrop ? "<red>Engelli - yere bile dÃ¼ÅŸmez, dupe korumalÄ±" : "<green>Ä°zinli - bahis gibi"), player),
                        MessageUtil.parse("<gray>KAPALI: <white>HiÃ§ eÅŸya yere dÃ¼ÅŸmez, Ã¶lÃ¼nce bile", player),
                        MessageUtil.parse("<gray>DÃ¼ello bitince her iki oyuncunun eski envanteri geri gelir", player),
                        MessageUtil.parse("<gray>Dupe korumalÄ±", player),
                        Component.empty(),
                        MessageUtil.parse("<gray>AÃ‡IK: <yellow>Bahis Modu</yellow> - insanlar kitlerini bahis gibi oynar", player),
                        MessageUtil.parse("<gray>Ã–len kiÅŸi kitini kaybeder, eÅŸyalarÄ± yere dÃ¼ÅŸer", player),
                        MessageUtil.parse("<gray>Kazanan eÅŸyalarÄ± toplayabilir", player),
                        MessageUtil.parse("<red>Dupe korumalÄ±: Kaybedenin eski envanteri geri verilmez", player),
                        Component.empty(),
                        MessageUtil.parse("<yellow>TÄ±kla ve deÄŸiÅŸtir! ÃœstÃ¼ne gelince aÃ§Ä±klama gÃ¶zÃ¼kÃ¼r", player),
                        MessageUtil.parse("<dark_gray>config: duel.restrictions.block-drop", player)
                )
                .glowing(!blockDrop)
                .build();
        gui.setItem(10, drop, (p, c) -> {
            cfg.toggle("duel.restrictions.block-drop");
            p.sendMessage(MessageUtil.parseWithPrefix("<#3B82F6> EÅŸya dÃ¼ÅŸÃ¼rme: <white>" + (cfg.isBlockDrop() ? "KapalÄ± (yere bile dÃ¼ÅŸmez, dupe korumalÄ±)" : "AÃ§Ä±k (Bahis Modu - kitler bahis)"), p));
            openGlobalSettingsGUI(p);
        });

        // EÅŸya alma
        boolean blockPickup = cfg.isBlockPickup();
        ItemStack pickup = new ItemBuilder(Material.HOPPER)
                .name(MessageUtil.parse("<#3B82F6>EÅŸya Toplama: " + (blockPickup ? "<red><bold>KapalÄ±</bold>" : "<green><bold>AÃ§Ä±k</bold>"), player))
                .lore(MessageUtil.parse("<gray>Åu an: " + (blockPickup ? "<red>Engelli" : "<green>Ä°zinli"), player), MessageUtil.parse("<yellow>TÄ±kla deÄŸiÅŸtir!", player))
                .glowing(!blockPickup)
                .build();
        gui.setItem(11, pickup, (p, c) -> {
            cfg.toggle("duel.restrictions.block-pickup");
            openGlobalSettingsGUI(p);
        });

        // Blok koyma
        boolean blockPlace = cfg.isBlockPlace();
        ItemStack place = new ItemBuilder(Material.BRICKS)
                .name(MessageUtil.parse("<#3B82F6>Blok Koyma: " + (blockPlace ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(13, place, (p, c) -> {
            cfg.toggle("duel.restrictions.block-place");
            openGlobalSettingsGUI(p);
        });

        // Komut engelleme
        boolean blockCmd = cfg.isBlockCommands();
        ItemStack cmd = new ItemBuilder(Material.COMMAND_BLOCK)
                .name(MessageUtil.parse("<#3B82F6>Komut KullanÄ±mÄ±: " + (blockCmd ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .lore(MessageUtil.parse("<gray>" + (blockCmd ? "Sadece /duel izinli" : "TÃ¼m komutlar izinli"), player), MessageUtil.parse("<yellow>TÄ±kla deÄŸiÅŸtir!", player))
                .build();
        gui.setItem(14, cmd, (p, c) -> {
            cfg.toggle("duel.restrictions.block-commands");
            openGlobalSettingsGUI(p);
        });

        // IÅŸÄ±nlanma
        boolean blockTp = cfg.isBlockTeleport();
        ItemStack tp = new ItemBuilder(Material.ENDER_PEARL)
                .name(MessageUtil.parse("<#3B82F6>IÅŸÄ±nlanma: " + (blockTp ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(15, tp, (p, c) -> {
            cfg.toggle("duel.restrictions.block-teleport");
            openGlobalSettingsGUI(p);
        });

        // Envanter tÄ±klama
        boolean blockInv = cfg.isBlockInventoryClick();
        ItemStack inv = new ItemBuilder(Material.CHEST)
                .name(MessageUtil.parse("<#3B82F6>Envanter DÃ¼zenleme: " + (blockInv ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(16, inv, (p, c) -> {
            cfg.toggle("duel.restrictions.block-inventory-click");
            openGlobalSettingsGUI(p);
        });

        // Chest aÃ§ma
        boolean blockChest = cfg.isBlockChestOpen();
        ItemStack chest = new ItemBuilder(Material.CHEST)
                .name(MessageUtil.parse("<#3B82F6>Chest AÃ§ma: " + (blockChest ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(19, chest, (p, c) -> {
            cfg.toggle("duel.restrictions.block-chest-open");
            openGlobalSettingsGUI(p);
        });

        // EnderChest
        boolean blockEnder = cfg.isBlockEnderChest();
        ItemStack ender = new ItemBuilder(Material.ENDER_CHEST)
                .name(MessageUtil.parse("<#3B82F6>EnderChest: " + (blockEnder ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(20, ender, (p, c) -> {
            cfg.toggle("duel.restrictions.block-enderchest");
            openGlobalSettingsGUI(p);
        });

        // UÃ§ma
        boolean blockFly = cfg.isBlockFlight();
        ItemStack fly = new ItemBuilder(Material.FEATHER)
                .name(MessageUtil.parse("<#3B82F6>UÃ§ma: " + (blockFly ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(21, fly, (p, c) -> {
            cfg.toggle("duel.restrictions.block-flight");
            openGlobalSettingsGUI(p);
        });

        // Gamemode
        boolean blockGm = cfg.isBlockGamemodeChange();
        ItemStack gm = new ItemBuilder(Material.COMMAND_BLOCK_MINECART)
                .name(MessageUtil.parse("<#3B82F6>Gamemode DeÄŸiÅŸtirme: " + (blockGm ? "<red>KapalÄ±" : "<green>AÃ§Ä±k"), player))
                .build();
        gui.setItem(22, gm, (p, c) -> {
            cfg.toggle("duel.restrictions.block-gamemode-change");
            openGlobalSettingsGUI(p);
        });

        // AÃ§lÄ±k
        boolean disableHunger = cfg.isDisableHungerDuringDuel();
        ItemStack hunger = new ItemBuilder(Material.COOKED_BEEF)
                .name(MessageUtil.parse("<#3B82F6>AÃ§lÄ±k: " + (disableHunger ? "<green>KapalÄ± (tok kalÄ±r)" : "<red>AÃ§Ä±k (acÄ±kÄ±r)"), player))
                .build();
        gui.setItem(23, hunger, (p, c) -> {
            cfg.set("settings.disable-hunger-during-duel", !disableHunger);
            openGlobalSettingsGUI(p);
        });

        // Hareket engelleme countdown
        boolean blockMove = cfg.isBlockMovementDuringCountdown();
        ItemStack move = new ItemBuilder(Material.LEATHER_BOOTS)
                .name(MessageUtil.parse("<#3B82F6>Countdown Hareket: " + (blockMove ? "<red>Engelli" : "<green>Serbest"), player))
                .build();
        gui.setItem(24, move, (p, c) -> {
            cfg.toggle("settings.block-movement-during-countdown");
            openGlobalSettingsGUI(p);
        });

        // Arena reset butonu - DOLU bug'Ä± iÃ§in
        ItemStack reset = new ItemBuilder(Material.BARRIER)
                .name(MessageUtil.parse("<red><bold>âš  TÃ¼m ArenalarÄ± Zorla BoÅŸalt</bold>", player))
                .lore(
                        MessageUtil.parse("<gray>Arenalar sÃ¼rekli DOLU gÃ¶zÃ¼kÃ¼yorsa tÄ±kla", player),
                        MessageUtil.parse("<gray>BoÅŸ olsa bile DOLU diyorsa", player),
                        MessageUtil.parse("<yellow>TÄ±kla ve tÃ¼m arenalarÄ± boÅŸalt!", player),
                        MessageUtil.parse("<dark_gray>Komut: /duel arenas reset", player)
                )
                .glowing(true)
                .build();
        gui.setItem(40, reset, (p, c) -> {
            plugin.getArenaManager().forceResetAll();
            p.sendMessage(MessageUtil.parseWithPrefix("<green>TÃ¼m arenalar zorla boÅŸaltÄ±ldÄ±! BoÅŸta: " + plugin.getArenaManager().getAvailableCount(), p));
            openGlobalSettingsGUI(p);
        });

        ItemStack info = new ItemBuilder(Material.PAPER)
                .name(MessageUtil.parse("<#1E3A8A>ayarlar.yml yerine GUI", player))
                .lore(MessageUtil.parse("<gray>Buradan tÄ±klayarak aÃ§/kapat yap", player), MessageUtil.parse("<gray>config.yml'e gerek yok", player), MessageUtil.parse("<green>DeÄŸiÅŸiklik anÄ±nda kaydedilir", player))
                .build();
        gui.setItem(45, info, null);

        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), player)).build();
        gui.setItem(53, close, (p, c) -> p.closeInventory());

        gui.open(player);
        registerOpen(player, gui);
    }

    // Per-duel ayarlar GUI - oyuncular GUI'den kontrol eder, config.yml deÄŸil
    public void openPerDuelSettingsGUI(Player requester, Player target) {
        int size = 27;
        Component title = MessageUtil.parse("<black>DÃ¼ello AyarlarÄ± - Bahis", requester);
        BaseGUI gui = new BaseGUI(plugin, title, size, BaseGUI.Type.DUEL_SETTINGS);
        fillDecorative(gui);

        boolean betEnabled = plugin.getDuelManager().getBetPreference(requester.getUniqueId());
        ItemStack betItem = new ItemBuilder(Material.DROPPER)
                .name(MessageUtil.parse("<#3B82F6>EÅŸya Bahisi: " + (betEnabled ? "<green>AÃ§Ä±k" : "<red>KapalÄ±"), requester))
                .lore(
                        MessageUtil.parse("<gray>Åu an: " + (betEnabled ? "<green>Bahis Modu AÃ§Ä±k - kendi eÅŸyalarÄ±n bahis" : "<red>KapalÄ± - eÅŸyalar yere bile dÃ¼ÅŸmez"), requester),
                        Component.empty(),
                        MessageUtil.parse("<gray>AÃ‡IK: <yellow>Kendi GERÃ‡EK eÅŸyalarÄ±n bahse girer", requester),
                        MessageUtil.parse("<gray>(Kit seÃ§tiysen bile kit eÅŸyalarÄ± deÄŸil,", requester),
                        MessageUtil.parse("<gray>senin dÃ¼ello Ã¶ncesi envanterin bahis olur)", requester),
                        MessageUtil.parse("<gray>Ã–len kiÅŸi kendi eÅŸyalarÄ±nÄ± kaybeder", requester),
                        MessageUtil.parse("<gray>Kazanan toplar, dupe korumalÄ±", requester),
                        Component.empty(),
                        MessageUtil.parse("<gray>KAPALI: <white>EÅŸyalar asla yere dÃ¼ÅŸmez", requester),
                        MessageUtil.parse("<gray>Ã–lÃ¼nce bile dÃ¼ÅŸmez, eski envanter geri gelir", requester),
                        MessageUtil.parse("<gray>KarÅŸÄ± tarafÄ±n eÅŸyalarÄ± silinmez, dupe yok", requester),
                        Component.empty(),
                        MessageUtil.parse("<yellow>TÄ±kla ve deÄŸiÅŸtir! Mouse Ã¼stÃ¼ne gelince aÃ§Ä±klama", requester)
                )
                .glowing(betEnabled)
                .build();
        gui.setItem(13, betItem, (p, c) -> {
            boolean current = plugin.getDuelManager().getBetPreference(p.getUniqueId());
            plugin.getDuelManager().setBetPreference(p.getUniqueId(), !current);
            p.sendMessage(MessageUtil.parseWithPrefix("<#3B82F6>EÅŸya bahisi: <white>" + (!current ? "AÃ§Ä±k (Bahis)" : "KapalÄ± (yere bile dÃ¼ÅŸmez)"), p));
            openPerDuelSettingsGUI(p, target);
        });

        ItemStack info = new ItemBuilder(Material.PAPER)
                .name(MessageUtil.parse("<#1E3A8A>Bilgi", requester))
                .lore(
                        MessageUtil.parse("<gray>Buradan tÄ±klayarak bahis modunu aÃ§/kapat", requester),
                        MessageUtil.parse("<gray>config.yml yerine GUI'den kontrol", requester),
                        MessageUtil.parse("<green>Dupe korumalÄ±, eÅŸya silinme bug'Ä± dÃ¼zeltildi", requester)
                )
                .build();
        gui.setItem(11, info, null);

        ItemStack back = new ItemBuilder(Material.ARROW).name(MessageUtil.parse("<yellow>â—€ Geri", requester)).build();
        gui.setItem(18, back, (p, c) -> openDuelSetupGUI(p, target));
        ItemStack close = new ItemBuilder(Material.BARRIER).name(MessageUtil.parse(plugin.getMessagesManager().getRaw("gui.close"), requester)).build();
        gui.setItem(26, close, (p, c) -> p.closeInventory());

        gui.open(requester);
        registerOpen(requester, gui);
    }

    public void closeAll() {
        for (UUID id : new ArrayList<>(openGUIs.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.closeInventory();
        }
        openGUIs.clear();
    }
}

