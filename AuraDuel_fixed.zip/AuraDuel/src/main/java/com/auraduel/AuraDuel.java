package com.Auraduel;

import com.Auraduel.commands.DuelCommand;
import com.Auraduel.commands.DuelTabCompleter;
import com.Auraduel.config.ArenaConfigManager;
import com.Auraduel.config.ConfigManager;
import com.Auraduel.config.KitConfigManager;
import com.Auraduel.config.MessagesManager;
import com.Auraduel.arena.ArenaManager;
import com.Auraduel.duel.DuelManager;
import com.Auraduel.gui.GUIManager;
import com.Auraduel.kit.KitManager;

import com.Auraduel.listeners.*;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.logging.Level;

public final class AuraDuel extends JavaPlugin {

    private static AuraDuel instance;

    private ConfigManager configManager;
    private MessagesManager messagesManager;
    private ArenaConfigManager arenaConfigManager;
    private KitConfigManager kitConfigManager;
    private ArenaManager arenaManager;
    private DuelManager duelManager;
    private GUIManager guiManager;
    private KitManager kitManager;

    @Override
    public void onEnable() {
        instance = this;

        // Managers initialization - order matters
        this.configManager = new ConfigManager(this);
        this.messagesManager = new MessagesManager(this);
        this.arenaConfigManager = new ArenaConfigManager(this);
        this.kitConfigManager = new KitConfigManager(this);
        this.arenaManager = new ArenaManager(this);
        this.kitManager = new KitManager(this);
        this.duelManager = new DuelManager(this);
        this.guiManager = new GUIManager(this);

        // Load data
        try {
            configManager.load();
            messagesManager.load();
            arenaConfigManager.load();
            kitConfigManager.load();
            arenaManager.loadArenas();
            kitManager.loadKits();
            // Otomatik sistem: Sunucu aÃ§Ä±lÄ±ÅŸÄ±nda tÃ¼m arenalarÄ± zorla boÅŸalt, enable otomatik zaten yapÄ±ldÄ±
            arenaManager.forceResetAll();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Konfigurasyon yuklenirken hata!", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Commands - Paper plugin style (no paper-plugin.yml commands, use CommandMap)
        registerCommands();

        // Listeners
        registerListeners();

        // Otomatik sistemler - ArtÄ±k komut yazmana gerek yok, her ÅŸey otomatik
        // Her 60 saniyede bir takÄ±lÄ± arenalarÄ± otomatik dÃ¼zelt
        getServer().getScheduler().runTaskTimer(this, () -> {
            if (arenaManager != null) {
                arenaManager.autoFixStuckArenas();
            }
        }, 1200L, 1200L); // 60 saniye

        MessageUtil.checkPAPI();

        getLogger().info("AuraDuel v" + getPluginMeta().getVersion() + " aktif! Paper " + getServer().getVersion());
        if (configManager.isDebug()) {
            getLogger().info("Debug modu aktif");
        }
    }

    @Override
    public void onDisable() {
        if (duelManager != null) {
            duelManager.shutdown();
        }
        if (arenaManager != null && arenaConfigManager != null) {
            try {
                arenaManager.saveArenasSync();
            } catch (Exception e) {
                getLogger().log(Level.WARNING, "Arenalar kaydedilemedi", e);
            }
        }
        if (kitManager != null && kitConfigManager != null) {
            try {
                kitManager.saveKitsSync();
            } catch (Exception e) {
                getLogger().log(Level.WARNING, "Kitler kaydedilemedi", e);
            }
        }
        getLogger().info("AuraDuel devre disi birakildi. Aktif duellolar temizlendi.");
        instance = null;
    }

    private void registerListeners() {
        var pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerJoinListener(this), this);
        pm.registerEvents(new PlayerQuitListener(this), this);
        pm.registerEvents(new PlayerMoveListener(this), this);
        pm.registerEvents(new PlayerDeathListener(this), this);
        pm.registerEvents(new PlayerRespawnListener(this), this);
        pm.registerEvents(new DamageListener(this), this);
        pm.registerEvents(new InventoryListener(this), this);
        pm.registerEvents(new CommandBlockListener(this), this);
        pm.registerEvents(new BlockBreakPlaceListener(this), this);
        pm.registerEvents(new ItemDropPickupListener(this), this);
        pm.registerEvents(new ResurrectListener(this), this);
        pm.registerEvents(new GameModeAndFlightListener(this), this);
        pm.registerEvents(new TeleportListener(this), this);
        pm.registerEvents(new InteractListener(this), this);
        pm.registerEvents(new ChatInputListener(this), this);
    }

    private void registerCommands() {
        // Paper 1.21+ Paper plugin does not support getCommand() + paper-plugin.yml commands section
        // So we register via CommandMap directly - compatible with Purpur/Paper
        var executor = new DuelCommand(this);
        var tabCompleter = new DuelTabCompleter(this);

        var duelCommand = new Command("duel", "Ana duel komutu", "/duel <invite/kabul/red/durum/create/delete/edit/arenas/reload>", List.of("duello", "vs", "dws")) {
            @Override
            public boolean execute(@NotNull CommandSender sender, @NotNull String label, @NotNull String[] args) {
                return executor.onCommand(sender, this, label, args);
            }

            @Override
            public @NotNull List<String> tabComplete(@NotNull CommandSender sender, @NotNull String alias, @NotNull String[] args) throws IllegalArgumentException {
                List<String> completions = tabCompleter.onTabComplete(sender, this, alias, args);
                return completions != null ? completions : super.tabComplete(sender, alias, args);
            }
        };
        // Permission null - we handle duel.use / duel.admin inside DuelCommand per subcommand
        duelCommand.setPermission(null);

        try {
            var commandMap = getServer().getCommandMap();
            commandMap.register("Auraduel", duelCommand);
            // Also register with minecraft namespace for safety
            commandMap.register("minecraft", duelCommand);
            getLogger().info("Komutlar CommandMap ile kaydedildi: /duel (create, delete, edit, arenas, invite, kabul, red, durum, reload, gui)");
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Komut kaydedilirken hata!", e);
        }
    }

    public void reload() {
        configManager.load();
        messagesManager.load();
        arenaConfigManager.load();
        kitConfigManager.load();
        arenaManager.loadArenas();
        kitManager.loadKits();
    }

    public static AuraDuel getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public MessagesManager getMessagesManager() {
        return messagesManager;
    }

    public ArenaConfigManager getArenaConfigManager() {
        return arenaConfigManager;
    }

    public KitConfigManager getKitConfigManager() {
        return kitConfigManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public DuelManager getDuelManager() {
        return duelManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }
}

