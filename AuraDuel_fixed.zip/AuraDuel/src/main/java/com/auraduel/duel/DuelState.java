package com.Auraduel.duel;

public enum DuelState {
    REQUESTED,
    COUNTDOWN,
    IN_PROGRESS,
    FINISHED,
    CANCELLED
}

