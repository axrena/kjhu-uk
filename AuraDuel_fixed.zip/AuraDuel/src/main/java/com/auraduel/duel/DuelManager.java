package com.Auraduel.duel;

import com.Auraduel.AuraDuel;
import com.Auraduel.arena.Arena;
import com.Auraduel.utils.MessageUtil;
import com.Auraduel.utils.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class DuelManager {

    private final AuraDuel plugin;

    // Requests: key = player UUID, value = request
    private final Map<UUID, DuelRequest> sentRequests = new ConcurrentHashMap<>(); // requester -> request
    private final Map<UUID, DuelRequest> receivedRequests = new ConcurrentHashMap<>(); // target -> request

    // Active duels
    private final Map<UUID, Duel> duelsById = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> playerToDuelId = new ConcurrentHashMap<>();

    private BukkitTask expirationTask;

    private final Set<UUID> pendingRespawnRestore = ConcurrentHashMap.newKeySet();
    private final Map<UUID, PlayerState> pendingRestoreStates = new ConcurrentHashMap<>();

    private final Map<UUID, BukkitTask> requestCountdownTasks = new ConcurrentHashMap<>();

    private final Map<UUID, String> arenaPreferences = new ConcurrentHashMap<>();
    private final Map<UUID, String> kitPreferences = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> betPreferences = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Boolean>> duelSettingsPreferences = new ConcurrentHashMap<>();

    public DuelManager(AuraDuel plugin) {
        this.plugin = plugin;
        startExpirationTask();
    }

    private void startExpirationTask() {
        expirationTask = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            List<DuelRequest> toExpire = new ArrayList<>();
            for (DuelRequest req : sentRequests.values()) {
                if (req.getExpireAt() <= now) {
                    toExpire.add(req);
                }
            }
            if (!toExpire.isEmpty()) {
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    for (DuelRequest req : toExpire) {
                        expireRequest(req);
                    }
                });
            }
        }, 20L, 20L);
    }

    public void shutdown() {
        if (expirationTask != null) {
            expirationTask.cancel();
        }
        for (var task : requestCountdownTasks.values()) {
            try { task.cancel(); } catch (Exception ignored) {}
        }
        requestCountdownTasks.clear();
        for (Duel duel : new ArrayList<>(duelsById.values())) {
            try {
                forceEndDuel(duel, null, EndReason.PLUGIN_DISABLE);
            } catch (Exception ignored) {}
        }
        sentRequests.clear();
        receivedRequests.clear();
        duelsById.clear();
        playerToDuelId.clear();
        pendingRespawnRestore.clear();
        pendingRestoreStates.clear();
    }

    // ================= REQUEST LOGIC =================

    public enum RequestResult {
        SUCCESS,
        SELF,
        OFFLINE,
        ALREADY_IN_DUEL,
        TARGET_ALREADY_IN_DUEL,
        ALREADY_SENT,
        TARGET_HAS_PENDING,
        SAME_DUEL_BLOCK,
        NO_FREE_ARENA
    }

    public static class RequestResponse {
        public final RequestResult result;
        public final DuelRequest request;
        public RequestResponse(RequestResult result, DuelRequest request) {
            this.result = result;
            this.request = request;
        }
    }

    public RequestResponse sendRequest(Player requester, Player target) {
        UUID reqId = requester.getUniqueId();
        UUID tarId = target.getUniqueId();

        if (reqId.equals(tarId)) {
            return new RequestResponse(RequestResult.SELF, null);
        }
        if (!target.isOnline()) {
            return new RequestResponse(RequestResult.OFFLINE, null);
        }
        if (isInDuel(reqId)) {
            return new RequestResponse(RequestResult.ALREADY_IN_DUEL, null);
        }
        if (isInDuel(tarId)) {
            return new RequestResponse(RequestResult.TARGET_ALREADY_IN_DUEL, null);
        }
        if (sentRequests.containsKey(reqId)) {
            DuelRequest existing = sentRequests.get(reqId);
            if (!existing.isExpired()) {
                return new RequestResponse(RequestResult.ALREADY_SENT, null);
            } else {
                removeRequest(existing);
            }
        }
        if (receivedRequests.containsKey(tarId)) {
            DuelRequest existing = receivedRequests.get(tarId);
            if (!existing.isExpired()) {
                return new RequestResponse(RequestResult.TARGET_HAS_PENDING, null);
            } else {
                removeRequest(existing);
            }
        }
        UUID existingDuelId = playerToDuelId.get(reqId);
        if (existingDuelId != null) {
            Duel duel = duelsById.get(existingDuelId);
            if (duel != null && duel.containsPlayer(tarId)) {
                return new RequestResponse(RequestResult.SAME_DUEL_BLOCK, null);
            }
        }

        long expireMillis = plugin.getConfigManager().getRequestExpireSeconds() * 1000L;
        DuelRequest request = new DuelRequest(reqId, tarId, expireMillis);
        sentRequests.put(reqId, request);
        receivedRequests.put(tarId, request);

        notifyRequestSent(requester, target, request);

        return new RequestResponse(RequestResult.SUCCESS, request);
    }

    private void notifyRequestSent(Player requester, Player target, DuelRequest request) {
        var mm = plugin.getMessagesManager();
        var cfg = plugin.getConfigManager();
        long remaining = request.getRemainingSeconds();
        if (remaining <= 0) remaining = cfg.getRequestExpireSeconds();

        String timeStr = String.valueOf(remaining);
        String arenaPref = getArenaPreference(requester.getUniqueId()).orElse("Rastgele");
        String kitPref = getKitPreference(requester.getUniqueId());

        requester.sendMessage(mm.getPrefixed("duel.invite.sent-chat", "%target%", target.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref));
        Component title = mm.getComponent("duel.invite.sent-title", "%target%", target.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref);
        Component subtitle = mm.getComponent("duel.invite.sent-subtitle", "%target%", target.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref);
        requester.showTitle(Title.title(title, subtitle, Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(2000), Duration.ofMillis(500))));
        requester.sendActionBar(MessageUtil.parse(MessageUtil.replacePlaceholders(mm.getRaw("duel.invite.sent-actionbar"), "%target%", target.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref), requester));
        SoundUtil.play(requester, cfg.getSound("request-send", "ENTITY_EXPERIENCE_ORB_PICKUP"));

        for (String line : mm.getList("duel.invite.received-chat")) {
            String replaced = line.replace("%player%", requester.getName()).replace("%target%", target.getName()).replace("%time%", timeStr).replace("%arena%", arenaPref).replace("%kit%", kitPref);
            target.sendMessage(MessageUtil.parse(replaced, target));
        }
        Component rTitle = mm.getComponent("duel.invite.received-title", "%player%", requester.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref);
        Component rSub = mm.getComponent("duel.invite.received-subtitle", "%player%", requester.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref);
        target.showTitle(Title.title(rTitle, rSub, Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(3500), Duration.ofMillis(800))));
        target.sendActionBar(MessageUtil.parse(MessageUtil.replacePlaceholders(mm.getRaw("duel.invite.received-actionbar"), "%player%", requester.getName(), "%time%", timeStr, "%arena%", arenaPref, "%kit%", kitPref), target));
        SoundUtil.play(target, cfg.getSound("request-receive", "BLOCK_NOTE_BLOCK_PLING"));

        BukkitTask countdownTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long rem = request.getRemainingSeconds();
            if (rem <= 0 || request.isExpired()) return;
            Player req = plugin.getServer().getPlayer(request.getRequester());
            Player tar = plugin.getServer().getPlayer(request.getTarget());
            if (req == null || tar == null || !req.isOnline() || !tar.isOnline()) return;
            String remStr = String.valueOf(rem);
            String reqActionRaw = mm.getRaw("duel.invite.sent-actionbar").replace("%target%", tar.getName()).replace("%time%", remStr).replace("%arena%", arenaPref).replace("%kit%", kitPref);
            String tarActionRaw = mm.getRaw("duel.invite.received-actionbar").replace("%player%", req.getName()).replace("%time%", remStr).replace("%arena%", arenaPref).replace("%kit%", kitPref);
            req.sendActionBar(MessageUtil.parse(reqActionRaw, req));
            tar.sendActionBar(MessageUtil.parse(tarActionRaw, tar));
            if (rem <= 5) {
                SoundUtil.play(req, "BLOCK_NOTE_BLOCK_HAT", 0.5f, 1.5f);
                SoundUtil.play(tar, "BLOCK_NOTE_BLOCK_HAT", 0.5f, 1.5f);
            }
        }, 20L, 20L);

        requestCountdownTasks.put(request.getRequester(), countdownTask);
        requestCountdownTasks.put(request.getTarget(), countdownTask);

        if (plugin.getConfigManager().isDebug()) {
            plugin.getLogger().info("Duel request: " + requester.getName() + " -> " + target.getName() + " expires in " + remaining + "s Arena:" + arenaPref + " Kit:" + kitPref);
        }
    }

    public boolean acceptRequest(Player accepter) {
        UUID accId = accepter.getUniqueId();
        DuelRequest request = receivedRequests.get(accId);
        if (request == null || request.isExpired()) {
            if (request != null) removeRequest(request);
            return false;
        }

        Player requester = plugin.getServer().getPlayer(request.getRequester());
        if (requester == null || !requester.isOnline()) {
            removeRequest(request);
            accepter.sendMessage(plugin.getMessagesManager().getPrefixed("player-not-found", "%target%", "istek sahibi"));
            return false;
        }

        Arena selectedArena = null;
        Optional<String> prefOpt = getArenaPreference(request.getRequester());

        if (prefOpt.isPresent()) {
            String prefName = prefOpt.get();
            Arena prefArena = plugin.getArenaManager().getArena(prefName);
            if (prefArena != null && prefArena.isAvailable()) {
                selectedArena = prefArena;
            } else if (prefArena != null && prefArena.isInUse()) {
                accepter.sendMessage(MessageUtil.parseWithPrefix("<yellow>Tercih edilen arena <white>" + prefName + "</white> ÅŸu anda dolu, random arena aranÄ±yor...", accepter));
                requester.sendMessage(MessageUtil.parseWithPrefix("<yellow>SeÃ§tiÄŸin arena dolu olduÄŸu iÃ§in random arena seÃ§iliyor...", requester));
            }
        }

        if (selectedArena == null) {
            var arenaOpt = plugin.getArenaManager().findFreeArena();
            if (arenaOpt.isEmpty()) {
                int total = plugin.getArenaManager().getTotalCount();
                int available = plugin.getArenaManager().getAvailableCount();
                var mm = plugin.getMessagesManager();
                accepter.sendMessage(mm.getPrefixed("duel.no-free-arena"));
                if (total == 0) {
                    accepter.sendMessage(MessageUtil.parseWithPrefix("<red>HiÃ§ arena oluÅŸturulmamÄ±ÅŸ! Admin bir arena oluÅŸturmalÄ±: <white>/duel create <isim></white> + <white>/duel edit <isim> pos1/pos2/enable", accepter));
                    requester.sendMessage(MessageUtil.parseWithPrefix("<red>HiÃ§ arena oluÅŸturulmamÄ±ÅŸ!", requester));
                } else {
                    accepter.sendMessage(MessageUtil.parseWithPrefix("<gray>Toplam arena: <white>" + total + "</white> | BoÅŸta: <white>" + available + "</white> | Dolu: <white>" + (total - available) + "</white>", accepter));
                    requester.sendMessage(MessageUtil.parseWithPrefix("<gray>Toplam arena: <white>" + total + "</white> | BoÅŸta: <white>" + available + "</white>", requester));
                    for (var arena : plugin.getArenaManager().getAllArenas()) {
                        if (!arena.isAvailable()) {
                            String reason = !arena.isEnabled() ? "Pasif" : arena.isInUse() ? "Dolu/KullanÄ±mda" : !arena.isSetup() ? "Kurulum eksik (pos1/pos2)" : "Bilinmiyor";
                            accepter.sendMessage(MessageUtil.parseWithPrefix("<dark_gray>- " + arena.getName() + ": <red>" + reason, accepter));
                        }
                    }
                }
                requester.sendMessage(mm.getPrefixed("duel.accept.no-arena"));
                removeRequest(request);
                clearPreferences(request.getRequester());
                return false;
            }
            selectedArena = arenaOpt.get();
        }

        Arena arena = selectedArena;
        UUID duelId = UUID.randomUUID();

        if (!arena.tryOccupy(duelId)) {
            var arenaOpt = plugin.getArenaManager().findFreeArena();
            if (arenaOpt.isEmpty()) {
                accepter.sendMessage(plugin.getMessagesManager().getPrefixed("duel.no-free-arena"));
                return false;
            }
            arena = arenaOpt.get();
            if (!arena.tryOccupy(duelId)) {
                accepter.sendMessage(plugin.getMessagesManager().getPrefixed("duel.no-free-arena"));
                return false;
            }
        }
        plugin.getArenaManager().onArenaOccupied(arena);

        Duel duel = new Duel(duelId, request.getRequester(), request.getTarget(), arena);
        String kitPref = getKitPreference(request.getRequester());
        duel.setSelectedKit(kitPref);
        boolean betMode = getBetPreference(request.getRequester());
        duel.setBetMode(betMode);

        removeRequest(request);
        clearPreferences(request.getRequester());

        duelsById.put(duel.getDuelId(), duel);
        playerToDuelId.put(duel.getPlayer1(), duel.getDuelId());
        playerToDuelId.put(duel.getPlayer2(), duel.getDuelId());

        var mm = plugin.getMessagesManager();
        accepter.sendMessage(mm.getPrefixed("duel.accept.accepter-chat"));
        requester.sendMessage(mm.getPrefixed("duel.accept.requester-chat", "%player%", accepter.getName()));

        startDuelCountdown(duel);

        return true;
    }

    public boolean denyRequest(Player denier) {
        UUID denierId = denier.getUniqueId();
        DuelRequest request = receivedRequests.get(denierId);
        if (request == null) return false;
        if (request.isExpired()) {
            removeRequest(request);
            return false;
        }

        Player requester = plugin.getServer().getPlayer(request.getRequester());
        var mm = plugin.getMessagesManager();

        denier.sendMessage(mm.getPrefixed("duel.deny.denier-chat"));
        Component title = mm.getComponent("duel.deny.title");
        Component sub = mm.getComponent("duel.deny.subtitle");
        denier.showTitle(Title.title(title, sub));

        if (requester != null && requester.isOnline()) {
            requester.sendMessage(mm.getPrefixed("duel.deny.requester-chat", "%player%", denier.getName()));
        }

        removeRequest(request);
        return true;
    }

    private void expireRequest(DuelRequest request) {
        Player requester = plugin.getServer().getPlayer(request.getRequester());
        Player target = plugin.getServer().getPlayer(request.getTarget());
        var mm = plugin.getMessagesManager();

        if (requester != null) {
            requester.sendMessage(mm.getPrefixed("duel.request-expired", "%player%", requester.getName(), "%target%", target != null ? target.getName() : "Oyuncu"));
            requester.sendActionBar(MessageUtil.parseWithPrefix("<red>DÃ¼ello sÃ¼resi doldu!", requester));
        }
        if (target != null) {
            target.sendMessage(mm.getPrefixed("duel.request-expired-target", "%player%", requester != null ? requester.getName() : "Oyuncu", "%target%", target.getName()));
            target.sendActionBar(MessageUtil.parseWithPrefix("<red>DÃ¼ello sÃ¼resi doldu!", target));
        }
        removeRequest(request);
    }

    private void removeRequest(DuelRequest request) {
        sentRequests.remove(request.getRequester());
        receivedRequests.remove(request.getTarget());
        BukkitTask t1 = requestCountdownTasks.remove(request.getRequester());
        BukkitTask t2 = requestCountdownTasks.remove(request.getTarget());
        if (t1 != null) try { t1.cancel(); } catch (Exception ignored) {}
        if (t2 != null && t2 != t1) try { t2.cancel(); } catch (Exception ignored) {}
    }

    // ================= PREFERENCES (GUI) =================
    public void setArenaPreference(UUID playerId, String arenaName) {
        if (arenaName == null || arenaName.equalsIgnoreCase("RANDOM") || arenaName.equalsIgnoreCase("Rastgele")) {
            arenaPreferences.remove(playerId);
        } else {
            arenaPreferences.put(playerId, arenaName);
        }
    }

    public Optional<String> getArenaPreference(UUID playerId) {
        return Optional.ofNullable(arenaPreferences.get(playerId));
    }

    public void setKitPreference(UUID playerId, String kitId) {
        if (kitId == null || kitId.equalsIgnoreCase("own")) {
            kitPreferences.remove(playerId);
            kitPreferences.put(playerId, "own");
        } else {
            kitPreferences.put(playerId, kitId);
        }
    }

    public String getKitPreference(UUID playerId) {
        return kitPreferences.getOrDefault(playerId, "own");
    }

    public void clearPreferences(UUID playerId) {
        arenaPreferences.remove(playerId);
        kitPreferences.remove(playerId);
        betPreferences.remove(playerId);
        duelSettingsPreferences.remove(playerId);
    }

    public void handlePlayerQuit(UUID playerId) {
        DuelRequest sent = sentRequests.remove(playerId);
        if (sent != null) {
            BukkitTask t = requestCountdownTasks.remove(playerId);
            if (t != null) try { t.cancel(); } catch (Exception ignored) {}
        }
        DuelRequest received = receivedRequests.remove(playerId);
        if (received != null) {
            BukkitTask t = requestCountdownTasks.remove(playerId);
            if (t != null) try { t.cancel(); } catch (Exception ignored) {}
        }
    }

    public void setBetPreference(UUID playerId, boolean betEnabled) {
        betPreferences.put(playerId, betEnabled);
    }

    public boolean getBetPreference(UUID playerId) {
        Boolean pref = betPreferences.get(playerId);
        if (pref != null) return pref;
        return !plugin.getConfigManager().isBlockDrop();
    }

    public boolean hasBetPreference(UUID playerId) {
        return betPreferences.containsKey(playerId);
    }

    public void setDuelSetting(UUID playerId, String key, boolean value) {
        Map<String, Boolean> settings = duelSettingsPreferences.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>());
        settings.put(key, value);
    }

    public boolean getDuelSetting(UUID playerId, String key, boolean def) {
        Map<String, Boolean> settings = duelSettingsPreferences.get(playerId);
        if (settings == null) return def;
        return settings.getOrDefault(key, def);
    }

    // ================= DUEL LIFECYCLE =================

    private void startDuelCountdown(Duel duel) {
        Player p1 = plugin.getServer().getPlayer(duel.getPlayer1());
        Player p2 = plugin.getServer().getPlayer(duel.getPlayer2());

        if (p1 == null || p2 == null || !p1.isOnline() || !p2.isOnline()) {
            forceEndDuel(duel, null, EndReason.PLAYER_OFFLINE);
            return;
        }

        duel.setState(DuelState.COUNTDOWN);

        PlayerState s1 = new PlayerState(p1);
        PlayerState s2 = new PlayerState(p2);
        duel.addPlayerState(p1.getUniqueId(), s1);
        duel.addPlayerState(p2.getUniqueId(), s2);

        preparePlayerForDuel(p1);
        preparePlayerForDuel(p2);

        giveKitIfNeeded(p1, duel.getSelectedKit());
        giveKitIfNeeded(p2, duel.getSelectedKit());

        Location spawn1 = duel.getArena().getSpawn1();
        Location spawn2 = duel.getArena().getSpawn2();
        if (spawn1 == null || spawn2 == null) {
            p1.sendMessage(plugin.getMessagesManager().getPrefixed("arena.not-setup"));
            p2.sendMessage(plugin.getMessagesManager().getPrefixed("arena.not-setup"));
            restoreAndCleanup(duel);
            return;
        }

        p1.teleportAsync(spawn1);
        p2.teleportAsync(spawn2);

        int total = plugin.getConfigManager().getCountdownSeconds();
        var bossBarColor = plugin.getConfigManager().getBossbarColor();
        var bossBarStyle = plugin.getConfigManager().getBossbarStyle();

        org.bukkit.boss.BossBar bukkitBossBar = null;
        if (plugin.getConfigManager().isCountdownBossbarEnabled()) {
            bukkitBossBar = Bukkit.createBossBar("", bossBarColor, bossBarStyle);
            bukkitBossBar.addPlayer(p1);
            bukkitBossBar.addPlayer(p2);
            bukkitBossBar.setVisible(true);
            duel.setBossBar(bukkitBossBar);
        }

        final org.bukkit.boss.BossBar finalBossBar = bukkitBossBar;
        final int[] count = {total};

        var task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            Player pl1 = plugin.getServer().getPlayer(duel.getPlayer1());
            Player pl2 = plugin.getServer().getPlayer(duel.getPlayer2());
            if (pl1 == null || pl2 == null || !pl1.isOnline() || !pl2.isOnline()) {
                if (finalBossBar != null) finalBossBar.removeAll();
                plugin.getServer().getScheduler().runTask(plugin, () -> forceEndDuel(duel, pl1 != null && pl1.isOnline() ? pl2 : pl1, EndReason.PLAYER_OFFLINE));
                return;
            }

            if (count[0] > 0) {
                var mm = plugin.getMessagesManager();
                String cntStr = String.valueOf(count[0]);

                if (plugin.getConfigManager().isCountdownTitleEnabled()) {
                    String titleRaw = mm.getRaw("countdown.title").replace("%count%", cntStr);
                    String subRaw = mm.getRaw("countdown.subtitle");
                    Component title = MessageUtil.parse(titleRaw, pl1);
                    Component subtitle = MessageUtil.parse(subRaw, pl1);
                    Title t = Title.title(title, subtitle, Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(900), Duration.ofMillis(200)));
                    pl1.showTitle(t);
                    pl2.showTitle(t);
                }
                if (plugin.getConfigManager().isCountdownActionbarEnabled()) {
                    String ab1Raw = mm.getRaw("countdown.actionbar")
                            .replace("%count%", cntStr)
                            .replace("%opponent%", pl2.getName());
                    String ab2Raw = mm.getRaw("countdown.actionbar")
                            .replace("%count%", cntStr)
                            .replace("%opponent%", pl1.getName());
                    pl1.sendActionBar(MessageUtil.parse(ab1Raw, pl1));
                    pl2.sendActionBar(MessageUtil.parse(ab2Raw, pl2));
                }
                if (finalBossBar != null) {
                    String bossTextRaw = plugin.getMessagesManager().getRaw("countdown.bossbar").replace("%count%", cntStr);
                    try {
                        finalBossBar.setTitle(MessageUtil.stripMiniMessage(bossTextRaw));
                    } catch (Exception ignored) {}
                    double progress = (double) count[0] / total;
                    finalBossBar.setProgress(Math.max(0.0, Math.min(1.0, progress)));
                }
                if (plugin.getConfigManager().isCountdownSoundEnabled()) {
                    SoundUtil.play(pl1, plugin.getConfigManager().getSound("countdown-tick", "BLOCK_NOTE_BLOCK_HAT"));
                    SoundUtil.play(pl2, plugin.getConfigManager().getSound("countdown-tick", "BLOCK_NOTE_BLOCK_HAT"));
                }

                count[0]--;
            } else {
                if (finalBossBar != null) {
                    finalBossBar.removeAll();
                }
                plugin.getServer().getScheduler().runTask(plugin, () -> startDuel(duel));
            }
        }, 0L, 20L);

        duel.setCountdownTaskId(task.getTaskId());
    }

    private void preparePlayerForDuel(Player player) {
        var cfg = plugin.getConfigManager();
        if (cfg.isHealOnStart()) {
            player.setHealth(player.getMaxHealth());
        }
        if (cfg.isFeedOnStart()) {
            player.setFoodLevel(20);
            player.setSaturation(20f);
            player.setExhaustion(0f);
        }
        if (cfg.isExtinguishFire()) {
            player.setFireTicks(0);
        }
        if (cfg.isClearPotionEffects()) {
            player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        }
        if (cfg.isClearFireTicks()) {
            player.setFireTicks(0);
        }
        if (cfg.isResetFallDistance()) {
            player.setFallDistance(0f);
        }
        if (cfg.isResetVelocity()) {
            player.setVelocity(new org.bukkit.util.Vector(0,0,0));
        }
        player.setFlying(false);
    }

    private void giveKitIfNeeded(Player player, String kitId) {
        if (kitId == null || kitId.equalsIgnoreCase("own")) return;
        var kitOpt = plugin.getKitManager().getKit(kitId);
        if (kitOpt.isEmpty()) return;
        var kit = kitOpt.get();
        if (kit.isKeepInventory()) return;

        player.getInventory().clear();

        ItemStack[] contents = kit.getInventoryContents();
        if (contents != null && contents.length == 36) {
            player.getInventory().setContents(contents);
        } else {
            for (var item : kit.getItems()) {
                if (item != null) player.getInventory().addItem(item);
            }
        }

        ItemStack[] armor = kit.getArmorContents();
        if (armor != null && armor.length > 0) {
            player.getInventory().setArmorContents(armor);
        }

        ItemStack off = kit.getOffHand();
        if (off != null) player.getInventory().setItemInOffHand(off);
        for (var eff : kit.getEffects()) {
            if (eff != null) player.addPotionEffect(eff);
        }
        player.updateInventory();
    }

    private void startDuel(Duel duel) {
        if (duel.getCountdownTaskId() != -1) {
            try {
                plugin.getServer().getScheduler().cancelTask(duel.getCountdownTaskId());
            } catch (Exception ignored) {}
        }

        Player p1 = plugin.getServer().getPlayer(duel.getPlayer1());
        Player p2 = plugin.getServer().getPlayer(duel.getPlayer2());

        if (p1 == null || p2 == null || !p1.isOnline() || !p2.isOnline()) {
            forceEndDuel(duel, null, EndReason.PLAYER_OFFLINE);
            return;
        }

        duel.setState(DuelState.IN_PROGRESS);
        duel.getArena().setEnabled(true);

        var mm = plugin.getMessagesManager();
        var cfg = plugin.getConfigManager();

        Component startTitle = mm.getComponent("countdown.start-title");
        Component startSub = mm.getComponent("countdown.start-subtitle");
        Title startTitleObj = Title.title(startTitle, startSub, Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1000), Duration.ofMillis(300)));
        p1.showTitle(startTitleObj);
        p2.showTitle(startTitleObj);

        p1.sendActionBar(mm.getComponent("countdown.start-actionbar"));
        p2.sendActionBar(mm.getComponent("countdown.start-actionbar"));

        String arenaName = duel.getArena().getName();
        p1.sendMessage(mm.getPrefixed("duel-start.chat", "%arena%", arenaName, "%opponent%", p2.getName()));
        p2.sendMessage(mm.getPrefixed("duel-start.chat", "%arena%", arenaName, "%opponent%", p1.getName()));

        SoundUtil.playBoth(p1, p2, cfg.getSound("duel-start", "ENTITY_ENDER_DRAGON_GROWL"), 1f, 1f);

        if (cfg.isDebug()) {
            plugin.getLogger().info("Duel started: " + p1.getName() + " vs " + p2.getName() + " in " + arenaName);
        }
    }

    public void endDuelByDeath(Player loser) {
        if (loser == null) return;
        UUID duelId = playerToDuelId.get(loser.getUniqueId());
        if (duelId == null) return;
        Duel duel = duelsById.get(duelId);
        if (duel == null) return;
        if (duel.getState() != DuelState.IN_PROGRESS && duel.getState() != DuelState.COUNTDOWN) return;

        UUID winnerId = duel.getOpponent(loser.getUniqueId());
        Player winner = winnerId != null ? plugin.getServer().getPlayer(winnerId) : null;

        forceEndDuel(duel, winner, EndReason.DEATH, loser);
    }

    public void endDuelByQuit(Player quitter) {
        if (quitter == null) return;
        UUID duelId = playerToDuelId.get(quitter.getUniqueId());
        if (duelId == null) return;
        Duel duel = duelsById.get(duelId);
        if (duel == null) return;

        UUID opponentId = duel.getOpponent(quitter.getUniqueId());
        Player opponent = opponentId != null ? plugin.getServer().getPlayer(opponentId) : null;

        forceEndDuel(duel, opponent, EndReason.PLAYER_OFFLINE, quitter);
    }

    public enum EndReason {
        DEATH,
        PLAYER_OFFLINE,
        COMMAND,
        PLUGIN_DISABLE,
        DRAW,
        MANUAL
    }

    public void forceEndDuel(Duel duel, Player winner, EndReason reason) {
        forceEndDuel(duel, winner, reason, null);
    }

    public void forceEndDuel(Duel duel, Player winner, EndReason reason, Player explicitLoser) {
        if (duel == null) return;

        if (duel.getCountdownTaskId() != -1) {
            try { plugin.getServer().getScheduler().cancelTask(duel.getCountdownTaskId()); } catch (Exception ignored) {}
        }
        if (duel.getBossBar() != null) {
            try { duel.getBossBar().removeAll(); } catch (Exception ignored) {}
        }

        duel.setState(DuelState.FINISHED);

        Player p1 = plugin.getServer().getPlayer(duel.getPlayer1());
        Player p2 = plugin.getServer().getPlayer(duel.getPlayer2());

        Player loser = explicitLoser;
        if (winner == null && loser == null) {
            if (p1 != null && p1.isOnline() && (p2 == null || !p2.isOnline())) { winner = p1; loser = p2; }
            else if (p2 != null && p2.isOnline() && (p1 == null || !p1.isOnline())) { winner = p2; loser = p1; }
        } else if (winner != null && loser == null) {
            UUID loserId = duel.getOpponent(winner.getUniqueId());
            loser = loserId != null ? plugin.getServer().getPlayer(loserId) : null;
            if (loser == null) {
                if (p1 != null && !p1.getUniqueId().equals(winner.getUniqueId())) loser = p1;
                else if (p2 != null && !p2.getUniqueId().equals(winner.getUniqueId())) loser = p2;
            }
        }

        if (loser != null) {
            duel.setLoserId(loser.getUniqueId());
        }

        var mm = plugin.getMessagesManager();
        var cfg = plugin.getConfigManager();

        if (winner != null || loser != null) {
            String winnerName = winner != null ? winner.getName() : (explicitLoser != null ? getOfflineName(duel.getOpponent(explicitLoser.getUniqueId())) : "Bilinmiyor");
            String loserName = loser != null ? loser.getName() : (winner != null ? getOfflineName(duel.getOpponent(winner.getUniqueId())) : "Bilinmiyor");
            if (loser == null && explicitLoser != null) loserName = explicitLoser.getName();
            if (winner == null && loser != null) winnerName = getOfflineName(duel.getOpponent(loser.getUniqueId()));

            if (winner != null && winner.isOnline()) {
                Component winTitle = mm.getComponent("duel-end.win-title", "%winner%", winnerName, "%loser%", loserName, "%arena%", duel.getArena().getName());
                Component winSub = mm.getComponent("duel-end.win-subtitle", "%winner%", winnerName, "%loser%", loserName, "%arena%", duel.getArena().getName());
                winner.showTitle(Title.title(winTitle, winSub, Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2500), Duration.ofMillis(500))));
                winner.sendActionBar(mm.getComponent("duel-end.win-actionbar", "%winner%", winnerName, "%loser%", loserName, "%arena%", duel.getArena().getName()));
                for (String line : mm.getList("duel-end.win-chat")) {
                    winner.sendMessage(MessageUtil.parse(line.replace("%winner%", winnerName).replace("%loser%", loserName).replace("%arena%", duel.getArena().getName()).replace("%kit%", duel.getSelectedKit()), winner));
                }
                SoundUtil.play(winner, cfg.getSound("duel-win", "UI_TOAST_CHALLENGE_COMPLETE"));
                if (cfg.isFireworkOnWin()) spawnFirework(winner.getLocation());
            }

            if (loser != null && loser.isOnline() && (winner == null || !loser.getUniqueId().equals(winner.getUniqueId()))) {
                Component loseTitle = mm.getComponent("duel-end.lose-title", "%winner%", winnerName, "%loser%", loserName, "%arena%", duel.getArena().getName());
                Component loseSub = mm.getComponent("duel-end.lose-subtitle", "%winner%", winnerName, "%loser%", loserName, "%arena%", duel.getArena().getName());
                loser.showTitle(Title.title(loseTitle, loseSub, Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2500), Duration.ofMillis(500))));
                loser.sendActionBar(mm.getComponent("duel-end.lose-actionbar", "%winner%", winnerName, "%loser%", loserName, "%arena%", duel.getArena().getName()));
                for (String line : mm.getList("duel-end.lose-chat")) {
                    loser.sendMessage(MessageUtil.parse(line.replace("%winner%", winnerName).replace("%loser%", loserName).replace("%arena%", duel.getArena().getName()).replace("%kit%", duel.getSelectedKit()), loser));
                }
                SoundUtil.play(loser, cfg.getSound("duel-lose", "ENTITY_VILLAGER_DEATH"));
            }

            if (winnerName != null && loserName != null && reason == EndReason.DEATH) {
                String broadcastRaw = mm.getRaw("duel-end.broadcast");
                if (broadcastRaw != null && !broadcastRaw.isEmpty()) {
                    Component broadcast = MessageUtil.parse(broadcastRaw.replace("%winner%", winnerName).replace("%loser%", loserName).replace("%arena%", duel.getArena().getName()).replace("%kit%", duel.getSelectedKit()));
                    for (Player online : Bukkit.getOnlinePlayers()) online.sendMessage(broadcast);
                }
            }

            if (winner != null && loser != null && reason == EndReason.PLAYER_OFFLINE) {
                if (loser.isOnline()) loser.sendMessage(mm.getPrefixed("events.quit-lose"));
                if (winner.isOnline()) winner.sendMessage(mm.getPrefixed("events.quit-win"));
            }
        }

        restoreAndCleanup(duel, winner, loser);
    }

    private String getOfflineName(UUID uuid) {
        if (uuid == null) return "Bilinmiyor";
        var offline = Bukkit.getOfflinePlayer(uuid);
        return offline.getName() != null ? offline.getName() : uuid.toString().substring(0,8);
    }

    private void spawnFirework(Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        int amount = plugin.getConfigManager().getFireworkAmount();
        for (int i = 0; i < amount; i++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                Firework fw = loc.getWorld().spawn(loc.clone().add(0,1,0), Firework.class);
                FireworkMeta meta = fw.getFireworkMeta();
                meta.addEffect(FireworkEffect.builder()
                        .withColor(Color.fromRGB(ThreadLocalRandom.current().nextInt(255), ThreadLocalRandom.current().nextInt(255), ThreadLocalRandom.current().nextInt(255)))
                        .with(FireworkEffect.Type.BALL_LARGE)
                        .trail(true)
                        .flicker(true)
                        .build());
                meta.setPower(1);
                fw.setFireworkMeta(meta);
                plugin.getServer().getScheduler().runTaskLater(plugin, fw::detonate, 20L);
            }, i * 5L);
        }
    }

    private void sendToSpawn(Player player) {
        if (player == null || !player.isOnline()) return;
        try {
            player.performCommand("spawn");
        } catch (Exception ignored) {}
    }

    private void sendToSpawnDelayed(UUID playerId, long delayTicks) {
        if (delayTicks <= 0) {
            Player p = plugin.getServer().getPlayer(playerId);
            sendToSpawn(p);
            return;
        }
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Player p = plugin.getServer().getPlayer(playerId);
            sendToSpawn(p);
        }, delayTicks);
    }

    public void restoreAndCleanup(Duel duel) {
        restoreAndCleanup(duel, null, null);
    }

    public void restoreAndCleanup(Duel duel, Player winner, Player loser) {
        if (duel == null) return;

        if (duel.getArena() != null) {
            duel.getArena().release();
            plugin.getArenaManager().onArenaReleased(duel.getArena());
        }

        // Ã–NEMLÄ°: Bu kontrol, PlayerDeathListener'daki betMode kontrolÃ¼yle (sadece duel.isBetMode())
        // BÄ°REBÄ°R AYNI olmak zorunda. Eskiden burada "|| !isBlockDrop()" eklenmiÅŸti; bu, bazÄ±
        // config.yml ayarlarÄ±nda (block-drop: false ama dÃ¼ello bahis modu kapalÄ±yken) bu metodun
        // "bahis modundayÄ±z" sanÄ±p kaybedenin envanterini geri vermemesine raÄŸmen, Ã¶lÃ¼m anÄ±nda
        // hiÃ§bir loot toplanmamÄ±ÅŸ olmasÄ± yÃ¼zÃ¼nden kazanana HÄ°Ã‡BÄ°R ÅEYÄ°N geÃ§memesine yol aÃ§Ä±yordu.
        boolean isBetMode = duel.isBetMode();

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            UUID loserId = (isBetMode && loser != null) ? loser.getUniqueId() : null;

            // FAZ 1: Bahis lootunu vermeden Ã–NCE, kaybeden HARÄ°Ã‡ herkesin (Ã¶zellikle
            // kazananÄ±n) durumu eski haline getirilir.
            //
            // Eskiden bunu tek bir dÃ¶ngÃ¼de yapÄ±yorduk: aynÄ± dÃ¶ngÃ¼ iÃ§inde hem kaybedenin
            // eÅŸyalarÄ± kazanana ekleniyor hem de kazananÄ±n kendi state.restore() Ã§aÄŸrÄ±sÄ±
            // yapÄ±lÄ±yordu. Map'in iterasyon sÄ±rasÄ± garanti olmadÄ±ÄŸÄ± iÃ§in, eÄŸer kazananÄ±n
            // kaydÄ± kaybedenden SONRA iÅŸlenirse, state.restore() Ã¶nce envanteri komple
            // TEMÄ°ZLEYÄ°P eski (dÃ¼ello Ã¶ncesi) haline dÃ¶ndÃ¼rÃ¼yor ve az Ã¶nce eklenen bahis
            // eÅŸyalarÄ±nÄ± da siliyordu. Bu da bazÄ± oyuncu Ã§iftlerinde eÅŸyalarÄ±n "kaybolduÄŸu"
            // hissi veren, kesik kesik ortaya Ã§Ä±kan bir bug'dÄ±. Åimdi iki aÅŸamaya bÃ¶ldÃ¼k:
            // Ã¶nce TÃœM restore iÅŸlemleri biter, loot en son, restore'u kesinleÅŸmiÅŸ bir
            // envantere eklenir.
            for (Map.Entry<UUID, PlayerState> entry : duel.getPlayerStates().entrySet()) {
                UUID pid = entry.getKey();
                PlayerState state = entry.getValue();
                Player player = plugin.getServer().getPlayer(pid);

                if (loserId != null && pid.equals(loserId)) {
                    // Bahis modunda kaybedenin eski envanteri KESÄ°NLÄ°KLE geri verilmez.
                    pendingRespawnRestore.remove(pid);
                    pendingRestoreStates.remove(pid);
                    continue;
                }

                if (player != null && player.isOnline()) {
                    if (player.isDead()) {
                        pendingRespawnRestore.add(pid);
                        pendingRestoreStates.put(pid, state);
                    } else {
                        boolean isThisWinner = winner != null && pid.equals(winner.getUniqueId());
                        // Konuma isinlanmiyor artik - oyuncu kaybeden en son duello'ya
                        // girdigi yere degil, /spawn'a gonderilecek.
                        state.restore(player, false);
                        if (isThisWinner) {
                            // Kazanan hemen spawn'a atilmaz, kutlayabilsin diye bekletilir;
                            // ama komutlar (isInDuel artik false oldugu icin) hemen acilir,
                            // isterse /spawn yazip erken cikabilir.
                            int delaySeconds = plugin.getConfigManager().getWinnerSpawnDelaySeconds();
                            long delayTicks = delaySeconds * 20L;
                            if (delaySeconds > 0) {
                                player.sendMessage(plugin.getMessagesManager().getPrefixed(
                                        "duel-end.winner-spawn-notice", "%seconds%", String.valueOf(delaySeconds)));
                            }
                            sendToSpawnDelayed(pid, delayTicks);
                        } else {
                            sendToSpawnDelayed(pid, 0L);
                        }
                    }
                } else {
                    pendingRespawnRestore.add(pid);
                    pendingRestoreStates.put(pid, state);
                }
            }

            // FAZ 2: Åimdi bahis lootunu kazanana ver. KazananÄ±n envanteri bu noktada
            // kesin olarak eski (dÃ¼ello Ã¶ncesi) haline dÃ¶nmÃ¼ÅŸ durumda - loot bunun
            // ÃœSTÃœNE eklenir, silinme riski yok.
            //
            // ENVANTER DOLUYSA: addItem() sÄ±ÄŸmayan eÅŸyalarÄ± "leftover" olarak dÃ¶ndÃ¼rÃ¼r,
            // biz de bunlarÄ± kazananÄ±n BULUNDUÄU konuma dÃ¼ÅŸÃ¼rÃ¼yoruz. Kazanan artÄ±k restore
            // sÄ±rasÄ±nda Ä±ÅŸÄ±nlanmÄ±yor (arenada kalÄ±p /spawn'a gecikmeli gÃ¶nderiliyor), bu yÃ¼zden
            // winner.getLocation() bu noktada her zaman gÃ¼ncel ve gÃ¼venilir.
            if (loserId != null && winner != null && winner.isOnline()) {
                List<ItemStack> loot = duel.getBetLoot();
                plugin.getLogger().info("Bahis modu: " + getOfflineName(loserId) + " kaybetti, envanteri geri verilmedi (dupe korumalÄ±)");
                if (loot != null && !loot.isEmpty()) {
                    Location dropLoc = winner.getLocation();
                    for (ItemStack item : loot) {
                        if (item == null || item.getType() == Material.AIR) continue;
                        Map<Integer, ItemStack> leftover = winner.getInventory().addItem(item);
                        for (ItemStack extra : leftover.values()) {
                            if (dropLoc.getWorld() != null) {
                                dropLoc.getWorld().dropItemNaturally(dropLoc, extra);
                            } else {
                                winner.getWorld().dropItemNaturally(winner.getLocation(), extra);
                            }
                        }
                    }
                    winner.sendMessage(MessageUtil.parseWithPrefix(
                            "<gold>âš” <yellow>" + getOfflineName(loserId) + "</yellow>'in eÅŸyalarÄ± bahis kazancÄ± olarak envanterine eklendi!", winner));
                    winner.updateInventory();
                }
            }

            duelsById.remove(duel.getDuelId());
            playerToDuelId.remove(duel.getPlayer1());
            playerToDuelId.remove(duel.getPlayer2());
        }, 2L);
    }

    public boolean handleRespawn(Player player) {
        UUID id = player.getUniqueId();

        // BAHÄ°S MODU KORUMASI: PlayerRespawnEvent, restoreAndCleanup()'Ä±n 2 tick sonra
        // Ã§alÄ±ÅŸan gÃ¶revinden Ã–NCE tetiklenebilir (oyuncu anÄ±nda respawn olursa). Bu durumda
        // aÅŸaÄŸÄ±daki eski kod, kaybedenin orijinal (dÃ¼ello Ã¶ncesi) envanterini yanlÄ±ÅŸlÄ±kla
        // geri veriyordu - bahis modunda eÅŸyalarÄ±n kazanana geÃ§memesinin sebeplerinden biri
        // buydu. Kaybeden ise ve dÃ¼ello bahis modundaysa, orijinal envanter KESÄ°NLÄ°KLE
        // geri verilmez; restoreAndCleanup zaten eÅŸyalarÄ± kazanana aktarÄ±p temizliÄŸi yapacak.
        UUID earlyDuelId = playerToDuelId.get(id);
        if (earlyDuelId != null) {
            Duel earlyDuel = duelsById.get(earlyDuelId);
            if (earlyDuel != null && earlyDuel.isBetMode() && id.equals(earlyDuel.getLoserId())) {
                pendingRespawnRestore.remove(id);
                pendingRestoreStates.remove(id);
                return false;
            }
        }

        // Ã–nce pending restore states map'inden dene - eÅŸya silinme bug fix
        PlayerState pendingState = pendingRestoreStates.get(id);
        if (pendingState != null) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                Player p = plugin.getServer().getPlayer(id);
                if (p != null && p.isOnline()) {
                    // Respawn ekranindan cikan oyuncu artik eski (duello oncesi) konumuna
                    // degil /spawn'a gonderilir - respawn'in kendisi zaten "hemen degil"
                    // bekletmeyi sagliyor (oyuncunun respawn ekranina tiklamasi gerekiyor).
                    pendingState.restore(p, false);
                    sendToSpawn(p);
                }
                pendingRespawnRestore.remove(id);
                pendingRestoreStates.remove(id);
            }, 2L);
            return true;
        }

        if (!pendingRespawnRestore.contains(id)) {
            UUID duelId = playerToDuelId.get(id);
            if (duelId != null) {
                Duel duel = duelsById.get(duelId);
                if (duel != null) {
                    PlayerState state = duel.getPlayerState(id);
                    if (state != null) {
                        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                            Player p = plugin.getServer().getPlayer(id);
                            if (p != null) {
                                state.restore(p, false);
                                sendToSpawn(p);
                                pendingRespawnRestore.remove(id);
                                pendingRestoreStates.remove(id);
                                duelsById.remove(duel.getDuelId());
                                playerToDuelId.remove(duel.getPlayer1());
                                playerToDuelId.remove(duel.getPlayer2());
                                duel.getArena().release();
                                plugin.getArenaManager().onArenaReleased(duel.getArena());
                            }
                        }, 2L);
                        return true;
                    }
                }
            }
            return false;
        }

        for (Duel duel : duelsById.values()) {
            if (duel.containsPlayer(id)) {
                PlayerState state = duel.getPlayerState(id);
                if (state != null) {
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        Player p = plugin.getServer().getPlayer(id);
                        if (p != null) {
                            state.restore(p, false);
                            sendToSpawn(p);
                        }
                        pendingRespawnRestore.remove(id);
                        pendingRestoreStates.remove(id);
                        duelsById.remove(duel.getDuelId());
                        playerToDuelId.remove(duel.getPlayer1());
                        playerToDuelId.remove(duel.getPlayer2());
                        duel.getArena().release();
                        plugin.getArenaManager().onArenaReleased(duel.getArena());
                    }, 2L);
                    return true;
                }
            }
        }

        pendingRespawnRestore.remove(id);
        pendingRestoreStates.remove(id);
        return false;
    }

    // ================= QUERIES =================

    public boolean isInDuel(UUID playerId) {
        return playerToDuelId.containsKey(playerId);
    }

    public Duel getDuel(UUID playerId) {
        UUID duelId = playerToDuelId.get(playerId);
        if (duelId == null) return null;
        return duelsById.get(duelId);
    }

    public Duel getDuelById(UUID duelId) {
        return duelsById.get(duelId);
    }

    public Optional<DuelRequest> getSentRequest(UUID playerId) {
        return Optional.ofNullable(sentRequests.get(playerId));
    }

    public Optional<DuelRequest> getReceivedRequest(UUID playerId) {
        return Optional.ofNullable(receivedRequests.get(playerId));
    }

    public boolean hasPendingRequest(UUID playerId) {
        DuelRequest r = receivedRequests.get(playerId);
        return r != null && !r.isExpired();
    }

    public Map<UUID, Duel> getActiveDuels() {
        return Collections.unmodifiableMap(duelsById);
    }

    public int getActiveDuelCount() {
        return duelsById.size();
    }
}

