package com.Auraduel.duel;

import com.Auraduel.arena.Arena;
import org.bukkit.boss.BossBar;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class Duel {

    private final UUID duelId;
    private final UUID player1;
    private final UUID player2;
    private final Arena arena;
    private final Map<UUID, PlayerState> playerStates = new ConcurrentHashMap<>();

    private DuelState state;
    private long startTime;
    private BossBar bossBar;
    private int countdownTaskId = -1;
    private String selectedKit = "own";
    private boolean betMode = false; // true = bahis modu aÃ§Ä±k, eÅŸyalar bahis
    // Bahis modunda kaybedenin Ã¶lÃ¼m anÄ±nda elinde bulunan eÅŸyalar (yere dÃ¼ÅŸÃ¼rÃ¼lmez,
    // restoreAndCleanup iÃ§inde doÄŸrudan kazananÄ±n envanterine aktarÄ±lÄ±r)
    private List<ItemStack> betLoot = new ArrayList<>();
    // Kaybeden belirlenir belirlenmez (forceEndDuel iÃ§inde) senkron olarak set edilir.
    // Bu sayede PlayerRespawnEvent, 2 tick sonra Ã§alÄ±ÅŸan restoreAndCleanup gÃ¶revinden
    // Ã–NCE tetiklenirse bile (respawn - restore gÃ¶revi yarÄ±ÅŸ durumu), kaybedenin bahis
    // modunda olduÄŸu bilinip orijinal envanterinin yanlÄ±ÅŸlÄ±kla geri verilmesi engellenir.
    private UUID loserId;

    public Duel(UUID player1, UUID player2, Arena arena) {
        this(UUID.randomUUID(), player1, player2, arena);
    }

    // duelId'yi dÄ±ÅŸarÄ±dan almak iÃ§in: arena occupy edilirken kullanÄ±lan ID ile
    // Duel objesinin ID'sinin her zaman aynÄ± kalmasÄ±nÄ± garanti eder (bkz. DuelManager.acceptRequest)
    public Duel(UUID duelId, UUID player1, UUID player2, Arena arena) {
        this.duelId = duelId;
        this.player1 = player1;
        this.player2 = player2;
        this.arena = arena;
        this.state = DuelState.REQUESTED;
        this.startTime = System.currentTimeMillis();
    }

    public String getSelectedKit() {
        return selectedKit;
    }

    public void setSelectedKit(String selectedKit) {
        this.selectedKit = selectedKit != null ? selectedKit : "own";
    }

    public boolean isBetMode() {
        return betMode;
    }

    public void setBetMode(boolean betMode) {
        this.betMode = betMode;
    }

    public List<ItemStack> getBetLoot() {
        return betLoot;
    }

    public void setBetLoot(List<ItemStack> betLoot) {
        this.betLoot = betLoot != null ? betLoot : new ArrayList<>();
    }

    public UUID getLoserId() {
        return loserId;
    }

    public void setLoserId(UUID loserId) {
        this.loserId = loserId;
    }

    public UUID getDuelId() {
        return duelId;
    }

    public UUID getPlayer1() {
        return player1;
    }

    public UUID getPlayer2() {
        return player2;
    }

    public Arena getArena() {
        return arena;
    }

    public DuelState getState() {
        return state;
    }

    public void setState(DuelState state) {
        this.state = state;
    }

    public long getStartTime() {
        return startTime;
    }

    public BossBar getBossBar() {
        return bossBar;
    }

    public void setBossBar(BossBar bossBar) {
        this.bossBar = bossBar;
    }

    public int getCountdownTaskId() {
        return countdownTaskId;
    }

    public void setCountdownTaskId(int countdownTaskId) {
        this.countdownTaskId = countdownTaskId;
    }

    public Map<UUID, PlayerState> getPlayerStates() {
        return playerStates;
    }

    public void addPlayerState(UUID playerId, PlayerState state) {
        playerStates.put(playerId, state);
    }

    public PlayerState getPlayerState(UUID playerId) {
        return playerStates.get(playerId);
    }

    public UUID getOpponent(UUID playerId) {
        if (playerId.equals(player1)) return player2;
        if (playerId.equals(player2)) return player1;
        return null;
    }

    public boolean containsPlayer(UUID playerId) {
        return player1.equals(playerId) || player2.equals(playerId);
    }

    public long getDurationSeconds() {
        return (System.currentTimeMillis() - startTime) / 1000;
    }
}

