package com.Auraduel.duel;

import java.util.UUID;

public final class DuelRequest {

    private final UUID requester;
    private final UUID target;
    private final long timestamp;
    private final long expireAt;

    public DuelRequest(UUID requester, UUID target, long expireMillis) {
        this.requester = requester;
        this.target = target;
        this.timestamp = System.currentTimeMillis();
        this.expireAt = timestamp + expireMillis;
    }

    public UUID getRequester() {
        return requester;
    }

    public UUID getTarget() {
        return target;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public long getExpireAt() {
        return expireAt;
    }

    public boolean isExpired() {
        return System.currentTimeMillis() >= expireAt;
    }

    public long getRemainingSeconds() {
        long remaining = expireAt - System.currentTimeMillis();
        return Math.max(0, remaining / 1000);
    }
}

