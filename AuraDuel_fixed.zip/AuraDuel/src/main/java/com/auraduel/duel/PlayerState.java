package com.Auraduel.duel;

import com.Auraduel.AuraDuel;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.Collection;
import java.util.UUID;

public final class PlayerState {

    private final UUID playerId;
    private final Location location;
    private final ItemStack[] inventoryContents;
    private final ItemStack[] armorContents;
    private final ItemStack offHand;
    private final ItemStack[] extraContents;

    private final int level;
    private final float exp;
    private final double health;
    private final int foodLevel;
    private final float saturation;
    private final float exhaustion;
    private final Collection<PotionEffect> potionEffects;
    private final GameMode gameMode;
    private final int fireTicks;
    private final float fallDistance;
    private final boolean allowFlight;
    private final boolean flying;

    public PlayerState(Player player) {
        this.playerId = player.getUniqueId();
        this.location = player.getLocation().clone();
        this.inventoryContents = player.getInventory().getContents().clone();
        this.armorContents = player.getInventory().getArmorContents() != null ? player.getInventory().getArmorContents().clone() : new ItemStack[4];
        this.offHand = player.getInventory().getItemInOffHand().clone();
        this.extraContents = player.getInventory().getExtraContents() != null ? player.getInventory().getExtraContents().clone() : new ItemStack[1];

        this.level = player.getLevel();
        this.exp = player.getExp();
        this.health = player.getHealth();
        this.foodLevel = player.getFoodLevel();
        this.saturation = player.getSaturation();
        this.exhaustion = player.getExhaustion();
        this.potionEffects = player.getActivePotionEffects().stream().map(e -> new PotionEffect(e.getType(), e.getDuration(), e.getAmplifier(), e.isAmbient(), e.hasParticles(), e.hasIcon())).toList();
        this.gameMode = player.getGameMode();
        this.fireTicks = player.getFireTicks();
        this.fallDistance = player.getFallDistance();
        this.allowFlight = player.getAllowFlight();
        this.flying = player.isFlying();
    }

    public void restore(Player player) {
        restore(player, true);
    }

    // teleport = false: envanteri/canÄ±/statlarÄ± eski haline dondurur ama oyuncuyu
    // ESKÄ° (dÃ¼ello Ã¶ncesi) konumuna Ä±ÅŸÄ±nlamaz - oyuncu bulunduÄŸu yerde (Ã¶rn. arenada) kalÄ±r.
    // Duello bitince oyuncuyu artÄ±k eski konumuna deÄŸil /spawn'a gÃ¶ndermek istediÄŸimiz
    // iÃ§in konum kÄ±smÄ±nÄ± DuelManager ayrÄ±ca (gecikmeli ya da anÄ±nda) yÃ¶netiyor.
    public void restore(Player player, boolean teleport) {
        if (player == null || !player.isOnline()) return;

        // Teleport first if needed? We'll handle outside but ensure safe
        try {
            // Clear current
            player.getInventory().clear();
            player.setFireTicks(0);
            player.setFallDistance(0);
            player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));

            // Restore inventory
            player.getInventory().setContents(inventoryContents);
            if (armorContents != null) player.getInventory().setArmorContents(armorContents);
            player.getInventory().setItemInOffHand(offHand);
            if (extraContents != null) player.getInventory().setExtraContents(extraContents);

            // Restore stats
            player.setLevel(level);
            player.setExp(exp);
            // Health must be capped to max
            double maxHealth = 20.0;
            var attr = player.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) maxHealth = attr.getValue();
            player.setHealth(Math.min(health, maxHealth));
            player.setFoodLevel(foodLevel);
            player.setSaturation(saturation);
            player.setExhaustion(exhaustion);
            player.setGameMode(gameMode);
            player.setFireTicks(fireTicks);
            player.setFallDistance(fallDistance);
            player.setAllowFlight(allowFlight);
            player.setFlying(flying && allowFlight);

            // Potion effects
            for (PotionEffect eff : potionEffects) {
                player.addPotionEffect(eff);
            }

            // Teleport to old location - Paper async, fallback sync safe
            if (teleport) {
                try {
                    var future = player.teleportAsync(location);
                    future.thenAccept(result -> {
                        if (!result) {
                            var pl = AuraDuel.getInstance() != null ? AuraDuel.getInstance() : Bukkit.getPluginManager().getPlugin("AuraDuel");
                            if (pl != null) {
                                Bukkit.getScheduler().runTask(pl, () -> {
                                    try { player.teleport(location); } catch (Exception ignored) {}
                                });
                            } else {
                                try { player.teleport(location); } catch (Exception ignored) {}
                            }
                        }
                    });
                } catch (Exception ex) {
                    try { player.teleport(location); } catch (Exception ignored) {}
                }
            }

            player.updateInventory();
        } catch (Exception e) {
            // Try best effort
            e.printStackTrace();
        }
    }

    public Location getLocation() {
        return location;
    }

    public UUID getPlayerId() {
        return playerId;
    }

    // DÃ¼ello Ã¶ncesi GERÃ‡EK envanter - bahis modunda kaybedenin asÄ±l kaybettiÄŸi eÅŸyalarÄ±
    // hesaplamak iÃ§in kullanÄ±lÄ±r (kit eÅŸyalarÄ± deÄŸil, oyuncunun kendi eÅŸyalarÄ±).
    public ItemStack[] getInventoryContents() {
        return inventoryContents != null ? inventoryContents.clone() : new ItemStack[0];
    }

    public ItemStack[] getArmorContents() {
        return armorContents != null ? armorContents.clone() : new ItemStack[0];
    }

    public ItemStack getOffHand() {
        return offHand != null ? offHand.clone() : null;
    }
}

