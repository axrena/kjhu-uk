package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public final class BlockBreakPlaceListener implements Listener {

    private final AuraDuel plugin;

    public BlockBreakPlaceListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockBreak()) return;
        event.setCancelled(true);
        String raw = plugin.getMessagesManager().getRaw("restrictions.block-break");
        player.sendMessage(MessageUtil.parseWithPrefix(raw, player));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockPlace()) return;
        event.setCancelled(true);
        String raw = plugin.getMessagesManager().getRaw("restrictions.block-place");
        player.sendMessage(MessageUtil.parseWithPrefix(raw, player));
    }
}

