package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.List;
import java.util.Locale;

public final class CommandBlockListener implements Listener {

    private final AuraDuel plugin;

    public CommandBlockListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;

        if (!plugin.getConfigManager().isBlockCommands()) return;

        String msg = event.getMessage().toLowerCase(Locale.ROOT);

        // Allow only duel commands
        if (msg.startsWith("/duel") || msg.startsWith("/dÃ¼ello") || msg.startsWith("/duello")) {
            List<String> allowed = plugin.getConfigManager().getAllowedCommands();
            // Check if command prefix is allowed
            boolean allowedCmd = allowed.stream().anyMatch(a -> msg.startsWith("/" + a.toLowerCase(Locale.ROOT)));
            if (allowedCmd) return;
        }

        event.setCancelled(true);
        String raw = plugin.getMessagesManager().getRaw("restrictions.command-blocked");
        player.sendMessage(MessageUtil.parseWithPrefix(raw, player));
    }
}

