package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class PlayerJoinListener implements Listener {

    private final AuraDuel plugin;

    public PlayerJoinListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        MessageUtil.checkPAPI();
        // No special handling, but could cleanup pending states if player was in duel and offline restore needed
    }
}

