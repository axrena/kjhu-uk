package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.gui.BaseGUI;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;

public final class InventoryListener implements Listener {

    private final AuraDuel plugin;

    public InventoryListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // Check GUI first
        var openGuiOpt = plugin.getGuiManager().getOpenGUI(player);
        if (openGuiOpt.isPresent()) {
            BaseGUI gui = openGuiOpt.get();
            if (event.getInventory().equals(gui.getInventory())) {
                event.setCancelled(true);
                // Handle decorative glass already cancelled, but also trigger action
                if (event.getCurrentItem() == null) return;
                var action = gui.getAction(event.getSlot());
                if (action != null) {
                    action.onClick(player, event.getClick());
                }
                return;
            }
        }

        // Duel restrictions
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;

        if (plugin.getConfigManager().isBlockInventoryClick()) {
            // Op can still modify? No
            // Allow only if not in duel? Already in duel, block
            // But need to differentiate between own inventory and other inventories
            // Block all inventory manipulation except own crafting? Simplify: block prohibited actions
            // Chest open is also blocked via separate logic, but here block click
            // If player is in duel, cancel click in any inventory unless it's GUI
            // Actually spec: Inventory duzenleyemez, Chest acamaz, etc.
            // So cancel
            event.setCancelled(true);
            String msgRaw = plugin.getMessagesManager().getRaw("restrictions.inventory-blocked");
            player.sendMessage(MessageUtil.parseWithPrefix(msgRaw, player));
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        plugin.getGuiManager().unregisterOpen(player);
    }
}

