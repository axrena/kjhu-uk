package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;

public final class TeleportListener implements Listener {

    private final AuraDuel plugin;

    public TeleportListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockTeleport()) return;

        var duel = plugin.getDuelManager().getDuel(player.getUniqueId());
        if (duel == null) return;

        // Allow if duel finished (restore teleport)
        if (duel.getState() == com.Auraduel.duel.DuelState.FINISHED) return;

        // Allow only if cause is PLUGIN and distance small? For duel start we teleport via plugin: PlayerTeleportEvent cause PLUGIN.
        // But spec says teleport cannot during duel. So block all except when countdown or finished? Actually start teleport is before IN_PROGRESS.
        // For simplicity: block if duel is IN_PROGRESS or COUNTDOWN and not our own teleport?
        // We'll check if to location equals arena spawns - allow
        if (duel.getArena() != null) {
            var spawn1 = duel.getArena().getSpawn1();
            var spawn2 = duel.getArena().getSpawn2();
            var to = event.getTo();
            if (to != null && ((spawn1 != null && to.distanceSquared(spawn1) < 2) || (spawn2 != null && to.distanceSquared(spawn2) < 2))) {
                return; // Allow teleport to arena spawns (duel start)
            }
            // Allow teleport to old location on restore? That location is player state location, which is not arena spawn.
            // But state is FINISHED then we already returned.
            // So also allow if state is FINISHED or if restoring
            var state = duel.getPlayerState(player.getUniqueId());
            if (state != null && to != null && to.distanceSquared(state.getLocation()) < 2 && duel.getState() == com.Auraduel.duel.DuelState.FINISHED) {
                return;
            }
        }

        event.setCancelled(true);
        String raw = plugin.getMessagesManager().getRaw("restrictions.teleport-blocked");
        player.sendMessage(MessageUtil.parseWithPrefix(raw, player));
    }
}

