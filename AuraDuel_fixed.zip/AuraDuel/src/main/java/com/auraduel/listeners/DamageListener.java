package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.duel.Duel;
import com.Auraduel.duel.DuelState;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.projectiles.ProjectileSource;

public final class DamageListener implements Listener {

    private final AuraDuel plugin;

    public DamageListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = null;

        if (event.getDamager() instanceof Player p) {
            attacker = p;
        } else if (event.getDamager() instanceof Projectile proj) {
            ProjectileSource source = proj.getShooter();
            if (source instanceof Player p) {
                attacker = p;
            }
        }

        boolean victimInDuel = plugin.getDuelManager().isInDuel(victim.getUniqueId());
        boolean attackerInDuel = attacker != null && plugin.getDuelManager().isInDuel(attacker.getUniqueId());

        // Victim dÃ¼elloda deÄŸilse bizi ilgilendirmez (saldÄ±rgan dÃ¼ello dÄ±ÅŸÄ±ndaysa da ilgilendirmez, ama yukarÄ±da check var)
        if (!victimInDuel && !attackerInDuel) return;

        Duel duelVictim = victimInDuel ? plugin.getDuelManager().getDuel(victim.getUniqueId()) : null;

        // Victim dÃ¼elloda ama attacker yok (mob, dÃ¼ÅŸme deÄŸil, ok vs dÄ±ÅŸarÄ±dan)
        if (victimInDuel && attacker == null) {
            // Countdown sÄ±rasÄ±nda tÃ¼m hasar iptal
            if (duelVictim != null && duelVictim.getState() == DuelState.COUNTDOWN) {
                event.setCancelled(true);
            } else {
                // IN_PROGRESS sÄ±rasÄ±nda dÄ±ÅŸarÄ±dan gelen hasarÄ± da engelle (anti dÄ±ÅŸ mÃ¼dahale)
                // Sadece aynÄ± dÃ¼ellodaki ok / trident vs izinli, yoksa iptal
                // Attacker null ise dÄ±ÅŸ kaynak -> iptal
                event.setCancelled(true);
            }
            return;
        }

        // Sadece biri dÃ¼elloda
        if (victimInDuel != attackerInDuel) {
            event.setCancelled(true);
            return;
        }

        // Ä°kisi de dÃ¼elloda, aynÄ± dÃ¼ello mu?
        Duel duelAttacker = plugin.getDuelManager().getDuel(attacker.getUniqueId());

        if (duelVictim == null || duelAttacker == null) {
            event.setCancelled(true);
            return;
        }

        if (!duelVictim.getDuelId().equals(duelAttacker.getDuelId())) {
            event.setCancelled(true);
            return;
        }

        // AynÄ± dÃ¼ello, countdown mu?
        if (duelVictim.getState() == DuelState.COUNTDOWN) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGeneralDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;

        Duel duel = plugin.getDuelManager().getDuel(player.getUniqueId());
        if (duel == null) return;

        if (duel.getState() == DuelState.COUNTDOWN) {
            event.setCancelled(true);
        }
    }
}


