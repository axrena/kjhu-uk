package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;

public final class ItemDropPickupListener implements Listener {

    private final AuraDuel plugin;

    public ItemDropPickupListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockDrop()) return;
        event.setCancelled(true);
        String raw = plugin.getMessagesManager().getRaw("restrictions.drop-blocked");
        player.sendMessage(MessageUtil.parseWithPrefix(raw, player));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockPickup()) return;
        event.setCancelled(true);
    }
}

