package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public final class ChatInputListener implements Listener {

    private final AuraDuel plugin;

    public ChatInputListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    // Not: eski org.bukkit.event.player.AsyncPlayerChatEvent deprecated (Paper: "use AsyncChatEvent instead").
    // AsyncChatEvent, Adventure Component tabanlÄ± olup chat-signing sistemiyle uyumludur ve
    // legacy event'in getirdiÄŸi gereksiz recipient-set/format hesaplama yÃ¼kÃ¼nÃ¼ taÅŸÄ±maz.
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        var guiManager = plugin.getGuiManager();

        if (!guiManager.isAwaitingInput(player.getUniqueId())) return;

        event.setCancelled(true);

        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        // Sync taska taÅŸÄ±
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            guiManager.handleChatInput(player, message);
        });
    }
}

