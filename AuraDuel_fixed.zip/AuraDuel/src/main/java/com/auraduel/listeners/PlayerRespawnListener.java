package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

public final class PlayerRespawnListener implements Listener {

    private final AuraDuel plugin;

    public PlayerRespawnListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();

        // Check if this respawn belongs to a duel death
        boolean handled = plugin.getDuelManager().handleRespawn(player);
        if (handled) {
            // If handled, DuelManager will restore inventory and send the player to /spawn
            // shortly after respawn. We just set a safe temporary respawn location here so
            // they don't briefly appear stuck at the vanilla bed/world spawn point.
            var duel = plugin.getDuelManager().getDuel(player.getUniqueId());
            if (duel != null) {
                var state = duel.getPlayerState(player.getUniqueId());
                if (state != null) {
                    event.setRespawnLocation(state.getLocation());
                    return;
                }
            }
            // For pending restores where duel already removed, we cannot get location here
            // But the restore task will teleport after
        }
    }
}

