package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public final class InteractListener implements Listener {

    private final AuraDuel plugin;

    public InteractListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        Material type = block.getType();

        // Chest types
        if (plugin.getConfigManager().isBlockChestOpen()) {
            if (type.name().contains("CHEST") || type.name().contains("SHULKER_BOX") || type == Material.BARREL || type.toString().contains("CHEST")) {
                // chest, trapped chest, ender chest handling separate but here generic
                if (type == Material.ENDER_CHEST && plugin.getConfigManager().isBlockEnderChest()) {
                    event.setCancelled(true);
                    player.sendMessage(MessageUtil.parseWithPrefix(plugin.getMessagesManager().getRaw("restrictions.inventory-blocked"), player));
                    return;
                }
                if (type != Material.ENDER_CHEST) {
                    event.setCancelled(true);
                    player.sendMessage(MessageUtil.parseWithPrefix(plugin.getMessagesManager().getRaw("restrictions.inventory-blocked"), player));
                }
            }
        }

        if (plugin.getConfigManager().isBlockEnderChest() && type == Material.ENDER_CHEST) {
            event.setCancelled(true);
            player.sendMessage(MessageUtil.parseWithPrefix(plugin.getMessagesManager().getRaw("restrictions.inventory-blocked"), player));
        }
    }
}

