package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.duel.Duel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class PlayerDeathListener implements Listener {

    private final AuraDuel plugin;

    public PlayerDeathListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;

        Duel duel = plugin.getDuelManager().getDuel(player.getUniqueId());
        boolean betMode = duel != null && duel.isBetMode();
        boolean blockDrop = plugin.getConfigManager().isBlockDrop();

        if (betMode) {
            // Bahis modu: eÅŸyalar YERE DÃœÅMEZ (kimse yerden alamaz/kaybolmaz).
            // ...
            List<ItemStack> betLoot = new ArrayList<>();
            com.Auraduel.duel.PlayerState originalState = duel.getPlayerState(player.getUniqueId());
            if (originalState != null) {
                for (ItemStack item : originalState.getInventoryContents()) {
                    if (item != null && item.getType() != Material.AIR) betLoot.add(item.clone());
                }
                for (ItemStack item : originalState.getArmorContents()) {
                    if (item != null && item.getType() != Material.AIR) betLoot.add(item.clone());
                }
                ItemStack offHand = originalState.getOffHand();
                if (offHand != null && offHand.getType() != Material.AIR) betLoot.add(offHand.clone());
            } else {
                for (ItemStack item : player.getInventory().getContents()) {
                    if (item != null && item.getType() != Material.AIR) betLoot.add(item.clone());
                }
                for (ItemStack item : player.getInventory().getArmorContents()) {
                    if (item != null && item.getType() != Material.AIR) betLoot.add(item.clone());
                }
                ItemStack offHand = player.getInventory().getItemInOffHand();
                if (offHand.getType() != Material.AIR) betLoot.add(offHand.clone());
            }

            duel.setBetLoot(betLoot);

            event.getDrops().clear();
            event.setDroppedExp(0);
            event.setKeepInventory(true);
            player.getInventory().clear();
        } else if (blockDrop) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            event.setKeepInventory(true);
            player.getInventory().clear();
        } else {
            // Sunucuda keepInventory gamerule aÃ§Ä±ksa Bukkit drops listesini boÅŸ verir
            // ve envanteri temizlemez, yani bu modda hiÃ§bir ÅŸey dÃ¼ÅŸmez.
            // Bunu gÃ¶rmezden gelip dÃ¼ÅŸecek eÅŸyalarÄ± elle topluyoruz.
            List<ItemStack> forcedDrops = new ArrayList<>();
            for (ItemStack item : player.getInventory().getContents()) {
                if (item != null && item.getType() != Material.AIR) forcedDrops.add(item);
            }
            for (ItemStack item : player.getInventory().getArmorContents()) {
                if (item != null && item.getType() != Material.AIR) forcedDrops.add(item);
            }
            ItemStack offHand = player.getInventory().getItemInOffHand();
            if (offHand.getType() != Material.AIR) forcedDrops.add(offHand);

            event.getDrops().clear();
            event.getDrops().addAll(forcedDrops);
            event.setDroppedExp(player.getTotalExperience());

            player.getInventory().clear();
        }

        event.deathMessage(null);

        plugin.getDuelManager().endDuelByDeath(player);
    }
}

