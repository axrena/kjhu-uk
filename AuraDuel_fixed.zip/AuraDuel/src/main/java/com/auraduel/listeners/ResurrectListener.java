package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;

public final class ResurrectListener implements Listener {

    private final AuraDuel plugin;

    public ResurrectListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onResurrect(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        // Prevent totem usage during duel to keep fairness
        event.setCancelled(true);
    }
}

