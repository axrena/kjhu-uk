package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;

public final class GameModeAndFlightListener implements Listener {

    private final AuraDuel plugin;

    public GameModeAndFlightListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGameMode(PlayerGameModeChangeEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockGamemodeChange()) return;
        // Only cancel if not already being handled by restore? During restore we set gamemode, that would trigger event
        // So allow if new gamemode equals old stored? Simpler: if duel is finishing, allow
        var duel = plugin.getDuelManager().getDuel(player.getUniqueId());
        if (duel != null && duel.getState() == com.Auraduel.duel.DuelState.FINISHED) return;

        event.setCancelled(true);
        String raw = plugin.getMessagesManager().getRaw("restrictions.gamemode-blocked");
        player.sendMessage(MessageUtil.parseWithPrefix(raw, player));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFlightToggle(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;
        if (!plugin.getConfigManager().isBlockFlight()) return;

        var duel = plugin.getDuelManager().getDuel(player.getUniqueId());
        if (duel != null && duel.getState() == com.Auraduel.duel.DuelState.FINISHED) return;

        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
            // Allow gamemode based flight? But we block gamemode change anyway
            return;
        }

        if (event.isFlying()) {
            event.setCancelled(true);
            player.setFlying(false);
            player.setAllowFlight(false);
        }
    }
}

