package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import com.Auraduel.duel.Duel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerMoveListener implements Listener {

    private final AuraDuel plugin;
    // Performans: Border check throttling - her oyuncu iÃ§in son kontrol zamanÄ±
    private final Map<UUID, Long> lastBorderCheck = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastMessage = new ConcurrentHashMap<>();

    public PlayerMoveListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getDuelManager().isInDuel(player.getUniqueId())) return;

        Duel duel = plugin.getDuelManager().getDuel(player.getUniqueId());
        if (duel == null) return;

        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        if (from.getX() == to.getX() && from.getY() == to.getY() && from.getZ() == to.getZ()) {
            return;
        }

        switch (duel.getState()) {
            case COUNTDOWN -> {
                if (plugin.getConfigManager().isBlockMovementDuringCountdown() || plugin.getConfigManager().isFreezePlayers()) {
                    if (from.distanceSquared(to) > 0.01) {
                        event.setCancelled(true);
                        Location fixed = from.clone();
                        fixed.setYaw(to.getYaw());
                        fixed.setPitch(to.getPitch());
                        player.teleportAsync(fixed);
                    }
                }
            }
            case IN_PROGRESS -> {
                // Performans: Border check'i her 10 tick'te bir yap (0.5 sn throttling)
                // 200+ oyuncuda her tick her hareketi kontrol etmek pahalÄ±
                long now = System.currentTimeMillis();
                Long last = lastBorderCheck.get(player.getUniqueId());
                if (last != null && now - last < 400) { // 400ms = 8 tick
                    return;
                }
                lastBorderCheck.put(player.getUniqueId(), now);

                int maxDist = plugin.getConfigManager().getMaxDistanceFromArena();
                // O(1) cache'li isInside - merkez Ã¶nceden hesaplÄ±
                if (!duel.getArena().isInside(to, maxDist)) {
                    Location spawn = duel.getPlayer1().equals(player.getUniqueId()) ? duel.getArena().getSpawn1() : duel.getArena().getSpawn2();
                    if (spawn != null) {
                        event.setCancelled(true);
                        player.teleportAsync(spawn);
                        // Mesaj spamini engelle - 3 saniyede bir
                        Long lastMsg = lastMessage.get(player.getUniqueId());
                        if (lastMsg == null || now - lastMsg > 3000) {
                            String msgRaw = plugin.getMessagesManager().getRaw("arena.teleport-outside").replace("%distance%", String.valueOf(maxDist));
                            player.sendMessage(MessageUtil.parseWithPrefix(msgRaw, player));
                            lastMessage.put(player.getUniqueId(), now);
                        }
                    }
                }
            }
            default -> {}
        }
    }
}


