package com.Auraduel.listeners;

import com.Auraduel.AuraDuel;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerQuitListener implements Listener {

    private final AuraDuel plugin;

    public PlayerQuitListener(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        // Check if in duel -> auto lose
        if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
            plugin.getDuelManager().endDuelByQuit(player);
        }

        // Cleanup memory leaks
        plugin.getDuelManager().clearPreferences(player.getUniqueId());
        plugin.getDuelManager().handlePlayerQuit(player.getUniqueId());

        // Cleanup GUI tracking
        plugin.getGuiManager().unregisterOpen(player);
    }
}

