package com.Auraduel.config;

import com.Auraduel.AuraDuel;
import com.Auraduel.utils.MessageUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.List;

public final class MessagesManager {

    private final AuraDuel plugin;
    private FileConfiguration messages;
    private File file;

    public MessagesManager(AuraDuel plugin) {
        this.plugin = plugin;
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(file);

        // Eksik anahtarları kaynak dosyadan merge et (güncelleme sonrası eski dosyalar için)
        // NOT: getKeys(true) hem section'ları hem leaf key'leri döndürür.
        // messages.contains("arena") true olsa bile "arena.created" eksik olabilir.
        // Bu yüzden sadece gerçek değer taşıyan (section olmayan) leaf key'leri kontrol ediyoruz.
        var resource = plugin.getResource("messages.yml");
        if (resource != null) {
            var defaultMessages = YamlConfiguration.loadConfiguration(
                    new java.io.InputStreamReader(resource, java.nio.charset.StandardCharsets.UTF_8));
            boolean changed = false;
            for (String key : defaultMessages.getKeys(true)) {
                // Sadece leaf key'leri kontrol et — section key'lerini atla
                if (defaultMessages.isConfigurationSection(key)) continue;
                if (!messages.contains(key)) {
                    messages.set(key, defaultMessages.get(key));
                    changed = true;
                    plugin.getLogger().info("[MessagesManager] Eksik mesaj eklendi: " + key);
                }
            }
            if (changed) {
                try { messages.save(file); } catch (Exception e) {
                    plugin.getLogger().warning("[MessagesManager] messages.yml kaydedilemedi: " + e.getMessage());
                }
            }
        }

        // Cache prefix
        MessageUtil.setPrefix(getRaw("prefix"));
    }

    public FileConfiguration getMessages() {
        return messages;
    }

    public String getRaw(String path) {
        return messages.getString(path, "<red>Mesaj bulunamadi: " + path);
    }

    public String getRawOrNull(String path) {
        return messages.getString(path);
    }

    public List<String> getList(String path) {
        return messages.getStringList(path);
    }

    public Component getComponent(String path) {
        return MessageUtil.parse(getRaw(path));
    }

    public Component getComponent(String path, String... placeholders) {
        String raw = getRaw(path);
        for (int i = 0; i < placeholders.length - 1; i += 2) {
            raw = raw.replace(placeholders[i], placeholders[i + 1]);
        }
        return MessageUtil.parse(raw);
    }

    public Component getPrefixed(String path) {
        return MessageUtil.parseWithPrefix(getRaw(path));
    }

    public Component getPrefixed(String path, String... placeholders) {
        String raw = getRaw(path);
        for (int i = 0; i < placeholders.length - 1; i += 2) {
            raw = raw.replace(placeholders[i], placeholders[i + 1]);
        }
        return MessageUtil.parseWithPrefix(raw);
    }

    public List<Component> getComponentList(String path) {
        return getList(path).stream().map(MessageUtil::parse).toList();
    }

    public List<Component> getPrefixedList(String path) {
        return getList(path).stream().map(MessageUtil::parseWithPrefix).toList();
    }
}

