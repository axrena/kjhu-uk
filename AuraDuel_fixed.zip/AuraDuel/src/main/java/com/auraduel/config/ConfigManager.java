package com.Auraduel.config;

import com.Auraduel.AuraDuel;
import org.bukkit.Material;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

public final class ConfigManager {

    private final AuraDuel plugin;
    private FileConfiguration config;

    public ConfigManager(AuraDuel plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.config = plugin.getConfig();
    }

    public FileConfiguration getConfig() {
        return config;
    }

    public boolean isDebug() {
        return config.getBoolean("debug", false);
    }

    // Settings
    public int getRequestExpireSeconds() {
        return config.getInt("settings.request-expire-seconds", 30);
    }

    public int getCountdownSeconds() {
        return config.getInt("settings.countdown-seconds", 5);
    }

    public boolean isBlockMovementDuringCountdown() {
        return config.getBoolean("settings.block-movement-during-countdown", true);
    }

    public int getMaxDistanceFromArena() {
        return config.getInt("settings.max-distance-from-arena", 50);
    }

    public boolean isDisableHungerDuringDuel() {
        return config.getBoolean("settings.disable-hunger-during-duel", true);
    }

    // Duello bitince kazanan oyuncunun otomatik /spawn'a atilma suresi (saniye).
    // 0 = beklemeden hemen gonder. Kaybeden zaten respawn ekraniyla dogal olarak
    // bekletildigi icin ayri bir suresi yok, o direkt respawn olunca spawn'a gider.
    public int getWinnerSpawnDelaySeconds() {
        return config.getInt("duel.winner-spawn-delay-seconds", 60);
    }

    // Duel
    public boolean isHealOnStart() {
        return config.getBoolean("duel.heal-on-start", true);
    }

    public boolean isFeedOnStart() {
        return config.getBoolean("duel.feed-on-start", true);
    }

    public boolean isExtinguishFire() {
        return config.getBoolean("duel.extinguish-fire", true);
    }

    public boolean isClearPotionEffects() {
        return config.getBoolean("duel.clear-potion-effects", true);
    }

    public boolean isClearFireTicks() {
        return config.getBoolean("duel.clear-fire-ticks", true);
    }

    public boolean isResetFallDistance() {
        return config.getBoolean("duel.reset-fall-distance", true);
    }

    public boolean isResetVelocity() {
        return config.getBoolean("duel.reset-velocity", true);
    }

    public boolean isBlockCommands() {
        return config.getBoolean("duel.restrictions.block-commands", true);
    }

    public boolean isBlockTeleport() {
        return config.getBoolean("duel.restrictions.block-teleport", true);
    }

    public boolean isBlockBreak() {
        return config.getBoolean("duel.restrictions.block-break", true);
    }

    public boolean isBlockPlace() {
        return config.getBoolean("duel.restrictions.block-place", true);
    }

    public boolean isBlockDrop() {
        return config.getBoolean("duel.restrictions.block-drop", true);
    }

    public boolean isBlockPickup() {
        return config.getBoolean("duel.restrictions.block-pickup", true);
    }

    public boolean isBlockInventoryClick() {
        return config.getBoolean("duel.restrictions.block-inventory-click", true);
    }

    public boolean isBlockChestOpen() {
        return config.getBoolean("duel.restrictions.block-chest-open", true);
    }

    public boolean isBlockEnderChest() {
        return config.getBoolean("duel.restrictions.block-enderchest", true);
    }

    public boolean isBlockGamemodeChange() {
        return config.getBoolean("duel.restrictions.block-gamemode-change", true);
    }

    public boolean isBlockFlight() {
        return config.getBoolean("duel.restrictions.block-flight", true);
    }

    public List<String> getAllowedCommands() {
        return config.getStringList("duel.allowed-commands");
    }

    // Countdown
    public boolean isCountdownTitleEnabled() {
        return config.getBoolean("countdown.title-enabled", true);
    }

    public boolean isCountdownSubtitleEnabled() {
        return config.getBoolean("countdown.subtitle-enabled", true);
    }

    public boolean isCountdownActionbarEnabled() {
        return config.getBoolean("countdown.actionbar-enabled", true);
    }

    public boolean isCountdownBossbarEnabled() {
        return config.getBoolean("countdown.bossbar-enabled", true);
    }

    public BarColor getBossbarColor() {
        try {
            return BarColor.valueOf(config.getString("countdown.bossbar-color", "RED"));
        } catch (Exception e) {
            return BarColor.RED;
        }
    }

    public BarStyle getBossbarStyle() {
        try {
            return BarStyle.valueOf(config.getString("countdown.bossbar-style", "SOLID"));
        } catch (Exception e) {
            return BarStyle.SOLID;
        }
    }

    public boolean isCountdownSoundEnabled() {
        return config.getBoolean("countdown.sound-enabled", true);
    }

    public boolean isFreezePlayers() {
        return config.getBoolean("countdown.freeze-players", true);
    }

    // Effects
    public boolean isFireworkOnWin() {
        return config.getBoolean("effects.firework-on-win", true);
    }

    public int getFireworkAmount() {
        return config.getInt("effects.firework-amount", 3);
    }

    public String getSound(String path, String def) {
        return config.getString("effects.sounds." + path, def);
    }

    // GUI
    public boolean isDecorativeGlass() {
        return config.getBoolean("gui.decorative-glass", true);
    }

    public Material getGlassMaterial() {
        try {
            return Material.valueOf(config.getString("gui.glass-material", "BLACK_STAINED_GLASS_PANE"));
        } catch (Exception e) {
            return Material.BLACK_STAINED_GLASS_PANE;
        }
    }

    public int getArenaListRows() {
        return config.getInt("gui.arena-list-rows", 4);
    }

    public int getAdminGuiRows() {
        return config.getInt("gui.admin-gui-rows", 5);
    }

    public int getConfirmGuiRows() {
        return config.getInt("gui.confirm-gui-rows", 3);
    }

    public boolean isAsyncSave() {
        return config.getBoolean("performance.async-save", true);
    }

    // ==== GUI ile ayar deÄŸiÅŸtirme iÃ§in - config.yml yerine tÄ±klayarak aÃ§/kapat ====
    public void set(String path, Object value) {
        config.set(path, value);
        plugin.saveConfig();
        // config reference gÃ¼ncelle
        this.config = plugin.getConfig();
    }

    public void toggle(String path) {
        boolean current = config.getBoolean(path, true);
        set(path, !current);
    }

    public boolean getBoolean(String path, boolean def) {
        return config.getBoolean(path, def);
    }

    public void save() {
        plugin.saveConfig();
        this.config = plugin.getConfig();
    }
}

