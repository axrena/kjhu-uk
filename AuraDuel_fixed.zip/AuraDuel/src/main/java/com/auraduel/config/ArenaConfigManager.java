package com.Auraduel.config;

import com.Auraduel.AuraDuel;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

public final class ArenaConfigManager {

    private final AuraDuel plugin;
    private File file;
    private FileConfiguration config;

    public ArenaConfigManager(AuraDuel plugin) {
        this.plugin = plugin;
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "arenas.yml");
        if (!file.exists()) {
            plugin.saveResource("arenas.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(file);
    }

    public FileConfiguration getConfig() {
        return config;
    }

    public File getFile() {
        return file;
    }

    public void saveAsync() {
        if (file == null || config == null) return;
        CompletableFuture.runAsync(() -> {
            try {
                config.save(file);
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "arenas.yml kaydedilemedi async!", e);
            }
        });
    }

    public void saveSync() throws IOException {
        if (file == null || config == null) return;
        config.save(file);
    }

    public void save() {
        if (plugin.getConfigManager() != null && plugin.getConfigManager().isAsyncSave()) {
            saveAsync();
        } else {
            try {
                saveSync();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "arenas.yml kaydedilemedi!", e);
            }
        }
    }

    public void reload() {
        if (file != null) {
            config = YamlConfiguration.loadConfiguration(file);
        }
    }
}

