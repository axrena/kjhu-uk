package com.Auraduel.utils;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class ItemBuilder {

    private final ItemStack item;
    private final ItemMeta meta;

    public ItemBuilder(Material material) {
        this.item = new ItemStack(material);
        this.meta = item.getItemMeta();
    }

    public ItemBuilder(ItemStack base) {
        this.item = base.clone();
        this.meta = item.getItemMeta();
    }

    public ItemBuilder name(Component name) {
        if (meta != null) meta.displayName(name);
        return this;
    }

    public ItemBuilder lore(List<Component> lore) {
        if (meta != null) meta.lore(lore);
        return this;
    }

    public ItemBuilder lore(Component... lore) {
        if (meta != null) meta.lore(List.of(lore));
        return this;
    }

    public ItemBuilder addLore(Component line) {
        if (meta != null) {
            List<Component> current = meta.lore();
            if (current == null) current = new ArrayList<>();
            else current = new ArrayList<>(current);
            current.add(line);
            meta.lore(current);
        }
        return this;
    }

    public ItemBuilder amount(int amount) {
        item.setAmount(amount);
        return this;
    }

    public ItemBuilder enchant(Enchantment ench, int level) {
        if (meta != null) meta.addEnchant(ench, level, true);
        return this;
    }

    public ItemBuilder glowing(boolean glowing) {
        if (glowing && meta != null) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        return this;
    }

    public ItemBuilder flag(ItemFlag... flags) {
        if (meta != null) meta.addItemFlags(flags);
        return this;
    }

    public ItemBuilder unbreakable(boolean unbreakable) {
        if (meta != null) meta.setUnbreakable(unbreakable);
        return this;
    }

    public ItemBuilder customModel(int data) {
        if (meta != null) meta.setCustomModelData(data);
        return this;
    }

    public ItemStack build() {
        if (meta != null) item.setItemMeta(meta);
        return item;
    }
}

