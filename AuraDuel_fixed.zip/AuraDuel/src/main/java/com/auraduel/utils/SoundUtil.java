package com.Auraduel.utils;

import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {

    private SoundUtil() {}

    public static void play(Player player, String soundName, float volume, float pitch) {
        if (player == null || soundName == null) return;
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase());
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException ignored) {
            // Invalid sound
        }
    }

    public static void play(Player player, String soundName) {
        play(player, soundName, 1f, 1f);
    }

    public static void playBoth(Player p1, Player p2, String soundName, float volume, float pitch) {
        play(p1, soundName, volume, pitch);
        play(p2, soundName, volume, pitch);
    }
}

