package com.Auraduel.utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

public final class LocationUtil {

    private LocationUtil() {}

    public static void serialize(Location loc, ConfigurationSection section) {
        if (loc == null || section == null) return;
        section.set("world", loc.getWorld() != null ? loc.getWorld().getName() : "world");
        section.set("x", loc.getX());
        section.set("y", loc.getY());
        section.set("z", loc.getZ());
        section.set("yaw", loc.getYaw());
        section.set("pitch", loc.getPitch());
    }

    public static Location deserialize(ConfigurationSection section) {
        if (section == null) return null;
        String worldName = section.getString("world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        double x = section.getDouble("x");
        double y = section.getDouble("y");
        double z = section.getDouble("z");
        float yaw = (float) section.getDouble("yaw");
        float pitch = (float) section.getDouble("pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }

    public static String toString(Location loc) {
        if (loc == null) return "null";
        return String.format("%s %.1f %.1f %.1f", 
            loc.getWorld() != null ? loc.getWorld().getName() : "null",
            loc.getX(), loc.getY(), loc.getZ());
    }

    public static double distanceSquaredSafe(Location a, Location b) {
        if (a == null || b == null) return Double.MAX_VALUE;
        if (a.getWorld() == null || b.getWorld() == null) return Double.MAX_VALUE;
        if (!a.getWorld().equals(b.getWorld())) return Double.MAX_VALUE;
        return a.distanceSquared(b);
    }
}

