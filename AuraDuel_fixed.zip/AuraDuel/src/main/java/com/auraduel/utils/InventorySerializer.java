package com.Auraduel.utils;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

/**
 * Profesyonel Inventory Serialization
 * HiÃ§bir veri kaybolmaz: Enchant, Lore, DisplayName, ItemFlags, NBT, Attribute, PotionMeta, FireworkMeta, BannerMeta, Shield Pattern, Leather Color, Armor Trim, CustomModelData, MaxStack, Durability, RepairCost
 * BukkitObjectOutputStream kullanarak ItemStack[] Base64'e Ã§evrilir
 */
public final class InventorySerializer {

    private InventorySerializer() {}

    public static String itemStackArrayToBase64(ItemStack[] items) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(outputStream);
            dataOutput.writeInt(items.length);
            for (ItemStack item : items) {
                dataOutput.writeObject(item);
            }
            dataOutput.close();
            return Base64.getEncoder().encodeToString(outputStream.toByteArray());
        } catch (Exception e) {
            throw new IllegalStateException("Inventory Base64'e Ã§evrilemedi", e);
        }
    }

    public static ItemStack[] itemStackArrayFromBase64(String data) throws IOException {
        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(Base64.getDecoder().decode(data));
            BukkitObjectInputStream dataInput = new BukkitObjectInputStream(inputStream);
            int size = dataInput.readInt();
            ItemStack[] items = new ItemStack[size];
            for (int i = 0; i < size; i++) {
                items[i] = (ItemStack) dataInput.readObject();
            }
            dataInput.close();
            return items;
        } catch (ClassNotFoundException e) {
            throw new IOException("ItemStack decode edilemedi", e);
        }
    }

    public static String itemStackToBase64(ItemStack item) {
        return itemStackArrayToBase64(new ItemStack[]{item});
    }

    public static ItemStack itemStackFromBase64(String data) throws IOException {
        ItemStack[] arr = itemStackArrayFromBase64(data);
        return arr.length > 0 ? arr[0] : null;
    }
}

