package com.Auraduel.utils;

import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;

public final class MessageUtil {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static String prefix = "";
    private static boolean papiEnabled = false;

    private MessageUtil() {}

    public static void setPrefix(String p) {
        prefix = p != null ? p : "";
    }

    public static void checkPAPI() {
        papiEnabled = Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
    }

    public static Component parse(String raw) {
        if (raw == null || raw.isEmpty()) return Component.empty();
        // First check PAPI if needed later via parse with player
        // Support legacy & colors as fallback: convert if needed? MiniMessage handles legacy via translation
        // We'll parse MiniMessage directly
        try {
            return MINI_MESSAGE.deserialize(raw);
        } catch (Exception e) {
            // fallback legacy
            return LEGACY.deserialize(raw);
        }
    }

    public static Component parse(String raw, Player player) {
        if (raw == null) return Component.empty();
        String withPapi = applyPlaceholders(raw, player);
        return parse(withPapi);
    }

    public static Component parseWithPrefix(String raw) {
        if (raw == null) return Component.empty();
        return parse(prefix + raw);
    }

    public static Component parseWithPrefix(String raw, Player player) {
        if (raw == null) return Component.empty();
        String withPapi = applyPlaceholders(prefix + raw, player);
        return parse(withPapi);
    }

    public static Component parseWithPrefix(String raw, Player player, String... placeholders) {
        if (raw == null) return Component.empty();
        String replaced = replacePlaceholders(raw, placeholders);
        String withPapi = applyPlaceholders(prefix + replaced, player);
        return parse(withPapi);
    }

    public static String applyPlaceholders(String text, Player player) {
        if (papiEnabled && player != null) {
            try {
                return PlaceholderAPI.setPlaceholders(player, text);
            } catch (Exception ignored) {}
        }
        return text;
    }

    public static String replacePlaceholders(String text, String... placeholders) {
        if (placeholders == null || placeholders.length == 0) return text;
        String result = text;
        for (int i = 0; i < placeholders.length - 1; i += 2) {
            result = result.replace(placeholders[i], placeholders[i + 1]);
        }
        return result;
    }

    public static List<Component> parseList(List<String> raws) {
        return raws.stream().map(MessageUtil::parse).toList();
    }

    public static List<Component> parseList(List<String> raws, Player player) {
        return raws.stream().map(s -> parse(s, player)).toList();
    }

    public static String stripMiniMessage(String mini) {
        return MINI_MESSAGE.stripTags(mini);
    }
}

