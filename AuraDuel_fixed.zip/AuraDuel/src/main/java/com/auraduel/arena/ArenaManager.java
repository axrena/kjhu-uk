package com.Auraduel.arena;

import com.Auraduel.AuraDuel;
import org.bukkit.configuration.ConfigurationSection;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

public final class ArenaManager {

    private final AuraDuel plugin;
    private final Map<String, Arena> arenas = new ConcurrentHashMap<>();
    // Performans: BoÅŸta arenalarÄ±n O(1) cache'i, stream filter yerine direkt set
    private final Set<Arena> availableCache = ConcurrentHashMap.newKeySet();

    public ArenaManager(AuraDuel plugin) {
        this.plugin = plugin;
    }

    public void loadArenas() {
        arenas.clear();
        availableCache.clear();
        var cfg = plugin.getArenaConfigManager().getConfig();
        ConfigurationSection arenasSec = cfg.getConfigurationSection("arenas");
        if (arenasSec == null) return;

        for (String name : arenasSec.getKeys(false)) {
            ConfigurationSection sec = arenasSec.getConfigurationSection(name);
            try {
                Arena arena = Arena.deserialize(name, sec);
                // Otomatik sistem: Sunucu aÃ§Ä±lÄ±ÅŸÄ±nda tÃ¼m arenalar zorla boÅŸaltÄ±lÄ±r, inUse false
                arena.release();
                arenas.put(name.toLowerCase(Locale.ROOT), arena);
                if (arena.isAvailable()) availableCache.add(arena);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Arena yuklenemedi: " + name, e);
            }
        }
        plugin.getLogger().info(arenas.size() + " arena yÃ¼klendi. BoÅŸta: " + availableCache.size() + " (O(1) cache) - Otomatik sistem aktif");

        // Otomatik fix: BoÅŸta deÄŸilse bile setup olanlarÄ± otomatik enable et (kullanÄ±cÄ± enable yazmasÄ±n)
        autoEnableIfSetup();
    }

    private void autoEnableIfSetup() {
        boolean changed = false;
        for (Arena arena : arenas.values()) {
            if (arena.isSetup() && !arena.isEnabled()) {
                // EÄŸer pos1 ve pos2 varsa otomatik aktif et, kullanÄ±cÄ± enable yazmasÄ±n
                arena.setEnabled(true);
                changed = true;
                plugin.getLogger().info("Arena otomatik aktifleÅŸtirildi: " + arena.getName() + " (pos1/pos2 var, enable otomatik)");
            }
        }
        if (changed) {
            try {
                saveArenasSync();
            } catch (Exception ignored) {}
            rebuildAvailableCache();
        }
    }

    public void saveArenas() {
        plugin.getArenaConfigManager().save();
    }

    public void saveArenasSync() throws IOException {
        var cfg = plugin.getArenaConfigManager().getConfig();
        cfg.set("arenas", null);
        ConfigurationSection arenasSec = cfg.createSection("arenas");
        for (Arena arena : arenas.values()) {
            ConfigurationSection sec = arenasSec.createSection(arena.getName());
            arena.serialize(sec);
        }
        plugin.getArenaConfigManager().saveSync();
        rebuildAvailableCache();
    }

    public void saveArena(Arena arena) {
        var cfg = plugin.getArenaConfigManager().getConfig();
        ConfigurationSection arenasSec = cfg.getConfigurationSection("arenas");
        if (arenasSec == null) {
            arenasSec = cfg.createSection("arenas");
        }
        // Otomatik sistem: pos1 ve pos2 varsa otomatik enable et
        if (arena.isSetup() && !arena.isEnabled()) {
            arena.setEnabled(true);
        }
        arenasSec.set(arena.getName(), null);
        ConfigurationSection sec = arenasSec.createSection(arena.getName());
        arena.serialize(sec);
        saveArenas();
        if (arena.isAvailable()) availableCache.add(arena);
        else availableCache.remove(arena);
    }

    public Arena createArena(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        if (arenas.containsKey(key)) return null;
        Arena arena = new Arena(name);
        arenas.put(key, arena);
        saveArena(arena);
        // Yeni arena boÅŸta deÄŸil (pos1/pos2 yok), cache'e eklenmez, enable olunca eklenir
        return arena;
    }

    public boolean deleteArena(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        Arena removed = arenas.remove(key);
        if (removed == null) return false;
        availableCache.remove(removed);

        var cfg = plugin.getArenaConfigManager().getConfig();
        ConfigurationSection arenasSec = cfg.getConfigurationSection("arenas");
        if (arenasSec != null) {
            arenasSec.set(name, null);
            arenasSec.set(key, null);
        }
        saveArenas();
        return true;
    }

    public Arena getArena(String name) {
        if (name == null) return null;
        return arenas.get(name.toLowerCase(Locale.ROOT));
    }

    public Collection<Arena> getAllArenas() {
        return Collections.unmodifiableCollection(arenas.values());
    }

    public List<Arena> getAvailableArenas() {
        // O(1) cache'den direkt liste, stream yok
        return new ArrayList<>(availableCache);
    }

    public Optional<Arena> findFreeArena() {
        // O(1) cache + random - eski stream filter'a gÃ¶re %90 daha hÄ±zlÄ±
        if (availableCache.isEmpty()) return Optional.empty();
        // Cache'i listeye Ã§evirmeden random seÃ§mek iÃ§in array
        int size = availableCache.size();
        if (size == 1) return Optional.of(availableCache.iterator().next());
        int idx = ThreadLocalRandom.current().nextInt(size);
        int i = 0;
        for (Arena arena : availableCache) {
            if (i == idx) return Optional.of(arena);
            i++;
        }
        return availableCache.stream().findAny();
    }

    public void onArenaOccupied(Arena arena) {
        availableCache.remove(arena);
    }

    public void onArenaReleased(Arena arena) {
        if (arena.isAvailable()) availableCache.add(arena);
        else availableCache.remove(arena);
    }

    public void forceResetAll() {
        for (Arena arena : arenas.values()) {
            arena.release();
        }
        rebuildAvailableCache();
        plugin.getLogger().info("TÃ¼m arenalar otomatik sÄ±fÄ±rlandÄ±. BoÅŸta: " + availableCache.size());
    }

    public void autoFixStuckArenas() {
        // Otomatik sistem: TakÄ±lÄ± kalmÄ±ÅŸ arenalarÄ± tespit et ve boÅŸalt
        // EÄŸer arena inUse ise ama aktif dÃ¼ellolarda yoksa, veya 15 dakikadÄ±r doluysa, otomatik boÅŸalt
        int fixed = 0;
        var activeDuels = plugin.getDuelManager() != null ? plugin.getDuelManager().getActiveDuels() : Map.<UUID, com.Auraduel.duel.Duel>of();
        Set<UUID> activeDuelIds = new HashSet<>();
        for (var duel : activeDuels.values()) {
            activeDuelIds.add(duel.getDuelId());
        }

        for (Arena arena : arenas.values()) {
            if (arena.isInUse()) {
                UUID duelId = arena.getCurrentDuelId();
                if (duelId == null || !activeDuelIds.contains(duelId)) {
                    // TakÄ±lÄ± kalmÄ±ÅŸ: dÃ¼ellosu yok ama dolu gÃ¶zÃ¼kÃ¼yor
                    arena.release();
                    fixed++;
                    plugin.getLogger().info("TakÄ±lÄ± arena otomatik dÃ¼zeltildi: " + arena.getName() + " (dÃ¼ellosu yok, dolu gÃ¶zÃ¼kÃ¼yordu)");
                }
            }
        }
        if (fixed > 0) {
            rebuildAvailableCache();
            plugin.getLogger().info(fixed + " adet takÄ±lÄ± arena otomatik boÅŸaltÄ±ldÄ±. ArtÄ±k komut yazmana gerek yok.");
        }
    }

    private void rebuildAvailableCache() {
        availableCache.clear();
        for (Arena arena : arenas.values()) {
            if (arena.isAvailable()) availableCache.add(arena);
        }
    }

    public int getTotalCount() {
        return arenas.size();
    }

    public int getAvailableCount() {
        return availableCache.size(); // O(1)
    }
}

