package com.Auraduel.arena;

import com.Auraduel.utils.LocationUtil;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public final class Arena {

    private final String name;
    private String worldName;
    private Location spawn1;
    private Location spawn2;
    private Location lobby;

    private boolean enabled;
    private final AtomicBoolean inUse = new AtomicBoolean(false);
    private UUID currentDuelId;

    // Performans cache - merkez ve izin verilen uzaklÄ±k karesi Ã¶nceden hesaplanÄ±r
    private transient Location cachedCenter = null;
    private transient double cachedAllowedSquared = -1;
    private transient boolean cacheDirty = true;

    public Arena(@NotNull String name) {
        this.name = name;
        this.enabled = false;
    }

    public Arena(@NotNull String name, @Nullable Location spawn1, @Nullable Location spawn2, @Nullable Location lobby, boolean enabled) {
        this.name = name;
        this.spawn1 = spawn1;
        this.spawn2 = spawn2;
        this.lobby = lobby;
        this.enabled = enabled;
        if (spawn1 != null && spawn1.getWorld() != null) {
            this.worldName = spawn1.getWorld().getName();
        } else if (spawn2 != null && spawn2.getWorld() != null) {
            this.worldName = spawn2.getWorld().getName();
        }
        markCacheDirty();
    }

    private void markCacheDirty() {
        cacheDirty = true;
        cachedCenter = null;
        cachedAllowedSquared = -1;
    }

    private void recalculateCache(int maxDistance) {
        if (!cacheDirty && cachedCenter != null && cachedAllowedSquared >= 0) return;
        if (spawn1 == null || spawn2 == null) {
            cachedCenter = spawn1 != null ? spawn1 : spawn2;
            cachedAllowedSquared = (double) maxDistance * maxDistance;
            cacheDirty = false;
            return;
        }
        if (!Objects.equals(spawn1.getWorld(), spawn2.getWorld())) {
            cachedCenter = spawn1;
            cachedAllowedSquared = (double) maxDistance * maxDistance;
            cacheDirty = false;
            return;
        }
        double x = (spawn1.getX() + spawn2.getX()) / 2.0;
        double y = (spawn1.getY() + spawn2.getY()) / 2.0;
        double z = (spawn1.getZ() + spawn2.getZ()) / 2.0;
        cachedCenter = new Location(spawn1.getWorld(), x, y, z);
        double maxSq = (double) maxDistance * maxDistance;
        double spawnDist = spawn1.distanceSquared(spawn2);
        cachedAllowedSquared = Math.max(maxSq, spawnDist * 1.5);
        cacheDirty = false;
    }

    // Getters / Setters
    public String getName() {
        return name;
    }

    public String getWorldName() {
        return worldName;
    }

    public void setWorldName(String worldName) {
        this.worldName = worldName;
    }

    public Location getSpawn1() {
        return spawn1;
    }

    public void setSpawn1(Location spawn1) {
        this.spawn1 = spawn1;
        if (spawn1 != null && spawn1.getWorld() != null) {
            this.worldName = spawn1.getWorld().getName();
        }
        markCacheDirty();
    }

    public Location getSpawn2() {
        return spawn2;
    }

    public void setSpawn2(Location spawn2) {
        this.spawn2 = spawn2;
        if (worldName == null && spawn2 != null && spawn2.getWorld() != null) {
            this.worldName = spawn2.getWorld().getName();
        }
        markCacheDirty();
    }

    public Location getLobby() {
        return lobby;
    }

    public void setLobby(Location lobby) {
        this.lobby = lobby;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isInUse() {
        return inUse.get();
    }

    public boolean isAvailable() {
        return enabled && !inUse.get() && isSetup();
    }

    public boolean isSetup() {
        return spawn1 != null && spawn2 != null && spawn1.getWorld() != null && spawn2.getWorld() != null;
    }

    public boolean tryOccupy(UUID duelId) {
        if (inUse.compareAndSet(false, true)) {
            this.currentDuelId = duelId;
            return true;
        }
        return false;
    }

    public void release() {
        inUse.set(false);
        currentDuelId = null;
    }

    public UUID getCurrentDuelId() {
        return currentDuelId;
    }

    public Location getCenter() {
        if (cachedCenter != null && !cacheDirty) return cachedCenter;
        if (spawn1 == null || spawn2 == null) return spawn1 != null ? spawn1 : spawn2;
        if (!Objects.equals(spawn1.getWorld(), spawn2.getWorld())) return spawn1;
        double x = (spawn1.getX() + spawn2.getX()) / 2.0;
        double y = (spawn1.getY() + spawn2.getY()) / 2.0;
        double z = (spawn1.getZ() + spawn2.getZ()) / 2.0;
        cachedCenter = new Location(spawn1.getWorld(), x, y, z);
        cacheDirty = false;
        return cachedCenter;
    }

    public boolean isInside(Location loc, int maxDistance) {
        if (loc == null || loc.getWorld() == null) return false;
        if (spawn1 == null || spawn2 == null) return true;
        if (!loc.getWorld().equals(spawn1.getWorld())) return false;

        recalculateCache(maxDistance);
        if (cachedCenter == null) return true;
        if (!cachedCenter.getWorld().equals(loc.getWorld())) return false;
        // distanceSquared en ucuz hesaplama
        double distanceSq = cachedCenter.distanceSquared(loc);
        return distanceSq <= cachedAllowedSquared;
    }

    public void serialize(ConfigurationSection section) {
        if (spawn1 != null) {
            ConfigurationSection pos1Sec = section.createSection("pos1");
            LocationUtil.serialize(spawn1, pos1Sec);
        }
        if (spawn2 != null) {
            ConfigurationSection pos2Sec = section.createSection("pos2");
            LocationUtil.serialize(spawn2, pos2Sec);
        }
        if (lobby != null) {
            ConfigurationSection lobbySec = section.createSection("lobby");
            LocationUtil.serialize(lobby, lobbySec);
        }
        if (worldName != null) {
            section.set("world", worldName);
        }
        section.set("enabled", enabled);
    }

    public static Arena deserialize(String name, ConfigurationSection section) {
        Arena arena = new Arena(name);
        if (section == null) return arena;

        ConfigurationSection pos1Sec = section.getConfigurationSection("pos1");
        ConfigurationSection pos2Sec = section.getConfigurationSection("pos2");
        ConfigurationSection lobbySec = section.getConfigurationSection("lobby");

        arena.setSpawn1(LocationUtil.deserialize(pos1Sec));
        arena.setSpawn2(LocationUtil.deserialize(pos2Sec));
        arena.setLobby(LocationUtil.deserialize(lobbySec));
        arena.setWorldName(section.getString("world", arena.getWorldName()));
        arena.setEnabled(section.getBoolean("enabled", false));

        return arena;
    }
}

