package com.Auraduel.commands;

import com.Auraduel.AuraDuel;
import com.Auraduel.arena.Arena;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DuelTabCompleter implements TabCompleter {

    private final AuraDuel plugin;

    private final List<String> MAIN_SUBS = List.of("invite", "kabul", "red", "durum", "create", "delete", "edit", "arenas", "kit", "kits", "settings", "reload", "gui");
    private final List<String> EDIT_SUBS = List.of("pos1", "pos2", "enable", "disable");
    private final List<String> KIT_SUBS = List.of("list", "gui", "create", "edit", "save", "load", "delete", "rename", "icon", "setname");

    public DuelTabCompleter(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {

        if (!(sender instanceof Player)) return List.of();

        if (args.length == 1) {
            String input = args[0].toLowerCase(Locale.ROOT);
            List<String> out = new ArrayList<>();
            for (String sub : MAIN_SUBS) {
                if (sub.toLowerCase(Locale.ROOT).startsWith(input)) {
                    if (sub.equals("create") || sub.equals("delete") || sub.equals("edit") || sub.equals("reload") || sub.equals("gui") || sub.equals("kit")) {
                        if (!sender.hasPermission("duel.admin")) {
                            if (sub.equals("kit")) {
                                // kit list herkes gÃ¶rebilir ama create/delete admin
                                // yine de gÃ¶ster
                            } else {
                                continue;
                            }
                        }
                    }
                    out.add(sub);
                }
            }
            return out;
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            String input = args[1].toLowerCase(Locale.ROOT);
            List<String> out = new ArrayList<>();

            if (sub.equals("invite")) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getName().toLowerCase(Locale.ROOT).startsWith(input) && !p.equals(sender)) {
                        out.add(p.getName());
                    }
                }
            } else if (sub.equals("create")) {
                return List.of("<arena>");
            } else if (sub.equals("delete") || sub.equals("edit")) {
                for (Arena arena : plugin.getArenaManager().getAllArenas()) {
                    if (arena.getName().toLowerCase(Locale.ROOT).startsWith(input)) {
                        out.add(arena.getName());
                    }
                }
            } else if (sub.equals("arenas") || sub.equals("arena")) {
                if (sender.hasPermission("duel.admin")) {
                    if ("reset".startsWith(input)) out.add("reset");
                    if ("list".startsWith(input)) out.add("list");
                }
            } else if (sub.equals("gui")) {
                if (sender.hasPermission("duel.admin")) {
                    if ("admin".startsWith(input)) out.add("admin");
                    if ("settings".startsWith(input)) out.add("settings");
                }
            } else if (sub.equals("kit")) {
                for (String k : KIT_SUBS) {
                    if (k.startsWith(input)) out.add(k);
                }
            }
            return out;
        }

        if (args.length == 3) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            String sub2 = args[1].toLowerCase(Locale.ROOT);
            if (sub.equals("edit")) {
                String input = args[2].toLowerCase(Locale.ROOT);
                List<String> out = new ArrayList<>();
                for (String e : EDIT_SUBS) {
                    if (e.startsWith(input)) out.add(e);
                }
                return out;
            }
            if (sub.equals("kit") || sub.equals("kits")) {
                String input = args[2].toLowerCase(Locale.ROOT);
                if (sub2.equals("delete") || sub2.equals("edit") || sub2.equals("save") || sub2.equals("load") || sub2.equals("seticon") || sub2.equals("icon") || sub2.equals("setname") || sub2.equals("rename")) {
                    List<String> out = new ArrayList<>();
                    for (String kitId : plugin.getKitManager().getKitIds()) {
                        if (kitId.startsWith(input)) out.add(kitId);
                    }
                    return out;
                }
                if (sub2.equals("create")) {
                    return List.of("<kit-id>");
                }
            }
        }

        return List.of();
    }
}

