package com.Auraduel.commands;

import com.Auraduel.AuraDuel;
import com.Auraduel.arena.Arena;
import com.Auraduel.duel.Duel;
import com.Auraduel.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.Locale;

public final class DuelCommand implements CommandExecutor {

    private final AuraDuel plugin;

    public DuelCommand(AuraDuel plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().getComponent("only-players"));
            return true;
        }
        if (args.length == 0) {
            sendHelp(player);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "invite", "istek", "davet" -> handleInvite(player, args);
            case "kabul", "accept", "kabulet" -> handleAccept(player);
            case "red", "redd", "deny", "decline" -> handleDeny(player);
            case "durum", "status", "bilgi" -> handleStatus(player);
            case "create", "olustur", "oluÅŸtur" -> handleCreate(player, args);
            case "delete", "sil", "remove" -> handleDelete(player, args);
            case "edit", "duzenle", "dÃ¼zenle" -> handleEdit(player, args);
            case "arenas", "arena", "list" -> handleArenas(player, args);
            case "kit", "kitler", "kits" -> handleKit(player, args);
            case "settings", "ayarlar", "ayarla" -> handleSettings(player);
            case "reload", "yenile" -> handleReload(player);
            case "gui", "menu" -> handleGui(player, args);
            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player player) {
        var mm = plugin.getMessagesManager();
        for (String line : mm.getList("duel.help")) {
            player.sendMessage(MessageUtil.parse(line, player));
        }
    }

    private void handleInvite(Player player, String[] args) {
        if (!player.hasPermission("duel.use")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("invalid-usage", "<usage>", "/duel invite <oyuncu>"));
            return;
        }
        String targetName = args[1];
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) target = Bukkit.getPlayer(targetName);
        if (target == null) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("player-not-found", "%target%", targetName));
            return;
        }
        if (player.getUniqueId().equals(target.getUniqueId())) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("duel.self-request"));
            return;
        }
        if (plugin.getDuelManager().isInDuel(player.getUniqueId())) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("duel.already-in-duel"));
            return;
        }
        if (plugin.getDuelManager().isInDuel(target.getUniqueId())) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("duel.target-already-in-duel", "%target%", target.getName()));
            return;
        }
        boolean useGui = plugin.getConfigManager().getConfig().getBoolean("gui.enabled", true);
        boolean forceDirect = args.length >= 3 && args[2].equalsIgnoreCase("-direct");
        if (useGui && !forceDirect) {
            plugin.getGuiManager().openDuelSetupGUI(player, target);
            return;
        }
        var result = plugin.getDuelManager().sendRequest(player, target);
        var mm = plugin.getMessagesManager();
        switch (result.result) {
            case SELF -> player.sendMessage(mm.getPrefixed("duel.self-request"));
            case OFFLINE -> player.sendMessage(mm.getPrefixed("duel.offline-target", "%target%", targetName));
            case ALREADY_IN_DUEL -> player.sendMessage(mm.getPrefixed("duel.already-in-duel"));
            case TARGET_ALREADY_IN_DUEL -> player.sendMessage(mm.getPrefixed("duel.target-already-in-duel", "%target%", target.getName()));
            case ALREADY_SENT -> player.sendMessage(mm.getPrefixed("duel.already-sent-request"));
            case TARGET_HAS_PENDING -> player.sendMessage(mm.getPrefixed("duel.target-has-pending", "%target%", target.getName()));
            case SAME_DUEL_BLOCK -> player.sendMessage(mm.getPrefixed("duel.same-arena-duel-block", "%target%", target.getName()));
            case SUCCESS -> {}
        }
    }

    private void handleAccept(Player player) {
        if (!player.hasPermission("duel.use")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        var dm = plugin.getDuelManager();
        if (!dm.hasPendingRequest(player.getUniqueId())) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("duel.no-pending-request"));
            return;
        }
        boolean ok = dm.acceptRequest(player);
        if (!ok) player.sendMessage(plugin.getMessagesManager().getPrefixed("duel.no-pending-request"));
    }

    private void handleDeny(Player player) {
        if (!player.hasPermission("duel.use")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        boolean ok = plugin.getDuelManager().denyRequest(player);
        if (!ok) player.sendMessage(plugin.getMessagesManager().getPrefixed("duel.no-pending-request"));
    }

    private void handleStatus(Player player) {
        var dm = plugin.getDuelManager();
        var mm = plugin.getMessagesManager();
        Duel duel = dm.getDuel(player.getUniqueId());
        if (duel != null) {
            Player opponent = null;
            var oppId = duel.getOpponent(player.getUniqueId());
            if (oppId != null) opponent = Bukkit.getPlayer(oppId);
            String oppName = opponent != null ? opponent.getName() : (oppId != null ? Bukkit.getOfflinePlayer(oppId).getName() : "Bilinmiyor");
            player.sendMessage(mm.getComponent("duel.status.in-duel-title"));
            for (String line : mm.getList("duel.status.in-duel")) {
                String replaced = line.replace("%target%", oppName != null ? oppName : "Bilinmiyor").replace("%arena%", duel.getArena() != null ? duel.getArena().getName() : "Bilinmiyor").replace("%kit%", duel.getSelectedKit()).replace("<state>", duel.getState().name()).replace("<time>", duel.getDurationSeconds() + "s");
                player.sendMessage(MessageUtil.parse(replaced, player));
            }
            return;
        }
        var received = dm.getReceivedRequest(player.getUniqueId());
        var sent = dm.getSentRequest(player.getUniqueId());
        if (received.isPresent() && !received.get().isExpired()) {
            var req = received.get();
            Player reqPlayer = Bukkit.getPlayer(req.getRequester());
            String reqName = reqPlayer != null ? reqPlayer.getName() : Bukkit.getOfflinePlayer(req.getRequester()).getName();
            String msg = mm.getRaw("duel.status.pending-request").replace("%target%", reqName != null ? reqName : "Bilinmiyor").replace("%player%", player.getName()).replace("%time%", String.valueOf(req.getRemainingSeconds())).replace("%arena%", plugin.getDuelManager().getArenaPreference(req.getRequester()).orElse("Rastgele")).replace("%kit%", plugin.getDuelManager().getKitPreference(req.getRequester()));
            player.sendMessage(MessageUtil.parse(msg, player));
        } else if (sent.isPresent() && !sent.get().isExpired()) {
            var req = sent.get();
            Player tarPlayer = Bukkit.getPlayer(req.getTarget());
            String tarName = tarPlayer != null ? tarPlayer.getName() : Bukkit.getOfflinePlayer(req.getTarget()).getName();
            String msg = mm.getRaw("duel.status.pending-request").replace("%target%", tarName != null ? tarName : "Bilinmiyor").replace("%player%", player.getName()).replace("%time%", String.valueOf(req.getRemainingSeconds())).replace("%arena%", plugin.getDuelManager().getArenaPreference(player.getUniqueId()).orElse("Rastgele")).replace("%kit%", plugin.getDuelManager().getKitPreference(player.getUniqueId()));
            player.sendMessage(MessageUtil.parse(msg, player));
        } else {
            player.sendMessage(mm.getPrefixed("duel.status.not-in-duel"));
            if (received.isEmpty() && sent.isEmpty()) player.sendMessage(mm.getPrefixed("duel.status.no-request"));
        }
    }

    private void handleCreate(Player player, String[] args) {
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("invalid-usage", "<usage>", "/duel create <arena>"));
            return;
        }
        String name = args[1];
        if (plugin.getArenaManager().getArena(name) != null) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("arena.already-exists", "%arena%", name));
            return;
        }
        Arena arena = plugin.getArenaManager().createArena(name);
        if (arena != null) player.sendMessage(plugin.getMessagesManager().getPrefixed("arena.created", "%arena%", name));
        else player.sendMessage(plugin.getMessagesManager().getPrefixed("error-occurred", "<error>", "Arena olusturulamadi"));
    }

    private void handleDelete(Player player, String[] args) {
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("invalid-usage", "<usage>", "/duel delete <arena>"));
            return;
        }
        String name = args[1];
        if (plugin.getArenaManager().deleteArena(name)) player.sendMessage(plugin.getMessagesManager().getPrefixed("arena.deleted", "%arena%", name));
        else player.sendMessage(plugin.getMessagesManager().getPrefixed("arena-not-found", "%arena%", name));
    }

    private void handleEdit(Player player, String[] args) {
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        if (args.length < 3) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("invalid-usage", "<usage>", "/duel edit <arena> <pos1/pos2/enable/disable>"));
            return;
        }
        String arenaName = args[1];
        String action = args[2].toLowerCase(Locale.ROOT);
        Arena arena = plugin.getArenaManager().getArena(arenaName);
        if (arena == null) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("arena-not-found", "%arena%", arenaName));
            return;
        }
        if (arena.isInUse()) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("arena.in-use"));
            return;
        }
        var mm = plugin.getMessagesManager();
        Location loc = player.getLocation();
        switch (action) {
            case "pos1", "1", "spawn1" -> {
                arena.setSpawn1(loc);
                plugin.getArenaManager().saveArena(arena);
                player.sendMessage(mm.getPrefixed("arena.pos1-set", "%arena%", arena.getName(), "%world%", loc.getWorld() != null ? loc.getWorld().getName() : "null", "%x%", String.format("%.1f", loc.getX()), "%y%", String.format("%.1f", loc.getY()), "%z%", String.format("%.1f", loc.getZ())));
            }
            case "pos2", "2", "spawn2" -> {
                arena.setSpawn2(loc);
                plugin.getArenaManager().saveArena(arena);
                player.sendMessage(mm.getPrefixed("arena.pos2-set", "%arena%", arena.getName(), "%world%", loc.getWorld() != null ? loc.getWorld().getName() : "null", "%x%", String.format("%.1f", loc.getX()), "%y%", String.format("%.1f", loc.getY()), "%z%", String.format("%.1f", loc.getZ())));
            }
            case "enable", "aktif", "ac", "aÃ§" -> {
                if (!arena.isSetup()) {
                    player.sendMessage(mm.getPrefixed("arena.not-setup"));
                    return;
                }
                arena.setEnabled(true);
                plugin.getArenaManager().saveArena(arena);
                player.sendMessage(mm.getPrefixed("arena.enabled", "%arena%", arena.getName()));
            }
            case "disable", "pasif", "kapat", "deaktif" -> {
                arena.setEnabled(false);
                plugin.getArenaManager().saveArena(arena);
                player.sendMessage(mm.getPrefixed("arena.disabled", "%arena%", arena.getName()));
            }
            default -> player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel edit <arena> <pos1/pos2/enable/disable>"));
        }
    }

    private void handleArenas(Player player, String[] args) {
        var mm = plugin.getMessagesManager();

        // Reset subcommand - DOLU bug'Ä± iÃ§in
        if (args.length >= 2 && args[1].equalsIgnoreCase("reset")) {
            if (!player.hasPermission("duel.admin")) {
                player.sendMessage(mm.getPrefixed("no-permission"));
                return;
            }
            plugin.getArenaManager().forceResetAll();
            player.sendMessage(MessageUtil.parseWithPrefix("<green>TÃ¼m arenalar zorla boÅŸaltÄ±ldÄ±! BoÅŸta: " + plugin.getArenaManager().getAvailableCount() + "/" + plugin.getArenaManager().getTotalCount(), player));
            return;
        }

        // EÄŸer tek argÃ¼man yoksa, normal arenas komutu
        // handleArenas(player) called from switch with only one arg, but we support reset via /duel arenas reset
        // For /duel arenas we need to check if args[1] is reset, handle above
        Collection<Arena> all = plugin.getArenaManager().getAllArenas();
        if (all.isEmpty()) {
            player.sendMessage(mm.getPrefixed("arena.list-empty"));
            return;
        }
        String titleRaw = mm.getRaw("arena.list-title").replace("%count%", String.valueOf(all.size()));
        player.sendMessage(MessageUtil.parse(titleRaw, player));
        for (Arena arena : all) {
            String statusKey = arena.isEnabled() ? "arena.status-enabled" : "arena.status-disabled";
            String inuseKey = arena.isInUse() ? "arena.inuse-yes" : "arena.inuse-no";
            String formatRaw = mm.getRaw("arena.list-format");
            String statusMini = mm.getRaw(statusKey);
            String inuseMini = mm.getRaw(inuseKey);
            String line = formatRaw.replace("%arena%", arena.getName()).replace("%world%", arena.getWorldName() != null ? arena.getWorldName() : "Bilinmiyor").replace("<status>", statusMini).replace("<inuse>", inuseMini);
            player.sendMessage(MessageUtil.parse(line, player));
        }
        if (player.hasPermission("duel.admin")) {
            player.sendMessage(MessageUtil.parseWithPrefix("<gray>Toplam: <white>" + plugin.getArenaManager().getTotalCount() + " <gray>BoÅŸta: <green>" + plugin.getArenaManager().getAvailableCount() + " <gray>Dolu: <red>" + (plugin.getArenaManager().getTotalCount() - plugin.getArenaManager().getAvailableCount()) + " <gray>- Reset iÃ§in: <white>/duel arenas reset", player));
            player.sendMessage(MessageUtil.parseWithPrefix("<gray>Ayarlar GUI: <white>/duel settings <gray>veya <white>/duel gui settings", player));
        }
    }

    private void handleSettings(Player player) {
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        plugin.getGuiManager().openGlobalSettingsGUI(player);
    }

    private void handleReload(Player player) {
        if (!player.hasPermission("duel.admin")) {
            player.sendMessage(plugin.getMessagesManager().getPrefixed("no-permission"));
            return;
        }
        plugin.reload();
        player.sendMessage(plugin.getMessagesManager().getPrefixed("config-reloaded"));
    }

    // ================= KIT KOMUTLARI - PROFESYONEL =================
    private void handleKit(Player player, String[] args) {
        var mm = plugin.getMessagesManager();
        var kitManager = plugin.getKitManager();

        if (args.length == 1) {
            if (player.hasPermission("duel.admin")) plugin.getGuiManager().openKitManagementGUI(player);
            else sendKitList(player);
            return;
        }

        String subKit = args[1].toLowerCase(Locale.ROOT);
        switch (subKit) {
            case "list", "liste" -> {
                if (args.length >= 3 && args[2].equalsIgnoreCase("gui")) plugin.getGuiManager().openKitManagementGUI(player);
                else sendKitList(player);
            }
            case "gui", "menu" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                plugin.getGuiManager().openKitManagementGUI(player);
            }
            case "create", "olustur", "oluÅŸtur", "ekle" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    plugin.getGuiManager().startKitCreationFlow(player);
                    return;
                }
                String id = args[2];
                if (kitManager.getKit(id).isPresent()) {
                    player.sendMessage(mm.getPrefixed("kit.already-exists", "%kit%", id));
                    return;
                }
                boolean created = kitManager.createEmptyKit(id);
                if (created) {
                    player.sendMessage(mm.getPrefixed("kit.created", "%kit%", id));
                    player.sendMessage(MessageUtil.parseWithPrefix("<#1E3A8A>â–¸ <gray>BoÅŸ kit oluÅŸturuldu! <white>/duel kit edit " + id + "</white> ile dÃ¼zenle, <white>/duel kit save " + id + "</white> ile envanterini kaydet. Database: kits.yml", player));
                    kitManager.enterEditMode(player.getUniqueId(), id);
                    plugin.getGuiManager().openKitEditorGUI(player, kitManager.getKit(id).get());
                } else {
                    player.sendMessage(mm.getPrefixed("error-occurred", "<error>", "Kit oluÅŸturulamadÄ±"));
                }
            }
            case "edit", "duzenle", "dÃ¼zenle" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel kit edit <id> - Admin dÃ¼zenleme moduna girer"));
                    return;
                }
                String id = args[2];
                if (kitManager.getKit(id).isEmpty()) {
                    player.sendMessage(mm.getPrefixed("kit.not-found", "%kit%", id));
                    return;
                }
                kitManager.enterEditMode(player.getUniqueId(), id);
                player.sendMessage(MessageUtil.parseWithPrefix("<gradient:#0A1931:#3B82F6>âœ Edit Modu:</gradient> <white>" + id + "</white> <gray>kitini dÃ¼zenliyorsun. DeÄŸiÅŸiklikler sadece bu kite uygulanÄ±r.", player));
                plugin.getGuiManager().openKitEditorGUI(player, kitManager.getKit(id).get());
            }
            case "save", "kaydet" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel kit save <id> - Envanterini kit olarak kaydeder (tÃ¼m NBT korunur)"));
                    return;
                }
                String id = args[2];
                boolean saved = kitManager.saveKitFromPlayer(id, player);
                if (saved) {
                    player.sendMessage(mm.getPrefixed("kit.saved"));
                    player.sendMessage(MessageUtil.parseWithPrefix("<#1E3A8A>â–¸ <gray>Kaydedilen: <white>Inventory, Hotbar, Armor, OffHand, Enchant, Lore, DisplayName, Flags, NBT, Attribute, PotionMeta, FireworkMeta, BannerMeta, Shield Pattern, Leather Color, Armor Trim, CustomModelData, Durability, RepairCost - HiÃ§bir veri kaybolmadÄ±", player));
                } else {
                    player.sendMessage(mm.getPrefixed("kit.not-found", "%kit%", id));
                }
            }
            case "load", "yukle", "yÃ¼kle" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel kit load <id>"));
                    return;
                }
                String id = args[2];
                boolean loaded = kitManager.loadKitToPlayer(id, player);
                if (loaded) player.sendMessage(MessageUtil.parseWithPrefix("<gradient:#0A1931:#3B82F6>âœ” Kit yÃ¼klendi:</gradient> <white>" + id + "</white>", player));
                else player.sendMessage(mm.getPrefixed("kit.not-found", "%kit%", id));
            }
            case "delete", "sil", "remove" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel kit delete <id>"));
                    return;
                }
                String id = args[2];
                if (id.equalsIgnoreCase("own")) {
                    player.sendMessage(mm.getPrefixed("kit.cannot-delete-own"));
                    return;
                }
                boolean deleted = kitManager.deleteKit(id);
                if (deleted) player.sendMessage(mm.getPrefixed("kit.deleted", "%kit%", id));
                else player.sendMessage(mm.getPrefixed("kit.not-found", "%kit%", id));
            }
            case "rename", "setname", "isim", "ad" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 4) {
                    player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel kit rename <id> <MiniMessage isim>"));
                    return;
                }
                String id = args[2];
                String name = String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length));
                boolean ok = kitManager.setKitName(id, name);
                if (ok) {
                    player.sendMessage(mm.getPrefixed("kit.set-name", "%kit%", id));
                    player.sendMessage(MessageUtil.parseWithPrefix("<gray>Yeni isim: " + name, player));
                } else {
                    player.sendMessage(mm.getPrefixed("kit.not-found", "%kit%", id));
                }
            }
            case "icon", "seticon", "ikon" -> {
                if (!player.hasPermission("duel.admin")) {
                    player.sendMessage(mm.getPrefixed("no-permission"));
                    return;
                }
                if (args.length < 3) {
                    player.sendMessage(mm.getPrefixed("invalid-usage", "<usage>", "/duel kit icon <id> (elindeki eÅŸya ikon olur)"));
                    return;
                }
                String id = args[2];
                var item = player.getInventory().getItemInMainHand();
                if (item == null || item.getType() == org.bukkit.Material.AIR) {
                    player.sendMessage(mm.getPrefixed("error-occurred", "<error>", "Elinde eÅŸya tutmalÄ±sÄ±n!"));
                    return;
                }
                boolean ok = kitManager.setKitIcon(id, item.getType());
                if (ok) player.sendMessage(mm.getPrefixed("kit.set-icon", "%kit%", id, "%icon%", item.getType().name()));
                else player.sendMessage(mm.getPrefixed("kit.not-found", "%kit%", id));
            }
            default -> {
                if (kitManager.getKit(subKit).isPresent()) {
                    var kit = kitManager.getKit(subKit).get();
                    plugin.getGuiManager().openKitEditorGUI(player, kit);
                } else {
                    sendKitList(player);
                }
            }
        }
    }

    private void sendKitList(Player player) {
        var mm = plugin.getMessagesManager();
        var kits = plugin.getKitManager().getAllKits();
        String title = mm.getRaw("kit.list-title").replace("%count%", String.valueOf(kits.size()));
        player.sendMessage(MessageUtil.parse(title, player));
        if (kits.isEmpty()) {
            player.sendMessage(mm.getPrefixed("kit.list-empty"));
            return;
        }
        for (var kit : kits) {
            String format = mm.getRaw("kit.list-format").replace("%kit%", kit.getId()).replace("%icon%", kit.getIcon().name()).replace("%items%", String.valueOf(kit.getInventoryContents().length));
            player.sendMessage(MessageUtil.parse(format, player));
        }
        player.sendMessage(MessageUtil.parseWithPrefix("<#1E3A8A>â–¸ <gray>Kitler <white>kits.yml <gray>database'inde saklanÄ±r, restartta gitmez!", player));
    }

    private void handleGui(Player player, String[] args) {
        if (args.length >= 2) {
            String second = args[1].toLowerCase(Locale.ROOT);
            if (second.equals("admin") && player.hasPermission("duel.admin")) {
                plugin.getGuiManager().openAdminGUI(player);
                return;
            }
            if ((second.equals("settings") || second.equals("ayarlar")) && player.hasPermission("duel.admin")) {
                plugin.getGuiManager().openGlobalSettingsGUI(player);
                return;
            }
        }
        plugin.getGuiManager().openArenaListGUI(player);
    }
}

