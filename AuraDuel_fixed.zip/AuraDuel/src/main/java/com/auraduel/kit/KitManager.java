package com.Auraduel.kit;

import com.Auraduel.AuraDuel;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public final class KitManager {

    private final AuraDuel plugin;
    private final Map<String, Kit> kits = new ConcurrentHashMap<>();
    private final Map<UUID, String> editMode = new ConcurrentHashMap<>();

    public KitManager(AuraDuel plugin) {
        this.plugin = plugin;
    }

    public void loadKits() {
        kits.clear();
        var cfgManager = plugin.getKitConfigManager();
        if (cfgManager == null) {
            loadDefaultKits();
            return;
        }
        var cfg = cfgManager.getConfig();
        ConfigurationSection kitsSec = cfg.getConfigurationSection("kits");
        if (kitsSec == null || kitsSec.getKeys(false).isEmpty()) {
            loadDefaultKits();
            saveKits();
            return;
        }

        for (String id : kitsSec.getKeys(false)) {
            ConfigurationSection sec = kitsSec.getConfigurationSection(id);
            try {
                Kit kit = Kit.deserialize(id, sec);
                if (kit != null) {
                    kits.put(id.toLowerCase(Locale.ROOT), kit);
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Kit yÃ¼klenemedi: " + id, e);
            }
        }

        if (!kits.containsKey("own")) {
            Kit own = Kit.defaultKits().stream().filter(k -> k.getId().equals("own")).findFirst().orElse(null);
            if (own != null) {
                kits.put("own", own);
                saveKits();
            }
        }

        plugin.getLogger().info(kits.size() + " kit yÃ¼klendi.");
    }

    private void loadDefaultKits() {
        for (Kit kit : Kit.defaultKits()) {
            kits.put(kit.getId().toLowerCase(Locale.ROOT), kit);
        }
    }

    public void saveKits() {
        var cfgManager = plugin.getKitConfigManager();
        if (cfgManager == null) return;
        var cfg = cfgManager.getConfig();
        cfg.set("kits", null);
        ConfigurationSection kitsSec = cfg.createSection("kits");
        for (Kit kit : kits.values()) {
            ConfigurationSection sec = kitsSec.createSection(kit.getId());
            kit.serialize(sec);
        }
        cfgManager.save();
    }

    public void saveKit(Kit kit) {
        var cfgManager = plugin.getKitConfigManager();
        if (cfgManager == null) return;
        var cfg = cfgManager.getConfig();
        ConfigurationSection kitsSec = cfg.getConfigurationSection("kits");
        if (kitsSec == null) kitsSec = cfg.createSection("kits");
        kitsSec.set(kit.getId(), null);
        ConfigurationSection sec = kitsSec.createSection(kit.getId());
        kit.serialize(sec);
        cfgManager.save();
    }

    public void saveKitsSync() {
        var cfgManager = plugin.getKitConfigManager();
        if (cfgManager == null) return;
        var cfg = cfgManager.getConfig();
        cfg.set("kits", null);
        ConfigurationSection kitsSec = cfg.createSection("kits");
        for (Kit kit : kits.values()) {
            ConfigurationSection sec = kitsSec.createSection(kit.getId());
            kit.serialize(sec);
        }
        try {
            cfgManager.saveSync();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Kits sync kaydedilemedi", e);
        }
    }


    public boolean createEmptyKit(String id) {
        if (id == null || id.isEmpty()) return false;
        String key = id.toLowerCase(Locale.ROOT);
        if (kits.containsKey(key)) return false;
        Kit kit = new Kit(key);
        kit.setRawDisplayName("<gradient:#0A1931:#1E3A8A:#3B82F6>" + id + "</gradient>");
        kit.setRawLore(List.of("<gray>BoÅŸ kit - /duel kit edit " + id + " ile dÃ¼zenle", "<gray>Sonra /duel kit save " + id + " ile envanterini kaydet", "<#1E3A8A>KapalÄ± mavi tema", "<dark_gray>Database: kits.yml - kalÄ±cÄ±"));
        kit.setIcon(Material.DIAMOND_SWORD);
        kit.setPermission("duel.kit." + key);
        kit.setEnabled(true);
        kit.setOrder(kits.size());
        kits.put(key, kit);
        saveKit(kit);
        return true;
    }

    public boolean createKitFromPlayer(String id, Player player) {
        if (id == null || id.isEmpty()) return false;
        String key = id.toLowerCase(Locale.ROOT);
        if (kits.containsKey(key)) return false;
        Kit kit = new Kit(key);
        kit.setRawDisplayName("<gradient:#0A1931:#1E3A8A:#3B82F6>" + id + "</gradient>");
        kit.setRawLore(List.of("<gray>Ã–zel kit: " + id, "<gray>OluÅŸturan: " + player.getName(), "<#1E3A8A>KapalÄ± mavi tema"));
        kit.setIcon(player.getInventory().getItemInMainHand().getType() != Material.AIR ? player.getInventory().getItemInMainHand().getType() : Material.DIAMOND_SWORD);
        kit.setPermission("duel.kit." + key);
        kit.setInventoryFromPlayer(player);
        kits.put(key, kit);
        saveKit(kit);
        return true;
    }

    public boolean enterEditMode(UUID playerId, String id) {
        String key = id.toLowerCase(Locale.ROOT);
        if (!kits.containsKey(key)) return false;
        editMode.put(playerId, key);
        return true;
    }

    public Optional<String> getEditMode(UUID playerId) {
        return Optional.ofNullable(editMode.get(playerId));
    }

    public void exitEditMode(UUID playerId) {
        editMode.remove(playerId);
    }

    public boolean isInEditMode(UUID playerId) {
        return editMode.containsKey(playerId);
    }

    public boolean saveKitFromPlayer(String id, Player player) {
        String key = id.toLowerCase(Locale.ROOT);
        Kit kit = kits.get(key);
        if (kit == null) {
            if (!createEmptyKit(id)) return false;
            kit = kits.get(key);
        }
        kit.setInventoryFromPlayer(player);
        saveKit(kit);
        return true;
    }

    public boolean loadKitToPlayer(String id, Player player) {
        String key = id.toLowerCase(Locale.ROOT);
        Kit kit = kits.get(key);
        if (kit == null) return false;
        if (kit.getId().equals("own")) {
            return false;
        }

        try {
            player.getInventory().clear();

            ItemStack[] armor = kit.getArmorContents();
            if (armor != null && armor.length > 0) {
                player.getInventory().setArmorContents(armor);
            }

            ItemStack off = kit.getOffHand();
            if (off != null) {
                player.getInventory().setItemInOffHand(off);
            }

            ItemStack[] contents = kit.getInventoryContents();
            if (contents != null && contents.length > 0) {
                if (contents.length == 36) {
                    player.getInventory().setContents(contents);
                } else {
                    for (ItemStack is : contents) {
                        if (is != null && is.getType() != Material.AIR) {
                            player.getInventory().addItem(is);
                        }
                    }
                }
            }
            player.updateInventory();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteKit(String id) {
        if (id == null) return false;
        if (id.equalsIgnoreCase("own")) return false;
        String key = id.toLowerCase(Locale.ROOT);
        Kit removed = kits.remove(key);
        if (removed == null) return false;
        var cfg = plugin.getKitConfigManager().getConfig();
        var kitsSec = cfg.getConfigurationSection("kits");
        if (kitsSec != null) {
            kitsSec.set(id, null);
            kitsSec.set(key, null);
        }
        plugin.getKitConfigManager().save();
        return true;
    }

    public boolean renameKit(String id, String newRawDisplayName) {
        String key = id.toLowerCase(Locale.ROOT);
        Kit kit = kits.get(key);
        if (kit == null) return false;
        kit.setRawDisplayName(newRawDisplayName);
        saveKit(kit);
        return true;
    }

    public boolean setKitIcon(String id, Material icon) {
        var kit = kits.get(id.toLowerCase(Locale.ROOT));
        if (kit == null) return false;
        kit.setIcon(icon);
        saveKit(kit);
        return true;
    }

    public boolean setKitName(String id, String rawDisplayName) {
        return renameKit(id, rawDisplayName);
    }

    public boolean setKitPermission(String id, String permission) {
        var kit = kits.get(id.toLowerCase(Locale.ROOT));
        if (kit == null) return false;
        kit.setPermission(permission);
        saveKit(kit);
        return true;
    }

    public boolean setKitSlot(String id, int slot) {
        var kit = kits.get(id.toLowerCase(Locale.ROOT));
        if (kit == null) return false;
        kit.setGuiSlot(slot);
        saveKit(kit);
        return true;
    }

    public boolean setKitEnabled(String id, boolean enabled) {
        var kit = kits.get(id.toLowerCase(Locale.ROOT));
        if (kit == null) return false;
        kit.setEnabled(enabled);
        saveKit(kit);
        return true;
    }

    public Optional<Kit> getKit(String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(kits.get(id.toLowerCase(Locale.ROOT)));
    }

    public Kit getKitOrDefault(String id) {
        return getKit(id).orElseGet(() -> kits.get("own"));
    }

    public Collection<Kit> getAllKits() {
        List<Kit> sorted = new ArrayList<>(kits.values());
        sorted.sort(Comparator.comparingInt(Kit::getOrder).thenComparing(Kit::getId));
        return Collections.unmodifiableCollection(sorted);
    }

    public Collection<Kit> getEnabledKits() {
        List<Kit> enabled = new ArrayList<>();
        for (Kit k : kits.values()) if (k.isEnabled()) enabled.add(k);
        enabled.sort(Comparator.comparingInt(Kit::getOrder).thenComparing(Kit::getId));
        return enabled;
    }

    public Collection<Kit> getKitsForPlayer(Player player) {
        List<Kit> result = new ArrayList<>();
        for (Kit k : getEnabledKits()) {
            String perm = k.getPermission();
            if (perm == null || perm.isEmpty() || player.hasPermission(perm) || player.hasPermission("duel.admin") || player.hasPermission("duel.kit.*") || k.getId().equals("own")) {
                result.add(k);
            }
        }
        return result;
    }

    public List<String> getKitIds() {
        return new ArrayList<>(kits.keySet());
    }

    public int getCount() {
        return kits.size();
    }
}

