package com.Auraduel.kit;

import com.Auraduel.utils.InventorySerializer;
import com.Auraduel.utils.MessageUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Kit {

    private final String id;
    private String rawDisplayName;
    private List<String> rawLore;
    private Material icon;
    private int guiSlot = -1;
    private String permission = null;
    private boolean enabled = true;
    private int order = 0;
    private long cooldown = 0;

    private String inventoryBase64;
    private String armorBase64;
    private String offHandBase64;
    private String extraBase64;

    private transient ItemStack[] cachedInventory = null;
    private transient ItemStack[] cachedArmor = null;
    private transient ItemStack cachedOffHand = null;

    public Kit(String id) {
        this.id = id.toLowerCase(Locale.ROOT);
        this.rawDisplayName = "<gradient:#0A1931:#1E3A8A:#3B82F6>" + id + "</gradient>";
        this.rawLore = List.of("<gray>Ã–zel kit: " + id, "<#1E3A8A>KapalÄ± mavi tema", "<dark_gray>BoÅŸ kit - /duel kit edit ile dÃ¼zenle");
        this.icon = Material.DIAMOND_SWORD;
        this.permission = "duel.kit." + this.id;
    }

    public Kit(String id, String rawDisplayName, Material icon, List<String> rawLore, int guiSlot, String permission, boolean enabled, int order, long cooldown, String invB64, String armorB64, String offB64, String extraB64) {
        this.id = id.toLowerCase(Locale.ROOT);
        this.rawDisplayName = rawDisplayName != null ? rawDisplayName : "<white>" + id;
        this.icon = icon != null ? icon : Material.DIAMOND_SWORD;
        this.rawLore = rawLore != null ? new ArrayList<>(rawLore) : new ArrayList<>();
        this.guiSlot = guiSlot;
        this.permission = permission != null ? permission : "duel.kit." + this.id;
        this.enabled = enabled;
        this.order = order;
        this.cooldown = cooldown;
        this.inventoryBase64 = invB64;
        this.armorBase64 = armorB64;
        this.offHandBase64 = offB64;
        this.extraBase64 = extraB64;
    }

    public String getId() { return id; }
    public String getRawDisplayName() { return rawDisplayName; }
    public void setRawDisplayName(String raw) { this.rawDisplayName = raw; }
    public Component getDisplayName() { return MessageUtil.parse(rawDisplayName); }
    public List<String> getRawLore() { return rawLore; }
    public void setRawLore(List<String> lore) { this.rawLore = new ArrayList<>(lore); }
    public List<Component> getLore() {
        List<Component> comps = new ArrayList<>();
        for (String s : rawLore) comps.add(MessageUtil.parse(s));
        return comps;
    }
    public Material getIcon() { return icon; }
    public void setIcon(Material icon) { this.icon = icon; }
    public int getGuiSlot() { return guiSlot; }
    public void setGuiSlot(int slot) { this.guiSlot = slot; }
    public String getPermission() { return permission != null ? permission : "duel.kit." + id; }
    public void setPermission(String perm) { this.permission = perm; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public int getOrder() { return order; }
    public void setOrder(int order) { this.order = order; }
    public long getCooldown() { return cooldown; }
    public void setCooldown(long cd) { this.cooldown = cd; }
    public boolean isKeepInventory() { return id.equalsIgnoreCase("own"); }

    public java.util.List<org.bukkit.potion.PotionEffect> getEffects() {
        return List.of();
    }

    public String getInventoryBase64() { return inventoryBase64; }
    public String getArmorBase64() { return armorBase64; }
    public String getOffHandBase64() { return offHandBase64; }

    public void setKitItems(ItemStack[] inventory, ItemStack[] armor) {
        this.cachedInventory = inventory;
        this.cachedArmor = armor;
        this.inventoryBase64 = InventorySerializer.itemStackArrayToBase64(inventory);
        this.armorBase64 = InventorySerializer.itemStackArrayToBase64(armor);
    }

    public void setInventoryFromPlayer(org.bukkit.entity.Player player) {
        try {
            ItemStack[] contents = player.getInventory().getContents();
            this.inventoryBase64 = InventorySerializer.itemStackArrayToBase64(contents);
            this.cachedInventory = contents.clone();
            ItemStack[] armor = player.getInventory().getArmorContents();
            this.armorBase64 = armor != null ? InventorySerializer.itemStackArrayToBase64(armor) : null;
            this.cachedArmor = armor != null ? armor.clone() : null;
            ItemStack off = player.getInventory().getItemInOffHand();
            if (off != null && off.getType() != Material.AIR) {
                this.offHandBase64 = InventorySerializer.itemStackToBase64(off);
                this.cachedOffHand = off.clone();
            } else {
                this.offHandBase64 = null;
                this.cachedOffHand = null;
            }
            ItemStack[] extra = player.getInventory().getExtraContents();
            if (extra != null && extra.length > 0) {
                this.extraBase64 = InventorySerializer.itemStackArrayToBase64(extra);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public ItemStack[] getInventoryContents() {
        if (cachedInventory != null) return cachedInventory;
        if (inventoryBase64 == null) return new ItemStack[0];
        try { cachedInventory = InventorySerializer.itemStackArrayFromBase64(inventoryBase64); return cachedInventory; } catch (Exception e) { return new ItemStack[0]; }
    }

    public ItemStack[] getArmorContents() {
        if (cachedArmor != null) return cachedArmor;
        if (armorBase64 == null) return new ItemStack[0];
        try { cachedArmor = InventorySerializer.itemStackArrayFromBase64(armorBase64); return cachedArmor; } catch (Exception e) { return new ItemStack[0]; }
    }

    public ItemStack getOffHand() {
        if (cachedOffHand != null) return cachedOffHand;
        if (offHandBase64 == null) return null;
        try { cachedOffHand = InventorySerializer.itemStackFromBase64(offHandBase64); return cachedOffHand; } catch (Exception e) { return null; }
    }

    public List<ItemStack> getItems() {
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack is : getInventoryContents()) if (is != null && is.getType() != Material.AIR) list.add(is);
        return list;
    }

    public List<ItemStack> getArmor() {
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack is : getArmorContents()) if (is != null && is.getType() != Material.AIR) list.add(is);
        return list;
    }

    public void serialize(ConfigurationSection section) {
        section.set("displayName", rawDisplayName);
        section.set("lore", rawLore);
        section.set("icon", icon.name());
        section.set("guiSlot", guiSlot);
        section.set("permission", permission);
        section.set("enabled", enabled);
        section.set("order", order);
        section.set("cooldown", cooldown);
        section.set("inventoryBase64", inventoryBase64);
        section.set("armorBase64", armorBase64);
        section.set("offHandBase64", offHandBase64);
        section.set("extraBase64", extraBase64);
    }

    public static Kit deserialize(String id, ConfigurationSection section) {
        if (section == null) return new Kit(id);
        String displayName = section.getString("displayName", "<white>" + id);
        List<String> lore = section.getStringList("lore");
        if (lore.isEmpty()) lore = List.of("<gray>Ã–zel kit: " + id);
        String iconName = section.getString("icon", "DIAMOND_SWORD");
        Material icon;
        try { icon = Material.valueOf(iconName.toUpperCase(Locale.ROOT)); } catch (Exception e) { icon = Material.DIAMOND_SWORD; }
        int guiSlot = section.getInt("guiSlot", -1);
        String perm = section.getString("permission", "duel.kit." + id.toLowerCase(Locale.ROOT));
        boolean enabled = section.getBoolean("enabled", true);
        int order = section.getInt("order", 0);
        long cooldown = section.getLong("cooldown", 0);
        String invB64 = section.getString("inventoryBase64", null);
        String armorB64 = section.getString("armorBase64", null);
        String offB64 = section.getString("offHandBase64", null);
        String extraB64 = section.getString("extraBase64", null);

        if (invB64 == null) {
            Object itemsObj = section.get("items");
            if (itemsObj instanceof List) {
                List<?> list = (List<?>) itemsObj;
                List<ItemStack> itemsList = new ArrayList<>();
                for (Object o : list) if (o instanceof ItemStack) itemsList.add((ItemStack) o);
                if (!itemsList.isEmpty()) {
                    try { ItemStack[] arr = itemsList.toArray(new ItemStack[0]); invB64 = InventorySerializer.itemStackArrayToBase64(arr); } catch (Exception ignored) {}
                }
            }
        }
        if (armorB64 == null) {
            Object armorObj = section.get("armor");
            if (armorObj instanceof List) {
                List<?> list = (List<?>) armorObj;
                List<ItemStack> armorList = new ArrayList<>();
                for (Object o : list) if (o instanceof ItemStack) armorList.add((ItemStack) o);
                if (!armorList.isEmpty()) {
                    try { ItemStack[] arr = armorList.toArray(new ItemStack[0]); armorB64 = InventorySerializer.itemStackArrayToBase64(arr); } catch (Exception ignored) {}
                }
            }
        }

        return new Kit(id, displayName, icon, lore, guiSlot, perm, enabled, order, cooldown, invB64, armorB64, offB64, extraB64);
    }

    public static List<Kit> defaultKits() {
        List<Kit> kits = new ArrayList<>();

        Kit own = new Kit("own");
        own.setRawDisplayName("<gradient:#0A1931:#1E3A8A:#3B82F6>Kendi Envanter</gradient>");
        own.setRawLore(List.of("<gray>Mevcut envanterinle savaÅŸ", "<gray>EÅŸyalarÄ±n korunur"));
        own.setIcon(Material.CHEST);
        own.setOrder(0);
        kits.add(own);

        Kit nodebuff = new Kit("nodebuff");
        nodebuff.setRawDisplayName("<gradient:#0B2E5C:#1E5AA6:#3B82F6>NoDebuff</gradient>");
        nodebuff.setRawLore(List.of("<gray>1.8 NoDebuff kiti", "<gray>KÄ±lÄ±Ã§ + Olta", "<#1E3A8A>KapalÄ± mavi stil"));
        nodebuff.setIcon(Material.SPLASH_POTION);
        nodebuff.setOrder(1);
        nodebuff.setKitItems(
                inventoryOf(
                        slot(0, new ItemStack(Material.IRON_SWORD)),
                        slot(1, new ItemStack(Material.FISHING_ROD)),
                        slot(8, new ItemStack(Material.COOKED_BEEF, 16))
                ),
                new ItemStack[]{
                        new ItemStack(Material.CHAINMAIL_BOOTS),
                        new ItemStack(Material.CHAINMAIL_LEGGINGS),
                        new ItemStack(Material.CHAINMAIL_CHESTPLATE),
                        new ItemStack(Material.CHAINMAIL_HELMET)
                }
        );
        kits.add(nodebuff);

        Kit gapple = new Kit("gapple");
        gapple.setRawDisplayName("<gradient:#102A43:#1E4A8A:#2A6FDB>Gapple</gradient>");
        gapple.setRawLore(List.of("<gray>Gapple PvP kiti", "<gray>GÃ¼Ã§lÃ¼ zÄ±rh + altÄ±n elma"));
        gapple.setIcon(Material.GOLDEN_APPLE);
        gapple.setOrder(2);
        gapple.setKitItems(
                inventoryOf(
                        slot(0, new ItemStack(Material.DIAMOND_SWORD)),
                        slot(1, new ItemStack(Material.GOLDEN_APPLE, 8)),
                        slot(8, new ItemStack(Material.COOKED_BEEF, 16))
                ),
                new ItemStack[]{
                        new ItemStack(Material.DIAMOND_BOOTS),
                        new ItemStack(Material.DIAMOND_LEGGINGS),
                        new ItemStack(Material.DIAMOND_CHESTPLATE),
                        new ItemStack(Material.DIAMOND_HELMET)
                }
        );
        kits.add(gapple);

        Kit builduhc = new Kit("builduhc");
        builduhc.setRawDisplayName("<gradient:#0F1C3F:#1E3A5F:#3A6EA5>BuildUHC</gradient>");
        builduhc.setRawLore(List.of("<gray>BuildUHC kiti", "<gray>Blok + KÄ±lÄ±Ã§ + Yay"));
        builduhc.setIcon(Material.BRICK);
        builduhc.setOrder(3);
        builduhc.setKitItems(
                inventoryOf(
                        slot(0, new ItemStack(Material.DIAMOND_SWORD)),
                        slot(1, new ItemStack(Material.BOW)),
                        slot(2, new ItemStack(Material.ARROW, 32)),
                        slot(8, new ItemStack(Material.COOKED_BEEF, 16)),
                        slot(9, new ItemStack(Material.STONE, 64)),
                        slot(10, new ItemStack(Material.STONE, 64))
                ),
                new ItemStack[]{
                        new ItemStack(Material.IRON_BOOTS),
                        new ItemStack(Material.IRON_LEGGINGS),
                        new ItemStack(Material.IRON_CHESTPLATE),
                        new ItemStack(Material.IRON_HELMET)
                }
        );
        kits.add(builduhc);

        return kits;
    }

    private static ItemStack[] inventoryOf(SlotItem... slotItems) {
        ItemStack[] contents = new ItemStack[36];
        for (SlotItem si : slotItems) contents[si.slot] = si.item;
        return contents;
    }

    private static SlotItem slot(int slot, ItemStack item) {
        return new SlotItem(slot, item);
    }

    private static final class SlotItem {
        final int slot;
        final ItemStack item;
        SlotItem(int slot, ItemStack item) { this.slot = slot; this.item = item; }
    }
}

